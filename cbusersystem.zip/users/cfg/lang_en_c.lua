--//// Cannonball's Extended usersystem! ////--
--//// Fully SQL based. ////--
--//// This script may not be shared under any circumstance's. ////--
--//// Copyrights Cannonball ////--
--//// Coded by Cannonball ////--

-- Titles from the notifier ( Fading window with a message )
notifier_INFO = "[INFO]"
notifier_ERROR = "[ERROR]"
notifier_MESSAGE = "[MESSAGE]"

-- PM Message messages
pm_Send = "Message succesfully send."
pm_Del = "Message succesfully removed."
pm_SendError = "Please select a correct reciever.\nAnd provide a subject, and\na message."

-- Change own-settings
nameChange_msg = "Thank you, your name has been\nsaved.\nNew name: "
skinChange_msg = "Thank you, your skin has been\nsaved."

-- Moderation messages
noPlayerSelected_msg = "No player selected"