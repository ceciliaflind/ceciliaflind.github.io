﻿--//// Cannonball's Extended usersystem! ////--
--//// Fully SQL based. ////--
--//// This script may not be shared under any circumstance's. ////--
--//// Copyrights Cannonball ////--
--//// Coded by Cannonball ////--

noConnection = "[SQL] Error: Could not locate database file or connect to it."
errorQuery = "[SQL] Error in executing query"

-- // Clan tag? 
setTag = "[TAG]"