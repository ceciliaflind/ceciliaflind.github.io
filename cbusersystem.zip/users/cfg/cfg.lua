﻿--//// Cannonball's Extended usersystem! ////--
--//// Fully MySQL based. ////--
--//// This script may not be shared under any circumstance's. ////--
--//// Copyrights Cannonball ////--
--//// Coded by Cannonball ////--

--[[ Settings ]]--

--## Allow users to change their nicknames? e.g true/false
allowNickChange = true

--## Clan tag? 
setTag = "[TAG]"




------ ## PLEASE DO NOT TOUCH BELOW HERE ## -------

outputDebugString( "Initiating usersystem" )
--## Advised to not touch this part
initiateDatabase = dbConnect( "sqlite", "users.db" )
if( initiateDatabase ) then
	outputDebugString( "Connecting to database" )
end

local createPlayerTable = dbQuery( initiateDatabase, "CREATE TABLE IF NOT EXISTS players ( id INTEGER PRIMARY KEY AUTOINCREMENT, login TEXT, type INTEGER, class INTEGER, serial TEXT, skin INTEGER, money INTEGER, ip TEXT)", 10 )
if( createPlayerTable ) then
	outputDebugString( "Checking player tables.." )
end

local createMessageTable = dbQuery( initiateDatabase, "CREATE TABLE IF NOT EXISTS messages ( id INTEGER PRIMARY KEY AUTOINCREMENT, reciever TEXT, sender TEXT, subject TEXT, content TEXT, date INTEGER, read INTEGER)", 10 )
if( createMessageTable ) then
	outputDebugString( "Checking message tables..")
end

dbFree( createPlayerTable )
dbFree( createMessageTable )

outputDebugString( "Usersystem started!" )