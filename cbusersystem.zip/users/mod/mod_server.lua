﻿--//// Cannonball's Extended usersystem! ////--
--//// Fully SQL based. ////--
--//// This script may not be shared under any circumstance's. ////--
--//// Copyrights �Cannonball ////--
--//// Coded by Cannonball ////--

function secure(source)
	if( not initiateDatabase ) then
		outputChatBox( "Could not connect to MySQL server [SQLnames]" )
	else
		local mods = dbQuery( initiateDatabase, "SELECT class FROM players WHERE serial='" .. getPlayerSerial( source ) .. "'"  )
			if( mods ) then
			local result, num_affected_rows, errmsg = dbPoll ( mods, -1 )
				if num_affected_rows > 0 then
					for result, row in pairs ( result ) do
						if ( not row ) then break end
							if( row['class'] == 3 ) or ( row['class'] == 4 ) then
								triggerClientEvent (source, "modPanel", getRootElement())
							else
								outputChatBox("#FF0000*USER: #FFFF00You are not a moderator, therefor you cannot open this panel.", source, 0,0,0,true )
							end
					end
				end
			end
	end
end
addCommandHandler("mod", secure)

function unmute(client, playerSource)
	local unmuted = getPlayerFromName (client)
	local unmuter = getPlayerName (playerSource)
		if isPlayerMuted(unmuted) == true then
			setPlayerMuted(unmuted, false)
			--outputChatBox ("#FF0000*INFO: #FFFF00" ..unmuter.. " has unmuted you.", unmuted, 0, 0, 0, true)
			outputChatBox("#FF0000*INFO: #FFFF00" .. getPlayerName(unmuted) .. " has been unmuted.", getRootElement(), 255, 255, 255, true)
		else
			outputChatBox ("#FFFF00" ..client.. " is not muted.", source, 0, 0, 0, true)
	end
end

addEvent("kick", true)
	function kick (client, playerSource, reason)
		local kicked = getPlayerFromName(client)
		local kicker = getPlayerName(playerSource)
		kickPlayer (kicked, playerSource, reason)
	end
addEventHandler ("kick", getRootElement(), kick)

function ban (client, playerSource, reason)
	local banned = getPlayerFromName(client)
	banPlayer (banned, playerSource, reason)
end

addEvent ("kill", true)
	function kill (client, playerSource)
		local killed = getPlayerFromName(client)
		local killer = getPlayerName(playerSource)
		local aliveStatus = isPedDead(killed)
		if aliveStatus == true then
			outputChatBox ("#FFFF00" ..killer.. " is already dead.", myPlayer, 0, 0, 0, true)
		else
			killPed(killed)
			outputChatBox ("#FF0000*INFO: #FFFF00" ..killer.." has killed you!", killed, 0, 0, 0, true)
		end
	end
addEventHandler ("kill", getRootElement(), kill)

addEvent("mute", true)
	function mute (client, playerSource)
		local muted = getPlayerFromName (client)
		local muter = getPlayerName (playerSource)
		local isMuted = isPlayerMuted (muted)
		if isMuted == true then
			outputChatBox ("#FFFF00"  ..client.. " is already muted.", muted, 0, 0, 0, true)
		else
			setPlayerMuted(muted, true)
			outputChatBox("#FF0000*INFO: #FFFF00" .. getPlayerName(muted) .. " has been muted.", getRootElement(), 255, 255, 255, true)
		end
	end
addEventHandler ("mute", getRootElement(), mute)

addEvent ("blow", true)
	function blow (client, playerSource)
		local blow = getPlayerFromName(client)
		local blower = getPlayerName (playerSource)
		local aliveStatus = isPedDead (blow)
		if aliveStatus == true then
			outputChatBox ("#FFFF00"  ..client.. " is already dead.", source, 0, 0, 0, true)
		else
			X, Y, Z = getElementPosition(blow)
			createExplosion(X, Y, Z, 0)
			createExplosion(X, Y, Z, 0)
			createExplosion(X, Y, Z, 0)
			outputChatBox("#FF0000*INFO: #FFFF00" .. getPlayerName(blow) .. " has been bombed.", getRootElement(), 255, 255, 255, true)
		end
	end
addEventHandler ("blow", getRootElement(), blow)

addEvent ("zap", true)
	function zap (client, playerSource)
		local zapped = getPlayerFromName(client)
		local zapper = getPlayerName(playerSource)
		local aliveStatus = isPedDead (zapped)
			if aliveStatus == true then
			outputChatBox ("#FFFF00" ..client.. " is already dead.", source, 0, 0, 0, true)
			else
			X, Y, Z = getElementPosition(zapped)
			laser0 = createColSphere(X, Y, Z, 4) 
			Z = Z - 1
			laser1 = createMarker (X, Y, Z, "corona", 5, 0, 200, 0, 200)
			Z = Z + 5
			laser2 = createMarker (X, Y, Z, "checkpoint", 0.5, 0, 200, 0, 200)
			Z = Z + 50
			laser3 = createMarker (X, Y, Z, "checkpoint", 1, 0, 200, 0, 200)
			Z = Z + 400
			laser4 = createMarker (X, Y, Z, "checkpoint", 1, 0, 200, 0, 200)
			setTimer (destroyElement, 100, 1, laser0)
			setTimer (destroyElement, 600, 1, laser1)
			setTimer (destroyElement, 700, 1, laser2)
			setTimer (destroyElement, 700, 1, laser3)
			setTimer (destroyElement, 700, 1, laser4)
			killPed (zapped)
			outputChatBox("#FF0000*INFO: #FFFF00" .. getPlayerName(zapped) .. " has been zapped.", getRootElement(), 255, 255, 255, true)
		end
	end
addEventHandler ("zap", getRootElement(), zap)

addEvent ("onModSpec", true)
	function spectate (client, playerSource)
			spectated = getPlayerFromName (client)
			X, Y, Z = getElementPosition (playerSource)
			setElementPosition (playerSource, X, Y, Z)
			setCameraTarget (playerSource, spectated)
			setElementPosition (playerSource, X, Y, Z)
	end
addEventHandler ("onModSpec", getResourceRootElement(getThisResource()), spectate)

addEvent ("cancelSpec", true)
	function sSpec (myPlayer)
		setCameraTarget (myPlayer, myPlayer)
	end
addEventHandler ("cancelSpec", getResourceRootElement(getThisResource()), sSpec)




addEvent ("onModGive", true)
addEvent ("unmute", true)






addEventHandler ("unmute", getResourceRootElement(getThisResource()), unmute)
-- [New stuff - By Gecko]

-- Event handlers.
function modBurnPlayer(thePlayer, playerSource)
	if (isPedOnFire(thePlayer)) then
		setPedOnFire(thePlayer, false)
	else
		outputChatBox("#FF0000*INFO: #FFFF00" .. getPlayerName(thePlayer) .. " has been set on fire.", getRootElement(), 255, 255, 255, true)
		setPedOnFire(thePlayer, true)
	end
end

function modFreezePlayer(thePlayer, playerSource)
	if (isElementFrozen(thePlayer)) then
		outputChatBox("#FF0000*INFO: #FFFF00" .. getPlayerName(thePlayer) .. " has been unfrozen.", getRootElement(), 255, 255, 255, true)

		-- Unfreeze the player.
		setElementFrozen(thePlayer, false)
		
		-- If the player is in a vehicle, unfreeze it.
		if (isPedInVehicle(thePlayer)) then
			local theVehicle = getPedOccupiedVehicle(thePlayer)
			setElementFrozen(theVehicle, false)
		end
	else
		outputChatBox("#FF0000*INFO: #FFFF00" .. getPlayerName(thePlayer) .. " has been frozen.", getRootElement(), 255, 255, 255, true)
		-- Freeze the player.
		setElementFrozen(thePlayer, true)
		
		-- If the player is in a vehicle, freeze it.
		if (isPedInVehicle(thePlayer)) then
			local theVehicle = getPedOccupiedVehicle(thePlayer)
			setElementFrozen(theVehicle, true)
		end
	end
end

function modEjectPlayer(thePlayer, playerSource)
	if (isPedInVehicle(thePlayer)) then
		outputChatBox("#FF0000*INFO: #FFFF00" .. getPlayerName(thePlayer) .. " has been ejected.", getRootElement(), 255, 255, 255, true)
		removePedFromVehicle(thePlayer)
	end
end

-- Add event handlers.
addEvent("burnPlayerEvent", true)
addEventHandler("burnPlayerEvent", getRootElement(), modBurnPlayer)
addEvent("freezePlayerEvent", true)
addEventHandler("freezePlayerEvent", getRootElement(), modFreezePlayer)
addEvent("ejectPlayerEvent", true)
addEventHandler("ejectPlayerEvent", getRootElement(), modEjectPlayer)

-- [End]
