﻿--//// Cannonball's Extended usersystem! ////--
--//// Fully SQL based. ////--
--//// This script may not be shared under any circumstance's. ////--
--//// Copyrights Cannonball ////--
--//// Coded by Cannonball ////--

local open = false
local resX,resY = guiGetScreenSize()
local myPlayer = getLocalPlayer()
local inJail = false

addEvent("initModeratorPanel", true)
function modpanel(source)
		modPanel = guiCreateWindow ( resX/10*2, resY/12*3.5, 400, 250, "Moderator Panel", false )
		basicTools = guiCreateLabel (0.388, 0.09, 0.24, 0.06, "Moderation Tools:", true, modPanel)
		Extras = guiCreateLabel (0.388, 0.28, 0.18, 0.08, "Extras:", true, modPanel)

		kick = guiCreateButton( 0.622, 0.16, 0.10, 0.10, "Kick", true, modPanel)
		mute = guiCreateButton( 0.38, 0.16, 0.10, 0.10, "Mute", true, modPanel)
		unmute = guiCreateButton( 0.488, 0.16, 0.124, 0.10, "Unmute", true, modPanel)
		--ban = guiCreateButton( 0.732, 0.16, 0.10, 0.10, "Ban", true, modPanel) Currently disabled, might add later?
		kill = guiCreateButton( 0.38, 0.35, 0.10, 0.10, "Kill", true, modPanel)
		blow = guiCreateButton( 0.826, 0.35, 0.10, 0.10, "Bomb", true, modPanel)

		zap = guiCreateButton( 0.488, 0.47, 0.10, 0.10, "Zap", true, modPanel)
		spectate = guiCreateButton( 0.488, 0.35, 0.14, 0.10, "Spectate", true, modPanel)
		stopSpec = guiCreateButton( 0.636, 0.35, 0.18, 0.10, "Unspectate", true, modPanel)

		fireButton = guiCreateButton(0.598, 0.47, 0.10, 0.10, "Burn", true, modPanel)
		freezeButton = guiCreateButton(0.71, 0.47, 0.10, 0.10, "Freeze", true, modPanel)
		ejectButton = guiCreateButton(0.38, 0.47, 0.10, 0.10, "Eject", true, modPanel)

		guiLabelSetColor (basicTools, 0, 0, 255)
		guiLabelSetColor (Extras, 0, 0, 255)

		--showCursor(true)
		guiWindowSetSizable(modPanel, false)
		
		client = getLocalPlayer()		
		playerList = guiCreateGridList ( 0.02, 0.09, 0.34, 0.88, true, modPanel)
			local column = guiGridListAddColumn( playerList, "Player List", 0.85 )
			if ( column ) then
				for id, playeritem in ipairs (getElementsByType ("player")) do
					local row = guiGridListAddRow (playerList)
					guiGridListSetItemText (playerList, row, column, getPlayerName ( playeritem ), false, false)
				end
			end
					
		guiSetVisible( modPanel, false )

		
		addEventHandler("onClientGUIClick", mute, mutePlayer, false )
		addEventHandler("onClientGUIClick", unmute, unmutePlayer, false )
		
		addEventHandler("onClientGUIClick", spectate, spectatePlayer, false )
		addEventHandler("onClientGUIClick", stopSpec, stopSpectate, false )
		addEventHandler("onClientGUIClick", freezeButton, freezePlayer, false )
		addEventHandler("onClientGUIClick", ejectButton, ejectPlayer, false )
		addEventHandler("onClientGUIClick", kill, killPlayer, false )
		addEventHandler("onClientGUIClick", zap, zapPlayer, false )
		addEventHandler("onClientGUIClick", kick, kickPlayer, false )
		addEventHandler("onClientGUIClick", blow, bowPlayer, false )
		addEventHandler("onClientGUIClick", fireButton, firePLayer, false )
end
addEventHandler("initModeratorPanel", getRootElement(), modpanel )

addEvent("modPanel", true)
	function handleModWindow()
		if( guiGetVisible( modPanel ) == false ) then
			guiSetVisible( modPanel, true )
			guiSetAlpha( modPanel, 0 )
			setTimer ( function()
				guiSetAlpha( modPanel, guiGetAlpha(modPanel) + 0.1 )
			end, 60, 9 )
		else
			setTimer ( function()
				guiSetAlpha( modPanel, guiGetAlpha(modPanel) - 0.1 )
			end, 60, 9 )
			setTimer( guiSetVisible, 800, 1, modPanel, false )
		end
	end
addEventHandler("modPanel", getRootElement(), handleModWindow)
			

function updateModList()
		for id, player in ipairs(getElementsByType("player")) do
			local row = guiGridListAddRow ( playerList )
			guiGridListSetItemText ( playerList, row, column, getPlayerName ( player ), false, false )
			
				if ( column ) then
                for id, playeritem in ipairs(getElementsByType("player")) do
                        local row = guiGridListAddRow ( playerList )
                        guiGridListSetItemText ( playerList, row, column, getPlayerName ( playeritem ), false, false )
                end
			end
		end		
end

function kickPlayer()
kickBox = guiCreateWindow( resX/10*3.7, resY/12*3.5, 150, 100, "Reason", false)
selectedPlayer = guiGridListGetItemText ( playerList, guiGridListGetSelectedItem (playerList), 1 )   

	if source == kick then
		if ( guiGridListGetSelectedItem ( playerList ) ~= -1 ) then

				guiSetText (kickBox, "Reason")
				guiWindowSetSizable(kickBox, false)
				kickButton = guiCreateButton (0.07, 0.64, 0.36, 0.24, "Kick", true, kickBox)
				kickScreen = guiCreateEdit(0.06, 0.28, 0.87, 0.28, "", true, kickBox)	
				kickCancel = guiCreateButton (0.56, 0.64, 0.36, 0.24, "Cancel", true, kickBox)
				guiSetVisible(kickBox, true)
				--guiSetInputEnabled (true)
				
				addEventHandler("onClientGUIClick", kickCancel, 
					function() 
						destroyElement( kickBox )
						guiSetInputEnabled (false)
					end, 
				false )	
				
				addEventHandler("onClientGUIClick", kickButton, 
					function() 
						reason = guiGetText(kickScreen)
						destroyElement( kickBox )
						guiSetInputEnabled (false)
						triggerServerEvent ("kick", getRootElement(), selectedPlayer, client, reason)
					end, 
				false )	
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
			guiSetVisible (kickBox, false)
		end
	end
end

function mutePlayer()
	selectedPlayer = guiGridListGetItemText ( playerList, guiGridListGetSelectedItem (playerList), 1 )   
	if source == mute then
		if ( guiGridListGetSelectedItem ( playerList ) ~= -1 ) then
			triggerServerEvent ("mute", getRootElement(), selectedPlayer, client)
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end


function unmutePlayer()
selectedPlayer = guiGridListGetItemText ( playerList, guiGridListGetSelectedItem (playerList), 1 ) 	  
	if source == unmute then
		if ( guiGridListGetSelectedItem ( playerList ) ~= -1 ) then
			triggerServerEvent ("unmute", getRootElement(), selectedPlayer, client)
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end


function ban()
selectedPlayer = guiGridListGetItemText ( playerList, guiGridListGetSelectedItem (playerList), 1 )   
	if source == ban then
		if ( guiGridListGetSelectedItem ( playerList ) ~= -1 ) then
			triggerServerEvent ("ban", getRootElement(), selectedPlayer, client)
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end

function banned(thePlayer)
	if source == banButton then
		reason = guiGetText(banScreen)
		guiSetVisible(banBox, false)
		triggerServerEvent("ban", getRootElement(), selectedPlayer, client, reason)
	end
end

function banCancel(thePlayer)
	if source == banCancel then
		guiSetVisible(banBox, false)
	end
end

function killPlayer(thePlayer)
	if source == kill then
		selectedPlayer = guiGridListGetItemText ( playerList, guiGridListGetSelectedItem (playerList), 1 )   
		if ( guiGridListGetSelectedItem ( playerList ) ~= -1 ) then
			triggerServerEvent ("kill", getRootElement(), selectedPlayer, client)
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end



function bowPlayer(thePlayer)
	if source == blow then
		selectedPlayer = guiGridListGetItemText (playerList, guiGridListGetSelectedItem (playerList), 1 )   
		if ( guiGridListGetSelectedItem (playerList) ~= -1) then
			triggerServerEvent ("blow", getRootElement(), selectedPlayer, client)
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end


function zapPlayer(thePlayer)
	if source == zap then
		selectedPlayer = guiGridListGetItemText ( playerList, guiGridListGetSelectedItem (playerList), 1 )   
	if ( guiGridListGetSelectedItem ( playerList ) ~= -1 ) then
		triggerServerEvent ("zap", getRootElement(), selectedPlayer, client)
	else
		handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	 end
 end

function spectatePlayer(thePlayer)
	if source == spectate then
		selectedPlayer = guiGridListGetItemText ( playerList, guiGridListGetSelectedItem (playerList), 1 )   
		if ( guiGridListGetSelectedItem ( playerList ) ~= -1 ) then
			triggerServerEvent ("onModSpec",getRootElement(), selectedPlayer, client, speced)
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end

function stopSpectate()
	if source == stopSpec then
		triggerServerEvent ("cancelSpec", getRootElement(), myPlayer)
	end 
end

-- Set a player on fire.
function firePLayer()
	if (source == fireButton) then
		if (guiGridListGetSelectedItem(playerList) ~= -1) then
			thePlayer = getPlayerFromName(guiGridListGetItemText(playerList, guiGridListGetSelectedItem(playerList), 1))
			triggerServerEvent("burnPlayerEvent", getLocalPlayer(), thePlayer, client) 
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end


-- Freeze a player.
function freezePlayer()
	if (source == freezeButton) then
		if (guiGridListGetSelectedItem(playerList) ~= -1) then
			thePlayer = getPlayerFromName(guiGridListGetItemText(playerList, guiGridListGetSelectedItem(playerList), 1))
			triggerServerEvent("freezePlayerEvent", getLocalPlayer(), thePlayer, client)
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end

-- Eject a player.
function ejectPlayer()
	if (source == ejectButton) then
		if (guiGridListGetSelectedItem(playerList) ~= -1) then
			thePlayer = getPlayerFromName(guiGridListGetItemText(playerList, guiGridListGetSelectedItem(playerList), 1))
			triggerServerEvent("ejectPlayerEvent", getLocalPlayer(), thePlayer, client) 
		else
			handleNotifier(noPlayerSelected_msg, notifier_INFO)
		end
	end
end


addEventHandler("onClientJoin", getRootElement(), updateModList)
addEventHandler("onClientQuit", getRootElement(), updateModList)