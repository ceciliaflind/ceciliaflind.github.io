--[[
	Basic Roleplay Gamemode
	~ Server-side functions for interiors
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local types = {house=true, business=true, government=true}
local interiors = {
	-- ID : x position, y position, z position, interior
	-- Original list by 'mabako', final edits and adds by 'Socialz'
	-- You can add your own mapping positions, but the dimension will always be different so it's not recommened
	
	house1  = {235.25, 1186.68, 1080.26, 3},
	house2  = {226.79, 1240.02, 1082.14, 2},
	house3  = {223.07, 1287.09, 1082.14, 1},
	house4  = {327.94, 1477.73, 1084.44, 15},
	house5  = {2468.84, -1698.29, 1013.51, 2},
	house6  = {226.34, 1114.23, 1080.89, 5},
	house7  = {387.23, 1471.79, 1080.19, 15},
	house8  = {225.79, 1021.46, 1084.02, 7},
	house9  = {295.16, 1472.26, 1080.26, 15},
	house10 = {2807.58, -1174.75, 1025.57, 8},
	house12 = {2270.42, -1210.52, 1047.56, 10},
	house13 = {2496.02, -1692.08, 1014.74, 3},
	house14 = {2259.38, -1135.84, 1050.64, 10},
	house15 = {2365.21, -1135.60, 1050.88, 8},
	house16 = {1531.36, -6.84, 1002.01, 3},
	house17 = {2233.8, -1115.36, 1050.89, 5},
	house18 = {2282.90, -1140.27, 1050.9, 11},
	house19 = {2196.75, -1204.34, 1048.84, 6},
	house20 = {2308.78, -1212.91, 1048.82, 6},
	house21 = {2217.85, -1076.29, 1053, 1},
	house22 = {2237.61, -1081.48, 1048.91, 2},
	house23 = {2317.82, -1026.75, 1049.21, 9},
	house24 = {260.98, 1284.40, 1080.08, 4},
	house25 = {140.18, 1366.58, 1083.86, 5},
	house26 = {82.95, 1322.38, 1083.48, 9},
	house27 = {-42.56, 1405.64, 1084.60, 8},
	house28 = {2333.03, -1077.22, 1048.86, 6},
	
	madddogg = {1298.95, -797.01, 1084.01, 5},
	
	room1 = {243.71, 304.95, 999.14, 1},
	room2 = {266.50, 305.01, 999.14, 2},
	room3 = {322.18, 302.35, 999.14, 5},
	room4 = {343.71, 304.98, 999.14, 6},
	
	['24/7-1'] =  {-25.89, -188.24, 1003.54, 17},
	['24/7-2'] =  {6.11, -31.75, 1003.54, 10},
	['24/7-3'] =  {-25.89, -188.24, 1003.54, 17},
	['24/7-4'] =  {-25.77, -141.55, 1003.55, 16},
	['24/7-5'] =  {-27.30, -31.76, 1003.56, 4},
	['24/7-6'] =  {-27.34, -58.26, 1003.55, 6},
	ammunation1 = {285.50, -41.80, 1001.52, 1},
	ammunation2 = {285.87, -86.78, 1001.52, 4}, 
	ammunation3 = {296.84, -112.06, 1001.52, 6},
	ammunation4 = {315.70, -143.66, 999.60, 7},
	ammunation5 = {316.32, -170.30, 999.60, 6},
	atrium =      {1727.04, -1637.84, 20.22, 18},
	bar =         {501.99, -67.56, 998.75, 11},
	bar2 =        {-229.3, 1401.28, 27.76, 18},
	bar3 =        {1212.12, -26.14, 1000.99, 3},
	bar4 =        {681.58, -450.89, -25.37, 1},
	burgershot =  {362.84, -75.13, 1001.50, 10},
	clothes1 =    {207.63, -111.26, 1005.13, 15},
	clothes2 =    {204.32, -168.85, 1000.52, 14},
	clothes3 =    {207.07, -140.37, 1003.51, 3},
	clothes4 =    {203.81, -50.66, 1001.80, 1},
	clothes5 =    {227.56, -8.06, 1002.21, 5},
	clothes6 =    {161.37, -97.11, 1001.80, 18},
	club =        {493.50, -24.95, 1000.67, 17},
	club2 =       {-2636.66, 1402.36, 906.50, 3},
	cluckinbell = {364.98, -11.84, 1001.85, 9},
	diner      =  {460.53, -88.62, 999.55, 4},
	diner2      = {441.90, -49.70, 999.74, 6},
	donut      =  {377.08, -193.30, 1000.63, 17},
	electronics = {-2240.77, 137.20, 1035.41, 6},
	meatfactor = {964.93, 2160.09, 1011.03, 1},
	office1 =     {390.76, 173.79, 1008.38, 3},
	office2 =     {-2026.86, -103.60, 1035.18, 3},
	office3 =     {1494.36, 1303.57, 1093.28, 3},
	pizza =       {372.33, -133.52, 1001.49, 5},
	sexshop =     {-100.34, -25.03, 1000.72, 3},
	reeces =      {412, -23, 1002, 2},
	barber =      {418.6, -84.17, 1001.70, 3},
	tattoo =      {-204.37, -8.90, 1002.26, 17},
	factor =  {2541.71, -1304.07, 1025.08, 2},
	battlefield = {-977.72, 1052.96, 1345.22, 10},
	hallway =  {2266.15, 1647.42, 1084.29, 1},
	betting =     {834.78, 7.42, 1003.97, 3},
	betting2 =    {-2158.58, 643.15, 1052.33, 1},
	motel =       {2214.42, -1150.51, 1025.41, 15},
	gym =         {773.57, -78.12, 1000.88, 7},
	gym2 =        {772.11, -5, 1000.42, 5},
	gym3 =        {774.18, -50.42, 1000.60, 6},
	sex =         {-100.33, -24.94, 1000.33, 3},
	stadium =     {-1426.14, 928.44, 1036.35, 15},
	stadium2 =    {-1426.13, 44.16, 1036.23, 1},
	stadium3 =    {-1464.72, 1555.93, 1052.68, 14},
	sgarage =    {-2105.32, 893.01, 76.7, 0},
	mgarage =    {2644.87, -2043.41, 13.62, 0},
	warehouse1 =    {2561.16, -1287.47, 1031.42, 2},
	warehouse2 =    {1405.3120, -8.2928, 1000.9130, 1},
	
	lspd = {246.75, 62.32, 1003.64, 6},
	sfpd = {246.35, 107.30, 1003.22, 10},
	lvpd = {238.72, 138.62, 1003.02, 3},

	test = {0, 0, 3, 0}
}

local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

-- ~ [CREATEINTERIOR, MAKEINTERIOR, MAKEINT] ~ --
addCommandHandler({"createinterior", "makeinterior", "makeint"},
	function(player, cmd, id, cost, type, ...)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			local cost = tonumber(cost)
			if id and cost and type and (...) then
				if interiors[id:lower()] then
					if types[type:lower()] then
						local name = table.concat({ ... }, " ")
						if #name > 0 then
							local xml = xmlLoadFile("interiors.map")
							local new = xmlCreateChild(xml, "interior")
							local px, py, pz = getElementPosition(player)
							local interior = getElementInterior(player)
							local dimension = getElementDimension(player)
							local randomid = math.random(1,99999)
							local randomdimension = math.random(0,65535)
							xmlNodeSetAttribute(new, "id", tonumber(randomid))
							xmlNodeSetAttribute(new, "inside", id)
							xmlNodeSetAttribute(new, "name", tostring(name))
							xmlNodeSetAttribute(new, "posx", tonumber(px))
							xmlNodeSetAttribute(new, "posy", tonumber(py))
							xmlNodeSetAttribute(new, "posz", tonumber(pz) + 1)
							xmlNodeSetAttribute(new, "interior", tonumber(interior))
							xmlNodeSetAttribute(new, "dimension", tonumber(dimension))
							xmlNodeSetAttribute(new, "owner", "None")
							xmlNodeSetAttribute(new, "createdby", getPlayerName(player))
							xmlSaveFile(xml)
							xmlUnloadFile(xml)
							
							-- Exterior marker
							local exterior = createMarker(px, py, pz + 1, "arrow", 2, 255, 255, 0, 180)
							setElementInterior(exterior, interior)
							setElementDimension(exterior, dimension)
							setElementData(exterior, "interiors.name", name)
							setElementData(exterior, "interiors.id", randomid)
							setElementData(exterior, "interiors.x", interiors[id][1])
							setElementData(exterior, "interiors.y", interiors[id][2])
							setElementData(exterior, "interiors.z", interiors[id][3])
							setElementData(exterior, "interiors.int", interiors[id][4])
							setElementData(exterior, "interiors.dim", randomdimension)
							setElementData(exterior, "interiors.extra", "Entrance")
							setElementData(exterior, "interiors.owner", "None")
							
							-- Interior marker
							local interior = createMarker(interiors[id][1], interiors[id][2], interiors[id][3] + 1, "arrow", 2, 255, 255, 0, 180)
							setElementInterior(interior, interiors[id][4])
							setElementDimension(interior, randomdimension)
							setElementData(interior, "interiors.name", name)
							setElementData(interior, "interiors.id", randomid)
							setElementData(interior, "interiors.x", pz)
							setElementData(interior, "interiors.y", py)
							setElementData(interior, "interiors.z", pz - 1)
							setElementData(interior, "interiors.int", interior)
							setElementData(interior, "interiors.dim", dimension)
							setElementData(interior, "interiors.extra", "Exit")
							setElementData(interior, "interiors.owner", "None")
							
							outputChatBox("Created a new interior with ID " .. randomid .. ".", player, 0, 255, 0, false)
							outputServerLog("[INTERIORS] [CMD/CREATEINTERIOR]: " .. getPlayerName(player) .. " created a new interior (ID: " .. randomid .. ", Cost: " .. cost .. ", Interior: " .. id .. ", Name: " .. name .. ").")
						else
							outputChatBox("Syntax: /" .. cmd .. " <id> <cost> <type: house, business, government> <name>", player, 220, 220, 0, false)
						end
					else
						outputChatBox("Invalid interior type.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Invalid interior ID.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <id> <cost> <type: house, business, government> <name>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [DELETEINTERIOR, DELINTERIOR, DELINT] ~ --
addCommandHandler({"deleteinterior", "delinterior", "delint"},
	function(player, cmd, id)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			local id = tonumber(id)
			if id then
				local xml = xmlLoadFile("interiors.map")
				local new = xmlFindChild(xml, "interior", 0)
				for i,v in ipairs(getElementsByType("marker")) do
					for ii,vv in ipairs(getElementsByType("interior")) do
						if getElementData(v, "interiors.id") and getElementData(v, "interiors.id") == getElementData(vv, "id") then
							if getElementData(v, "interiors.extra") == "Entrance" then
								xmlNodeSetName(new, "deleted")
								xmlNodeSetAttribute(new, "deletedby", getPlayerName(player))
								xmlSaveFile(xml)
								xmlUnloadFile(xml)
							end
							destroyElement(v)
						end
					end
				end
				outputChatBox("Deleted interior " .. tonumber(id) .. ".", player, 0, 255, 0, false)
				outputServerLog("[INTERIORS] [CMD/DELETEINTERIOR]: " .. getPlayerName(player) .. " deleted interior " .. tonumber(id) .. ".")
			else
				outputChatBox("Syntax: /" .. cmd .. " <id>", player, 220, 220, 0, false)
			end
		end
	end
)

-- Do not change this integer, thanks
local results = 0

-- ~ [NEARBYINTERIORS, NEARBYINTS] ~ --
addCommandHandler({"nearbyinteriors", "nearbyints"},
	function(player, cmd)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			local x, y, z = getElementPosition(player)
			outputChatBox("Nearby interiors:", player)
			for i,v in ipairs(getElementsByType("marker")) do
				if exports.brpExports:isElementInRangeOfPoint(v, x, y, z, 15) then
					if getElementData(v, "interiors.id") then
						outputChatBox(" " .. getElementData(v, "interiors.extra") .. " [" .. getElementData(v, "interiors.id") .. "] '" .. getElementData(v, "interiors.name") .. "' owned by " .. getElementData(v, "interiors.owner") .. ".", player, 220, 220, 0, false)
						if results == 0 then
							results = 1
						end
					end
				end
			end
			outputServerLog("[INTERIORS] [CMD/NEARBYINTERIORS]: " .. getPlayerName(player) .. " checked for nearby interiors at " .. x .. ", " .. y .. ", " .. z .. ".")
			if results == 0 then
				outputChatBox(" No nearby interiors found.", player, 255, 0, 0, false)
			else
				results = 0
			end
		end
	end
)

-- ~ [SETINTERIOROWNER, SETINTOWNER] ~ --
addCommandHandler({"setinteriorowner", "setintowner"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local account = getPlayerAccount(target)
					local accountname = getAccountName(account)
					if not isGuestAccount(account) then
						if getElementData(player, "temp.id") and getElementDimension(player) > 0 then
							for i,v in ipairs(getElementsByType("marker")) do
								if getElementData(v, "interiors.id") == getElementData(player, "temp.id") and getElementData(v, "interiors.extra") == "Entrance" then
									outputChatBox("Interior " .. getElementData(v, "interiors.id") .. " (" .. getElementData(v, "interiors.name") .. ") transferred to " .. getPlayerName(target) .. " (account: " .. accountname .. ").", player, 0, 255, 0, false)
									outputServerLog("[INTERIORS] [CMD/SETINTERIOROWNER]: " .. getPlayerName(player) .. " transferred interior " .. getElementData(v, "interiors.id") .. " (" .. getElementData(v, "interiors.name") .. ") to " .. getPlayerName(target) .. " (account: " .. accountname .. ").")
									setElementData(v, "interiors.owner", accountname)
								elseif getElementData(v, "interiors.id") == getElementData(player, "temp.id") and getElementData(v, "interiors.extra") == "Exit" then
									setElementData(v, "interiors.owner", accountname)
								end
							end
						else
							outputChatBox("Enter an interior first to do this.", player, 255, 0, 0, false)
						end
					else
						outputChatBox("That player is not logged in yet.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Couldn't find such player.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETINTERIOROWNER, SETINTNAME] ~ --
addCommandHandler({"setinteriorname", "setintname"},
	function(player, cmd, ...)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if (...) then
				local name = table.concat({ ... }, " ")
				if #name > 0 then
					if getElementData(player, "temp.id") and getElementDimension(player) > 0 then
						for i,v in ipairs(getElementsByType("marker")) do
							if getElementData(v, "interiors.id") == getElementData(player, "temp.id") and getElementData(v, "interiors.extra") == "Entrance" then
								outputChatBox("Interior " .. getElementData(v, "interiors.id") .. " (" .. getElementData(v, "interiors.name") .. ") name changed to " .. name .. ".", player, 0, 255, 0, false)
								outputServerLog("[INTERIORS] [CMD/SETINTERIORNAME]: " .. getPlayerName(player) .. " changed interior " .. getElementData(v, "interiors.id") .. " (" .. getElementData(v, "interiors.name") .. ") name to " .. name .. ".")
								setElementData(v, "interiors.name", name)
							elseif getElementData(v, "interiors.id") == getElementData(player, "temp.id") and getElementData(v, "interiors.extra") == "Exit" then
								setElementData(v, "interiors.name", name)
							end
						end
					else
						outputChatBox("Enter an interior first to do this.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Syntax: /" .. cmd .. " <name>", player, 220, 220, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <name>", player, 220, 220, 0, false)
			end
		end
	end
)

function enterInterior(source)
	fadeCamera(source, false, 1.3)
	unbindKey(source, "F", "down", enterInterior)
	setTimer(function(source)
		setElementFrozen(source, true)
		setElementData(source, "temp.using", 1)
		setElementDimension(source, getElementData(source, "temp.dim"))
		setElementInterior(source, getElementData(source, "temp.int"))
		setElementPosition(source, getElementData(source, "temp.posx"), getElementData(source, "temp.posy"), getElementData(source, "temp.posz"), true)
		outputServerLog("[INTERIORS] [PLA/ENTER]: " .. getPlayerName(source) .. " entered interior id " .. getElementData(source, "temp.id") .. " (" .. getElementData(source, "temp.name") .. ").")
		removeElementData(source, "temp.name")
		removeElementData(source, "temp.dim")
		removeElementData(source, "temp.int")
		removeElementData(source, "temp.posx")
		removeElementData(source, "temp.posy")
		removeElementData(source, "temp.posz")
		fadeCamera(source, true, 1.3)
		setTimer(setElementFrozen, 1000, 1, source, false)
		setTimer(function(source)
			setElementDimension(source, getElementData(source, "temp.dim"))
			setElementInterior(source, getElementData(source, "temp.int"))
			removeElementData(source, "temp.using")
		end, 2000, 1, source)
	end, 1300, 1, source)
end

addEventHandler("onMarkerHit", root,
	function(hitElement, matchingDimension)
		if getElementType(hitElement) == "player" and not getPedOccupiedVehicle(hitElement) then
			if matchingDimension then
				if getElementData(source, "interiors.id") then
					if not getElementData(hitElement, "temp.using") then
						bindKey(hitElement, "F", "down", enterInterior, hitElement)
						setElementData(hitElement, "temp.id", getElementData(source, "interiors.id"))
						setElementData(hitElement, "temp.name", getElementData(source, "interiors.name"))
						setElementData(hitElement, "temp.dim", getElementData(source, "interiors.dim"))
						setElementData(hitElement, "temp.int", getElementData(source, "interiors.int"))
						setElementData(hitElement, "temp.posx", getElementData(source, "interiors.x"))
						setElementData(hitElement, "temp.posy", getElementData(source, "interiors.y"))
						setElementData(hitElement, "temp.posz", getElementData(source, "interiors.z"))
						infodisplay = textCreateDisplay()
					    textDisplayAddObserver(infodisplay, hitElement)
					    infoname1 = textCreateTextItem("Name: " .. getElementData(source, "interiors.name"), 0.5, 0.945, 2, 255, 255, 255, 255, 1.0, "center", "bottom")
						infoowner1 = textCreateTextItem("Owner: " .. getElementData(source, "interiors.owner"), 0.5, 0.957, 2, 255, 255, 255, 255, 1.0, "center", "bottom")
						infoenter1 = textCreateTextItem("Press 'F' to enter this interior.", 0.5, 0.969, 2, 255, 255, 255, 255, 1.0, "center", "bottom")
						textDisplayAddText(infodisplay, infoname1)
						textDisplayAddText(infodisplay, infoowner1)
						textDisplayAddText(infodisplay, infoenter1)
						outputServerLog("[INTERIORS] [PLA/ENTERMARKER]: " .. getPlayerName(hitElement) .. " entered a interior marker [" .. getElementData(source, "interiors.id") .. "].")
					end
				end
			end
		end
	end
)

addEventHandler("onMarkerLeave", root,
	function(leaveElement, matchingDimension)
		if getElementType(leaveElement) == "player" and not getPedOccupiedVehicle(leaveElement) then
			if matchingDimension then
				if getElementData(source, "interiors.id") then
					unbindKey(leaveElement, "F", "down", enterInterior)
					removeElementData(leaveElement, "temp.name")
					removeElementData(leaveElement, "temp.dim")
					removeElementData(leaveElement, "temp.int")
					removeElementData(leaveElement, "temp.posx")
					removeElementData(leaveElement, "temp.posy")
					removeElementData(leaveElement, "temp.posz")
					textDestroyTextItem(infoname1)
					textDestroyTextItem(infoowner1)
					textDestroyTextItem(infoenter1)
					textDisplayRemoveObserver(infodisplay, leaveElement)
					textDestroyDisplay(infodisplay)
					outputServerLog("[INTERIORS] [PLA/LEAVEMARKER]: " .. getPlayerName(leaveElement) .. " left a interior marker [" .. getElementData(source, "interiors.id") .. "].")
				end
			end
		end
	end
)

addEventHandler("onResourceStart", resourceRoot,
	function()
		for i,v in ipairs(getElementsByType("interior")) do
			local exterior = createMarker(getElementData(v, "posx"), getElementData(v, "posy"), getElementData(v, "posz"), "arrow", 2, 255, 255, 0, 180)
			setElementInterior(exterior, getElementData(v, "interior"))
			setElementDimension(exterior, getElementData(v, "dimension"))
			setElementData(exterior, "interiors.name", getElementData(v, "name"))
			setElementData(exterior, "interiors.id", getElementData(v, "id"))
			setElementData(exterior, "interiors.x", interiors[getElementData(v, "inside")][1])
			setElementData(exterior, "interiors.y", interiors[getElementData(v, "inside")][2])
			setElementData(exterior, "interiors.z", interiors[getElementData(v, "inside")][3])
			setElementData(exterior, "interiors.int", interiors[getElementData(v, "inside")][4])
			setElementData(exterior, "interiors.extra", "Entrance")
			setElementData(exterior, "interiors.owner", getElementData(v, "owner"))
			
			local interior = createMarker(interiors[getElementData(v, "inside")][1], interiors[getElementData(v, "inside")][2], interiors[getElementData(v, "inside")][3] + 1, "arrow", 2, 255, 255, 0, 180)
			local randdim = math.random(0,65535)
			setElementInterior(interior, interiors[getElementData(v, "inside")][4])
			setElementDimension(interior, randdim)
			setElementData(interior, "interiors.name", getElementData(v, "name"))
			setElementData(interior, "interiors.id", getElementData(v, "id"))
			setElementData(interior, "interiors.x", getElementData(v, "posx"))
			setElementData(interior, "interiors.y", getElementData(v, "posy"))
			setElementData(interior, "interiors.z", getElementData(v, "posz") - 1)
			setElementData(interior, "interiors.int", getElementData(v, "interior"))
			setElementData(interior, "interiors.dim", getElementData(v, "dimension"))
			setElementData(interior, "interiors.owner", getElementData(v, "owner"))
			setElementData(interior, "interiors.extra", "Exit")
			setElementData(exterior, "interiors.dim", randdim)
		end
		
		for i,v in ipairs(getElementsByType("player")) do
			if getElementData(v, "temp.using") then
				removeElementData(v, "temp.using")
			end
		end
		
		outputServerLog("[INTERIORS] [AUTO/SPAWN]: All interiors spawned as the resource started.")
	end
)

addEventHandler("onResourceStop", resourceRoot,
	function()
		for iv,vv in ipairs(getElementsByType("marker")) do
			for i,v in ipairs(getElementsByType("interior")) do
				local xml = xmlLoadFile("interiors.map")
				local new = xmlFindChild(xml, "interior", 0)
				if getElementData(vv, "interiors.id") == xmlNodeGetAttribute(new, "id") then
					local owner = getElementData(vv, "interiors.owner")
					local name = getElementData(vv, "interiors.name")
					xmlNodeSetAttribute(new, "owner", owner)
					xmlNodeSetAttribute(new, "name", name)
					xmlSaveFile(xml)
					xmlUnloadFile(xml)
				end
			end
		end
		
		for i,v in ipairs(getElementsByType("player")) do
			if getElementData(v, "temp.using") then
				removeElementData(v, "temp.using")
			end
		end
		
		outputServerLog("[INTERIORS] [AUTO/SAVE]: All interiors saved as the resource stopped.")
	end
)