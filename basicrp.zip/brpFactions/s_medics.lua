--[[
	Basic Roleplay Gamemode
	~ Server-side functions for the medics
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Configurations (modifyable)
local minimum = 0 -- Minimum heal price
local maximum = 1000 -- Maximum heal price

-- Functions
addCommandHandler("heal",
	function(player, cmd, name, price)
		for index,ped in ipairs(getElementsByType("ped")) do
			if exports.brpExports:getPlayerFaction(player) == tonumber(getElementData(ped, "factions.id")) then
				if exports.brpExports:getFactionType(ped) == "medical" then
					local price = tonumber(price)
					if name and price then
						if price >= minimum and price <= maximum then
							local target = exports.brpExports:findPlayer(name, player)
							if target then
								if player ~= target then
									if getPlayerMoney(target) >= price then
										local x, y, z = getElementPosition(player)
										if exports.brpExports:isElementInRangeOfPoint(target, x, y, z, 5) then
											setElementHealth(target, 100)
											takePlayerMoney(target, getPlayerMoney(target) - price)
											outputChatBox("You healed " .. getPlayerName(target) .. " for $" .. price .. ".", player, 0, 255, 0, false)
											outputChatBox("You were healed by " .. getPlayerName(player) .. " and you paid $" .. price .. " for it.", player, 0, 255, 0, false)
											setElementData(ped, "factions.money", tonumber(getElementData(v, "factions.money")) + price)
										else
											outputChatBox("You're too far away from your patient, get closer.", player, 255, 0, 0, false)
										end
									else
										outputChatBox("They cannot afford your services.", player, 255, 0, 0, false)
									end
								else
									outputChatBox("You cannot heal yourself.", player, 255, 0, 0, false)
								end
							else
								outputChatBox("Couldn't find such player.", player, 255, 0, 0, false)
							end
						else
							outputChatBox("Price must be between $" .. minimum .. "-" .. maximum .. ".", player, 255, 0, 0, false)
						end
					else
						outputChatBox("Syntax: /" .. cmd .. " <player> <price>", player, 220, 220, 0, false)
					end
				else
					outputChatBox("You need to be part of a medical faction to do this.", player, 255, 0, 0, false)
				end
			end
		end
	end
)

addCommandHandler("stretcher",
	function(player, cmd)
		if exports.brpExports:isPlayerInFaction(player) then
			for i,v in ipairs(getElementsByType("ped")) do
				if getElementData(v, "factions.type") == "medical" then
					if tonumber(getElementData(v, "factions.id")) == tonumber(getElementData(player, "factions.player")) then
						local x, y, z = getElementPosition(player)
						for index,veh in ipairs(getElementsByType("vehicle")) do
							if getVehicleName(veh) == "Ambulance" then
								if exports.brpExports:isElementInRangeOfPoint(veh, x, y, z, 10) then
									if not getElementData(player, "stretcher") then
										stretcher = createObject(2146, x, y, z, 0, 0, 0)
										attachElements(stretcher, player, 0, 1.4, -0.5)
										setElementCollisionsEnabled(stretcher, false)
										setElementData(player, "stretcher", true)
										outputServerLog("[FACTIONS] [CMD/STRETCHER]: " .. getPlayerName(player) .. " gets a stretcher out from an ambulance [" .. getElementData(veh, "vehicle.id") .. "].")
									else
										destroyElement(stretcher)
										removeElementData(player, "stretcher")
										outputServerLog("[FACTIONS] [CMD/STRETCHER]: " .. getPlayerName(player) .. " puts the stretcher back to the ambulance [" .. getElementData(veh, "vehicle.id") .. "].")
									end
								else
									outputChatbox("Get nearer an ambulance to get a stretcher.", player, 255, 0, 0, false)
								end
							end
						end
					end
				end
			end
		end
	end
)

function removedata()
	if getElementData(source, "stretcher") then
		destroyElement(stretcher)
		removeElementData(source, "stretcher")
	end
end
addEventHandler("onPlayerLogout", root, removedata)
addEventHandler("onPlayerQuit", root, removedata)

addEventHandler("onResourceStop", root,
	function()
		for i,v in ipairs(getElementsByType("player")) do
			if getElementData(v, "stretcher") then
				destroyElement(stretcher)
				removeElementData(v, "stretcher")
			end
		end
	end
)