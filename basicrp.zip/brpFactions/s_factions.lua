--[[
	Basic Roleplay Gamemode
	~ Server-side functions for factions
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Configurations (modifyable)
local lawstartingmoney = 9000000 -- Starting money for law factions (default: $9,000,000)
local medicalstartingmoney = 9000000 -- Starting money for medical factions (default: $9,000,000)
local newsstartingmoney = 1500000 -- Starting money for news factions (default: $1,500,000)
local gangstartingmoney = 100000 -- Starting money for gang factions (default: $100,000)
local mafiastartingmoney = 400000 -- Starting money for mafia factions (default: $400,000)
local otherstartingmoney = 500000 -- Starting money for other factions (default: $500,000)

-- Functions
local types = {law=true, medical=true, news=true, gang=true, mafia=true, other=true}

local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

addEventHandler("onResourceStart", cThisRoot,
	function()
		for i,v in ipairs(getElementsByType("faction")) do
			local fped = createPed(0, 0, 0, 0)
			setElementFrozen(fped, true)
			setElementCollisionsEnabled(fped, false)
			setElementAlpha(fped, 0)
			setElementData(fped, "factions.id", getElementData(v, "id"))
			setElementData(fped, "factions.name", getElementData(v, "name"))
			setElementData(fped, "factions.type", getElementData(v, "type"))
			setElementData(fped, "factions.money", getElementData(v, "money"))
			setElementData(fped, "factions.motd", getElementData(v, "motd"))
		end
		
		outputServerLog("[FACTIONS] [AUTO/SPAWN]: All factions spawned as the resource started.")
	end
)

addEventHandler("onResourceStop", cThisRoot,
	function()
		for vi,vv in ipairs(getElementsByType("ped")) do
			for i,v in ipairs(getElementsByType("faction")) do
				local xml = xmlLoadFile("factions.map")
				local new = xmlFindChild(xml, "faction", 0)
				if getElementData(vv, "factions.id") == xmlNodeGetAttribute(new, "id") then
					local name = getElementData(vv, "factions.name")
					local type = getElementData(vv, "factions.type")
					local money = getElementData(vv, "factions.money")
					local motd = getElementData(vv, "factions.motd")
					xmlNodeSetAttribute(new, "name", name)
					xmlNodeSetAttribute(new, "type", type)
					xmlNodeSetAttribute(new, "money", money)
					xmlNodeSetAttribute(new, "motd", motd)
					xmlSaveFile(xml)
					xmlUnloadFile(xml)
				end
			end
		end
		
		outputServerLog("[FACTIONS] [AUTO/SAVE]: All factions saved as the resource stopped.")
	end
)

addCommandHandler({"createfaction", "makefaction"},
	function(player, cmd, type, ...)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if type and (...) then
				if types[type] then
					local message = table.concat({ ... }, " ")
					if #message > 0 then
						local xml = xmlLoadFile("factions.map")
						local new = xmlCreateChild(xml, "faction")
						local id = math.random(1,99999)
						xmlNodeSetAttribute(new, "id", tonumber(id))
						xmlNodeSetAttribute(new, "name", tostring(message))
						xmlNodeSetAttribute(new, "type", tostring(type))
						
						if type == "law" then
							xmlNodeSetAttribute(new, "money", lawstartingmoney)
							money = lawstartingmoney
						elseif type == "medical" then
							xmlNodeSetAttribute(new, "money", medicalstartingmoney)
							money = medicalstartingmoney
						elseif type == "news" then
							xmlNodeSetAttribute(new, "money", newsstartingmoney)
							money = newsstartingmoney
						elseif type == "gang" then
							xmlNodeSetAttribute(new, "money", gangstartingmoney)
							money = gangstartingmoney
						elseif type == "mafia" then
							xmlNodeSetAttribute(new, "money", mafiastartingmoney)
							money = mafiastartingmoney
						elseif type == "other" then
							xmlNodeSetAttribute(new, "money", otherstartingmoney)
							money = otherstartingmoney
						end
						
						xmlNodeSetAttribute(new, "motd", "Hello world! Edit your MOTD.")
						xmlSaveFile(xml)
						xmlUnloadFile(xml)
						local ped = createPed(0, 0, 0, 0)
						setElementFrozen(ped, true)
						setElementCollisionsEnabled(ped, false)
						setElementAlpha(ped, 0)
						setElementData(ped, "factions.id", tonumber(id))
						setElementData(ped, "factions.name", tostring(message))
						setElementData(ped, "factions.type", tostring(type))
						setElementData(ped, "factions.money", tonumber(money))
						setElementData(ped, "factions.motd", "Hello world! Edit your MOTD.")
						outputChatBox("Faction with name '" .. message .. "' [" .. id .. "] created.", player, 0, 255, 0, false)
						outputServerLog("[FACTIONS] [CMD/CREATEFACTION]: " .. getPlayerName(player) .. " created a faction (" .. message .. " [" .. id .. "]) as '" .. type .. "'.")
						money = nil
					end
				else
					outputChatBox("Syntax: /" .. cmd .. " <type: law, medical, news, gang, mafia, other> <faction name>", player, 220, 220, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <type: law, medical, news, gang, mafia, other> <faction name>", player, 220, 220, 0, false)
			end
		end
	end
)

addCommandHandler("getfactionmoney",
	function(player, cmd, faction)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			local faction = tonumber(faction)
			if faction then
				for i,v in ipairs(getElementsByType("ped")) do
					if faction == tonumber(getElementData(v, "factions.id")) then
						outputChatBox(getElementData(v, "factions.name") .. " has $" .. getElementData(v, "factions.money") .. " stored in their faction bank.", player, 220, 220, 0, false)
						outputServerLog("[FACTIONS] [CMD/GETFACTIONMONEY]: " .. getPlayerName(player) .. " checked " .. getElementData(v, "factions.name") .. "'s faction money ($" .. getElementData(v, "factions.money") .. ").")
					end
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <faction id>", player, 220, 220, 0, false)
			end
		end
	end
)

addCommandHandler("setfactionmoney",
	function(player, cmd, faction, amount)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			local faction = tonumber(faction)
			local amount = tonumber(amount)
			if faction and amount then
				for i,v in ipairs(getElementsByType("ped")) do
					if faction == tonumber(getElementData(v, "factions.id")) then
						setElementData(v, "factions.money", amount)
						outputChatBox(getElementData(v, "factions.name") .. "'s faction money set to $" .. amount .. ".", player, 220, 220, 0, false)
						outputServerLog("[FACTIONS] [CMD/SETFACTIONMONEY]: " .. getPlayerName(player) .. " set " .. getElementData(v, "factions.name") .. "'s faction money to $" .. amount .. ".")
					end
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <faction id> <amount>", player, 220, 220, 0, false)
			end
		end
	end
)

local results = 0 -- Do not change this integer or setting faction will not work

addCommandHandler("setfaction",
	function(player, cmd, name, id)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and id then
				if tonumber(id) then
					local target = exports.brpExports:findPlayer(name, player)
					if target then
						if tonumber(id) > 0 then
							for i,v in ipairs(getElementsByType("ped")) do
								if tonumber(getElementData(v, "factions.id")) == tonumber(id) then
									if tonumber(id) ~= exports.brpExports:getPlayerFaction(target) then
										setElementData(target, "factions.player", tonumber(id))
										setElementData(target, "factions.fplayer", getElementData(v, "factions.name"))
										setElementData(target, "factions.leader", "No")
										setAccountData(getPlayerAccount(target), "basicrp.faction", tonumber(id))
										setAccountData(getPlayerAccount(target), "basicrp.fname", getElementData(v, "factions.name"))
										outputChatBox(getPlayerName(target) .. " now belongs to a faction '" .. getElementData(v, "factions.name") .. "' [" .. id .. "].", player, 220, 220, 0, false)
										outputServerLog("[FACTIONS] [CMD/SETFACTION]: " .. getPlayerName(target) .. " joined a faction: set ([" .. getElementData(target, "factions.player") .. "] " .. getElementData(target, "factions.fplayer") .. ").")
										results = 1
										break
									else
										outputChatBox(getPlayerName(target) .. " already belongs to that faction.", player, 255, 0, 0, false)
									end
								end
							end
							
							if results == 0 then
								outputChatBox("No such faction exists.", player, 255, 0, 0, false)
							else
								results = 0
							end
						else
							if exports.brpExports:isPlayerInFaction(target) then
								outputServerLog("[FACTIONS] [CMD/SETFACTION]: " .. getPlayerName(target) .. " left a faction: reseted ([" .. getElementData(target, "factions.player") .. "] " .. getElementData(target, "factions.fplayer") .. ").")
								setElementData(target, "factions.player", 0)
								setElementData(target, "factions.fplayer", "false")
								setElementData(target, "factions.leader", "No")
								outputChatBox(getPlayerName(target) .. " does no longer belong to any faction.", player, 220, 220, 0, false)
							else
								outputChatBox(getPlayerName(target) .. " isn't in any faction at the moment.", player, 255, 0, 0, false)
							end
						end
					else
						outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Faction ID value needs to be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <faction id>", player, 220, 220, 0, false)
			end
		end
	end
)

addCommandHandler("setfactionleader",
	function(player, cmd, name, level)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and level then
				if tonumber(level) then
					if tonumber(level) == 0 or tonumber(level) == 1 then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							if tonumber(level) == 0 then
								setElementData(target, "factions.leader", "No")
								outputChatBox("You've removed " .. getPlayerName(target) .. "'s faction leader level.", player, 220, 220, 0, false)
								outputChatBox("You're no more a faction leader.", target, 220, 220, 0, false)
								outputServerLog("[FACTIONS] [CMD/SETFACTIONLEADER]: " .. getPlayerName(target) .. " is no longer a faction leader ([" .. getElementData(target, "factions.player") .. "] " .. getElementData(target, "factions.fplayer") .. ").")
							else
								setElementData(target, "factions.leader", "Yes")
								outputChatBox("You've set " .. getPlayerName(target) .. " as a faction leader.", player, 220, 220, 0, false)
								outputChatBox("You're now a faction leader.", target, 220, 220, 0, false)
								outputServerLog("[FACTIONS] [CMD/SETFACTIONLEADER]: " .. getPlayerName(target) .. " is now a faction leader ([" .. getElementData(target, "factions.player") .. "] " .. getElementData(target, "factions.fplayer") .. ").")
							end
						else
							outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
						end
					else
						outputChatBox("Invalid leader level (0 = member, 1 = leader)", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Leader level needs to be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <level: 0 = member, 1 = leader>", player, 220, 220, 0, false)
			end
		end
	end
)

-- Do NOT change the integers at any time
local frespawned = 0
local notfrespawned = 0

addCommandHandler({"factionrespawn", "respawnfaction", "respawnfactionvehicles", "respawnfactionvehs", "respawnfactioncars"},
	function(player, cmd, id)
		if exports.brpExports:isPlayerFullAdmin(player) then
			local id = tonumber(id)
			if id then
				for ii,vv in ipairs(getElementsByType("ped")) do
					if tonumber(getElementData(vv, "factions.id")) == tonumber(id) then
						for i,v in ipairs(getElementsByType("vehicle")) do
							if exports.brpExports:getVehicleFaction(v) == exports.brpExports:getPlayerFaction(player) then
								if exports.brpExports:isVehicleEmpty(v) then
									respawnVehicle(v)
									if frespawned == 0 then
										frespawned = 1
									else
										frespawned = frespawned + 1
									end
								else
									if notfrespawned == 0 then
										notfrespawned = 1
									else
										notfrespawned = notfrespawned + 1
									end
								end
							end
						end
						for i,v in ipairs(getElementsByType("player")) do
							if exports.brpExports:getPlayerFaction(player) == exports.brpExports:getPlayerFaction(v) then
								outputChatBox(getPlayerName(player) .. " respawned " .. frespawned .. " unoccupied faction vehicles (" .. notfrespawned .. " occupied).", v, 220, 220, 0, false)
							end
						end
						outputServerLog("[FACTIONS] [CMD/FACTIONRESPAWN]: " .. getPlayerName(player) .. " (admin) respawned faction vehicles ([" .. id .. "] " .. getElementData(vv, "factions.name") .. ").")
						frespawned = 0
						break
					end
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <faction id>", player, 220, 220, 0, false)
			end
		end
	end
)

addEvent("onVehicleFactionRespawn", true)
addEventHandler("onVehicleFactionRespawn", cRoot,
	function()
		for i,v in ipairs(getElementsByType("vehicle")) do
			if exports.brpExports:getVehicleFaction(v) == exports.brpExports:getPlayerFaction(source) then
				if exports.brpExports:isVehicleEmpty(v) then
					respawnVehicle(v)
					if frespawned == 0 then
						frespawned = 1
					else
						frespawned = frespawned + 1
					end
				else
					if notfrespawned == 0 then
						notfrespawned = 1
					else
						notfrespawned = notfrespawned + 1
					end
				end
			end
		end
		for i,v in ipairs(getElementsByType("player")) do
			if exports.brpExports:getPlayerFaction(source) == exports.brpExports:getPlayerFaction(v) then
				outputChatBox(getPlayerName(source) .. " respawned " .. frespawned .. " unoccupied faction vehicles (" .. notfrespawned .. " occupied).", v, 220, 220, 0, false)
			end
		end
		outputServerLog("[FACTIONS] [PLA/RESPAWNFACTIONVEHICLES]: " .. getPlayerName(source) .. " respawned faction vehicles ([" .. getElementData(source, "factions.player") .. "] " .. getElementData(source, "factions.fplayer") .. ").")
		frespawned = 0
	end
)

addEvent("onPlayerFactionKick", true)
addEventHandler("onPlayerFactionKick", cRoot,
	function(name)
		local target = exports.brpExports:findPlayer(name, source)
		if target then
			if exports.brpExports:getPlayerFaction(source) == exports.brpExports:getPlayerFaction(target) then
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:getPlayerFaction(source) == exports.brpExports:getPlayerFaction(v) then
						outputChatBox(getPlayerName(source) .. " kicked " .. getPlayerName(target) .. " from the faction.", v, 220, 220, 0, false)
					end
				end
				outputChatBox("You no longer belong to the faction.", target, 255, 255, 255, false)
				outputServerLog("[FACTIONS] [PLA/KICKPLAYER]: " .. getPlayerName(target) .. " left a faction: kick ([" .. getElementData(target, "factions.player") .. "] " .. getElementData(target, "factions.fplayer") .. ").")
				setElementData(target, "factions.player", 0)
				setElementData(target, "factions.fplayer", "false")
				setElementData(target, "factions.leader", "No")
				triggerClientEvent("onTrueFactionKick", target, target)
			else
				outputChatBox("Player is not in your faction.", source, 255, 0, 0, false)
			end
		else
			outputChatBox("No players or multiple were found.", source, 255, 0, 0, false)
		end
	end
)

addEvent("onPlayerFactionInvite", true)
addEventHandler("onPlayerFactionInvite", cRoot,
	function(name)
		local target = exports.brpExports:findPlayer(name, source)
		if target then
			if not exports.brpExports:isPlayerInFaction(target) then
				outputChatBox(getPlayerName(target) .. " invited to the faction.", source, 0, 255, 0, false)
				outputChatBox("You now belong to a faction, press F3 for more details.", target, 0, 255, 0, false)
				setElementData(target, "factions.player", getElementData(source, "factions.player"))
				setElementData(target, "faction.fplayer", getElementData(source, "factions.fplayer"))
				setElementData(target, "factions.leader", "No")
				outputServerLog("[FACTIONS] [PLA/INVITEPLAYER]: " .. getPlayerName(target) .. " joined a faction: invite ([" .. getElementData(target, "factions.player") .. "] " .. getElementData(target, "factions.fplayer") .. ").")
			else
				outputChatBox("Player is in a faction already - cannot invite.", source, 255, 0, 0, false)
			end
		else
			outputChatBox("No players or multiple were found.", source, 255, 0, 0, false)
		end
	end
)

addEvent("onPlayerFactionLeave", true)
addEventHandler("onPlayerFactionLeave", cRoot,
	function()
		for i,v in ipairs(getElementsByType("player")) do
			if exports.brpExports:getPlayerFaction(v) == exports.brpExports:getPlayerFaction(source) then
				outputChatBox(getPlayerName(source) .. " left the faction.", v, 255, 255, 255, false)
			end
		end
		outputServerLog("[FACTIONS] [CMD/LEAVEFACTION]: " .. getPlayerName(source) .. " left a faction: own decision ([" .. getElementData(source, "factions.player") .. "] " .. getElementData(source, "factions.fplayer") .. ").")
		setElementData(source, "factions.player", 0)
		setElementData(source, "factions.fplayer", "false")
		setElementData(source, "factions.leader", "No")
	end
)

addCommandHandler("leavefaction",
	function(player, cmd)
		if exports.brpExports:isPlayerInFaction(player) then
			triggerEvent("onPlayerFactionLeave", player)
		end
	end
)