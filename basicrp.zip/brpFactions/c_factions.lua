--[[
	Basic Roleplay Gamemode
	~ Client-side functions for factions
	
	Created by Socialz
]]--

--[[
	Notes:
	Hey there. I have disabled the promote/demote/ranks/players feature for now and they will be up and running in the upcoming version.
	-Socialz 17/05/2012 20:14:43 GMT +02
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)
local screenx, screeny = guiGetScreenSize()

-- Functions
function getFactionMoney()
	for i,v in ipairs(getElementsByType("ped")) do
		if tonumber(getElementData(v, "factions.id")) == tonumber(getElementData(localPlayer, "factions.player")) then
			return tonumber(getElementData(v, "factions.money"))
		end
	end
end

function startMenu()
	if getElementData(localPlayer, "factions.fplayer") ~= "false" then
		if isElement(factions_window) then
			destroyElement(factions_window)
			guiSetInputEnabled(false)
			showCursor(false)
			
			if isElement(factions_motdwindow) then
				destroyElement(factions_motdwindow)
			end
			
			if isElement(factions_kickwindow) then
				destroyElement(factions_kickwindow)
			end
			
			if isElement(factions_invitewindow) then
				destroyElement(factions_invitewindow)
			end
		else
			factions_window = guiCreateWindow((screenx - 900) / 2, (screeny - 400) / 2, 812, 364, "Faction: " .. tostring(getElementData(localPlayer, "factions.fplayer")), false)
			
			guiWindowSetMovable(factions_window, true)
			guiWindowSetSizable(factions_window, false)
			guiSetInputEnabled(true)
			showCursor(true)
			
			if getElementData(localPlayer, "factions.leader") == "Yes" then
				-- Kick a player
				factions_kick = guiCreateButton(637, 25, 165, 31, "Kick Player", false, factions_window)
				guiSetFont(factions_kick, "clear-normal")
				
				-- Invite a player
				factions_invite = guiCreateButton(637, 64, 165, 31, "Invite Player", false, factions_window)
				guiSetFont(factions_invite, "clear-normal")
				
				-- Respawn faction vehicles
				factions_respawn = guiCreateButton(637, 103, 165, 31, "Respawn Vehicles", false, factions_window)
				guiSetFont(factions_respawn, "clear-normal")
				
				-- Edit faction MOTD
				factions_motd = guiCreateButton(637, 142, 165, 31, "Edit MOTD", false, factions_window)
				guiSetFont(factions_motd, "clear-normal")
				
				-- Edit faction ranks [feature disabled at v1.0]
				factions_ranks = guiCreateButton(637, 181, 165, 31, "Edit Ranks", false, factions_window)
				guiSetFont(factions_ranks, "clear-normal")
				guiGetEnabled(factions_ranks, false)
				
				-- Promote a player [feature disabled at v1.0]
				factions_promote = guiCreateButton(637, 220, 165, 31, "Promote Player", false, factions_window)
				guiSetFont(factions_promote, "clear-normal")
				guiGetEnabled(factions_promote, false)
				
				-- Demote a player [feature disabled at v1.0]
				factions_demote = guiCreateButton(637, 259, 165, 31, "Demote Player", false, factions_window)
				guiSetFont(factions_demote, "clear-normal")
				guiGetEnabled(factions_demote, false)
				
				addEventHandler("onClientGUIClick", factions_kick, openFactionKick, false)
				addEventHandler("onClientGUIClick", factions_invite, openFactionInvite, false)
				addEventHandler("onClientGUIClick", factions_respawn, respawnFactionVehicles, false)
				addEventHandler("onClientGUIClick", factions_motd, openFactionMOTD, false)
			end
				
			factions_tabpanel = guiCreateTabPanel(13, 25, 613, 305, false, factions_window)
			factions_tab = guiCreateTab("Main Menu", factions_tabpanel)
			
			-- [feature disabled at v1.0]
			factions_memo = guiCreateMemo(10, 12, 593, 259, "This feature has been disabled.\n\nFaction bank: $" .. getFactionMoney() .. ".", false, factions_tab)
			guiMemoSetReadOnly(factions_memo, true)
			
			factions_close = guiCreateButton(637, 298, 165, 31, "Close Window", false, factions_window)
			guiSetFont(factions_close, "clear-normal")
			
			addEventHandler("onClientGUIClick", factions_close, closeWindow, false)
			
			for i,v in ipairs(getElementsByType("ped")) do
				if getElementData(v, "factions.name") == getElementData(localPlayer, "factions.fplayer") then
					factions_motdlabel = guiCreateLabel(12, 339, 790, 15, "MOTD: " .. getElementData(v, "factions.motd"), false, factions_window)
					guiSetFont(factions_motdlabel, "default-bold-small")
				end
			end
		end
	else
		outputChatBox("You're not in a faction.", 255, 0, 0, false)
	end
end

function openFactionKick()
	if isElement(factions_kickwindow) then
		destroyElement(factions_kickwindow)
	else
		factions_kickwindow = guiCreateWindow((screenx - 300) / 2, (screeny - 300) / 2, 235, 171, "Faction: Kick Player", false)
		guiWindowSetMovable(factions_kickwindow, true)
		guiWindowSetSizable(factions_kickwindow, false)
		
		factions_kickedit = guiCreateEdit(11, 30, 212, 38, "", false, factions_kickwindow)
		
		factions_kickkick = guiCreateButton(16, 75, 201, 37, "Kick Player", false, factions_kickwindow)
		guiSetFont(factions_kickkick, "clear-normal")
		
		factions_kickclose = guiCreateButton(16, 120, 201, 37, "Cancel", false, factions_kickwindow)
		guiSetFont(factions_kickclose, "clear-normal")
	
		addEventHandler("onClientGUIClick", factions_kickkick, kickPlayerFromFaction, false)
		addEventHandler("onClientGUIClick", factions_kickclose, exitKickWindow, false)
	end
end

function openFactionInvite()
	if isElement(factions_invitewindow) then
		destroyElement(factions_invitewindow)
	else
		factions_invitewindow = guiCreateWindow((screenx - 300) / 2, (screeny - 300) / 2, 235, 171, "Faction: Invite Player", false)
		guiWindowSetMovable(factions_invitewindow, true)
		guiWindowSetSizable(factions_invitewindow, false)
		
		factions_inviteedit = guiCreateEdit(11, 30, 212, 38, "", false, factions_invitewindow)
		
		factions_inviteinvite = guiCreateButton(16, 75, 201, 37, "Invite Player", false, factions_invitewindow)
		guiSetFont(factions_inviteinvite, "clear-normal")
		
		factions_inviteclose = guiCreateButton(16, 120, 201, 37, "Cancel", false, factions_invitewindow)
		guiSetFont(factions_inviteclose, "clear-normal")
		
		addEventHandler("onClientGUIClick", factions_inviteinvite, invitePlayerToFaction, false)
		addEventHandler("onClientGUIClick", factions_inviteclose, exitInviteWindow, false)
	end
end

function openFactionMOTD()
	if isElement(factions_motdwindow) then
		destroyElement(factions_motdwindow)
	else
		factions_motdwindow = guiCreateWindow((screenx - 600) / 2, (screeny - 300) / 2, 491, 169, "Faction: Edit MOTD", false)
		
		factions_motdmotd = guiCreateEdit(11, 28, 468, 44, "", false, factions_motdwindow)
		for i,v in ipairs(getElementsByType("ped")) do
			if getElementData(v, "factions.name") == getElementData(localPlayer, "factions.fplayer") then
				guiSetText(factions_motdmotd, getElementData(v, "factions.motd"))
			end
		end
		factions_motdedit = guiCreateButton(12, 78, 468, 35, "Edit MOTD", false, factions_motdwindow)
		guiSetFont(factions_motdedit, "clear-normal")
		
		factions_motdclose = guiCreateButton(12, 120, 468, 35, "Cancel", false, factions_motdwindow)
		guiSetFont(factions_motdclose, "clear-normal")

		addEventHandler("onClientGUIClick", factions_motdedit, changeFactionMOTD, false)
		addEventHandler("onClientGUIClick", factions_motdclose, exitMOTDWindow, false)
	end
end

function openFactionRanks()
	if isElement(factions_rankswindow) then
		destroyElement(factions_rankswindow)
	else
		factions_rankswindow = guiCreateWindow((screenx - 849) / 2, (screeny - 370) / 2, 237, 267, "Faction: Edit Ranks", false)
		
		factions_ranksplayer = guiCreateEdit(16, 49, 204, 40, "", false, factions_rankswindow)
		factions_ranksplayerlabel = guiCreateLabel(18, 29, 204, 16, "Playername:", false, factions_rankswindow)
		guiSetFont(factions_ranksplayerlabel, "default-bold-small")
		
		factions_ranksrank = guiCreateEdit(16, 120, 204, 40, "", false, factions_rankswindow)
		factions_ranksranklabel = guiCreateLabel(18, 100, 204, 16, "Rank:", false, factions_rankswindow)
		guiSetFont(factions_ranksranklabel, "default-bold-small")
		
		factions_ranksedit = guiCreateButton(17, 171, 203, 36, "Edit Rank", false, factions_rankswindow)
		guiSetFont(factions_ranksedit, "clear-normal")
		
		--factions_rankscloselabel = guiCreateLabel(230, 119, 164, 39, "", false, factions_rankswindow)
		factions_ranksclose = guiCreateButton(17, 215, 203, 36, "Cancel", false, factions_rankswindow)
		guiSetFont(factions_ranksclose, "clear-normal")
	end
end

function invitePlayerToFaction()
	local text = guiGetText(factions_inviteedit)
	if #text > 0 then
		triggerServerEvent("onPlayerFactionInvite", localPlayer, text)
	else
		outputChatBox("You left the box empty - type something in.", 255, 0, 0, false)
	end
end

function kickPlayerFromFaction()
	local text = guiGetText(factions_kickedit)
	if #text > 0 then
		triggerServerEvent("onPlayerFactionKick", localPlayer, text)
	else
		outputChatBox("You left the box empty - type something in.", 255, 0, 0, false)
	end
end

function changeFactionMOTD()
	local text = guiGetText(factions_motdmotd)
	if #text > 0 then
		for i,v in ipairs(getElementsByType("ped")) do
			if getElementData(v, "factions.name") == getElementData(localPlayer, "factions.fplayer") then
				setElementData(v, "factions.motd", tostring(text))
			end
		end
		outputChatBox("MOTD successfully edited.", 220, 220, 0, false)
		destroyElement(factions_motdwindow)
		destroyElement(factions_window)
		startMenu()
	else
		outputChatBox("You left the box empty - type something in.", 255, 0, 0, false)
	end
end

local cooldown = 0 -- Do not change this integer

function respawnFactionVehicles()
	if cooldown == 0 then
		triggerServerEvent("onVehicleFactionRespawn", localPlayer)
		cooldown = 1
		setTimer(function()
			cooldown = 0
		end, 600000, 1)
	else
		outputChatBox("Please wait before respawning vehicles again.", 255, 0, 0, false)
	end
end

addEvent("onTrueFactionKick", true)
addEventHandler("onTrueFactionKick", cRoot,
	function(player)
		if isElement(factions_window) then
			destroyElement(factions_window)
			guiSetInputEnabled(false)
			showCursor(false)
			
			if isElement(factions_motdwindow) then
				destroyElement(factions_motdwindow)
			end
			
			if isElement(factions_kickwindow) then
				destroyElement(factions_kickwindow)
			end
			
			if isElement(factions_invitewindow) then
				destroyElement(factions_invitewindow)
			end
		end
	end
)

function closeWindow()
	startMenu()
end

function exitInviteWindow()
	if isElement(factions_invitewindow) then
		destroyElement(factions_invitewindow)
	end
end

function exitMOTDWindow()
	if isElement(factions_motdwindow) then
		destroyElement(factions_motdwindow)
	end
end

function exitKickWindow()
	if isElement(factions_kickwindow) then
		destroyElement(factions_kickwindow)
	end
end

addEventHandler("onClientResourceStart", cThisRoot,
	function()
		bindKey("F3", "down", startMenu)
	end
)