--[[
	Basic Roleplay Gamemode
	~ Server-side functions for the police
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Configurations (modifyable)
local jails = {
	-- ID : x position, y position, z position, interior, dimension, radius
	[1] = {1849.47, -1453.7, 13.39, 0, 0, 5}
}

-- Releasepoint's x, y, z, interior and dimension positions
local releasepoint_x = 0
local releasepoint_y = 0
local releasepoint_z = 0
local releasepoint_interior = 0
local releasepoint_dimension = 0

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

-- ~ [CUFF, HANDCUFF, RESTRAIN] ~ --
addCommandHandler({"cuff", "handcuff", "restrain"},
	function(player, cmd, name)
		for i,v in ipairs(getElementsByType("ped")) do
			if tonumber(getElementData(player, "factions.player")) == tonumber(getElementData(v, "factions.id")) then
				if exports.brpExports:getFactionType(v) == "law" then
					if name then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							if player ~= target then
								local x, y, z = getElementPosition(player)
								if exports.brpExports:isElementInRangeOfPoint(target, x, y, z, 5) then
									if not getElementData(target, "police.cuffed") then
										toggleControl(target, "fire", false)
										toggleControl(target, "next_weapon", false)
										toggleControl(target, "previous_weapon", false)
										toggleControl(target, "sprint", false)
										toggleControl(target, "aim_weapon", false)
										toggleControl(target, "handbrake", false)
										toggleControl(target, "vehicle_fire", false)
										toggleControl(target, "vehicle_secondary_fire", false)
										toggleControl(target, "vehicle_left", false)
										toggleControl(target, "vehicle_right", false)
										toggleControl(target, "steer_forward", false)
										toggleControl(target, "steer_back", false)
										setElementData(target, "police.cuffed", true)
										outputChatBox("You are now restraining " .. getPlayerName(target) .. ".", player, 255, 255, 255, false)
										outputChatBox("You are now restrained by " .. getPlayerName(target) .. ".", target, 255, 255, 255, false)
										outputServerLog("[FACTIONS] [CMD/CUFF]: " .. getPlayerName(player) .. " is now restraining " .. getPlayerName(target) .. ".")
									else
										outputChatBox("That player is already handcuffed.", player, 255, 0, 0, false)
									end
								else
									outputChatBox("You are too far from the target.", player, 255, 0, 0, false)
								end
							else
								outputChatBox("You cannot cuff yourself.", player, 255, 0, 0, false)
							end
						else
							outputChatBox("Couldn't find such player.", player, 255, 0, 0, false)
						end
					else
						outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
					end
				end
			end
		end
	end
)

-- ~ [UNCUFF, UNHANDCUFF, UNRESTRAIN] ~ --
addCommandHandler({"uncuff", "unhandcuff", "unrestrain"},
	function(player, cmd, name)
		for i,v in ipairs(getElementsByType("ped")) do
			if tonumber(getElementData(player, "factions.player")) == tonumber(getElementData(v, "factions.id")) then
				if exports.brpExports:getFactionType(v) == "law" then
					if name then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							if player ~= target then
								local x, y, z = getElementPosition(player)
								if exports.brpExports:isElementInRangeOfPoint(target, x, y, z, 5) then
									if getElementData(target, "police.cuffed") then
										toggleControl(target, "fire", true)
										toggleControl(target, "next_weapon", true)
										toggleControl(target, "previous_weapon", true)
										toggleControl(target, "sprint", true)
										toggleControl(target, "aim_weapon", true)
										toggleControl(target, "handbrake", true)
										toggleControl(target, "vehicle_fire", true)
										toggleControl(target, "vehicle_secondary_fire", true)
										toggleControl(target, "vehicle_left", true)
										toggleControl(target, "vehicle_right", true)
										toggleControl(target, "steer_forward", true)
										toggleControl(target, "steer_back", true)
										removeElementData(target, "police.cuffed")
										outputChatBox("You unrestrained " .. getPlayerName(target) .. ".", player, 255, 255, 255, false)
										outputChatBox("You are unrestrained by " .. getPlayerName(target) .. ".", target, 255, 255, 255, false)
										outputServerLog("[FACTIONS] [CMD/UNCUFF]: " .. getPlayerName(player) .. " now unrestrained " .. getPlayerName(target) .. ".")
									else
										outputChatBox("That player is not handcuffed.", player, 255, 0, 0, false)
									end
								else
									outputChatBox("You are too far from the target.", player, 255, 0, 0, false)
								end
							else
								outputChatBox("You cannot uncuff yourself.", player, 255, 0, 0, false)
							end
						else
							outputChatBox("Couldn't find such player.", player, 255, 0, 0, false)
						end
					else
						outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
					end
				end
			end
		end
	end
)

-- ~ [AUNCUFF, AUNHANDCUFF, AUNRESTRAIN] ~ --
addCommandHandler({"auncuff", "aunhandcuff", "aunrestrain"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if getElementData(target, "police.cuffed") then
						toggleControl(target, "fire", true)
						toggleControl(target, "next_weapon", true)
						toggleControl(target, "previous_weapon", true)
						toggleControl(target, "sprint", true)
						toggleControl(target, "aim_weapon", true)
						toggleControl(target, "handbrake", true)
						toggleControl(target, "vehicle_fire", true)
						toggleControl(target, "vehicle_secondary_fire", true)
						toggleControl(target, "vehicle_left", true)
						toggleControl(target, "vehicle_right", true)
						toggleControl(target, "steer_forward", true)
						toggleControl(target, "steer_back", true)
						removeElementData(target, "police.cuffed")
						outputChatBox("You unrestrained " .. getPlayerName(target) .. ".", player, 255, 255, 255, false)
						outputChatBox("You are unrestrained by " .. getPlayerName(target) .. ".", target, 255, 255, 255, false)
						outputServerLog("[FACTIONS] [CMD/UNCUFF]: " .. getPlayerName(player) .. " now unrestrained " .. getPlayerName(target) .. ".")
					else
						outputChatBox("That player is not handcuffed.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Couldn't find such player.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

addCommandHandler({"jail", "arrest"},
	function(player, cmd, name, time, fine, ...)
		for i,v in ipairs(getElementsByType("ped")) do
			if tonumber(getElementData(player, "factions.player")) == tonumber(getElementData(v, "factions.id")) then
				if exports.brpExports:getFactionType(v) == "law" then
					local time = tonumber(time)
					local fine = tonumber(fine)
					if name and time and fine and (...) then
						if time > 0 and time <= 180 and fine >= 0 and fine <= 20000 then
							local reason = table.concat({ ... }, " ")
							if #reason > 0 then
								local target = exports.brpExports:findPlayer(name, player)
								if target then
									--if player ~= target then
										local x, y, z = getElementPosition(player)
										if exports.brpExports:isElementInRangeOfPoint(target, x, y, z, 5) then
											if not getElementData(target, "police.arrested") then
												for index,jail in ipairs(jails) do
													if exports.brpExports:isElementInRangeOfPoint(player, jails[index][1], jails[index][2], jails[index][3], jails[index][6]) and getElementInterior(player, jails[index][4]) and getElementDimension(player, jails[index][5]) and exports.brpExports:isElementInRangeOfPoint(target, jails[index][1], jails[index][2], jails[index][3], jails[index][6]) and getElementInterior(target, jails[index][4]) and getElementDimension(target, jails[index][5]) then
														setElementPosition(target, jails[index][1], jails[index][2], jails[index][3])
														setElementInterior(target, jails[index][4])
														setElementDimension(target, jails[index][5])
														outputChatBox("You arrested " .. getPlayerName(target) .. " for " .. time .. " minutes and fined for $" .. fine .. ".", player, 120, 120, 255, false)
														outputChatBox("You were arrested by " .. getPlayerName(player) .. " for " .. time .. " minutes and fined for $" .. fine .. ".", target, 120, 120, 255, false)
														outputServerLog("[FACTIONS] [CMD/JAIL]: " .. getPlayerName(player) .. " arrested " .. getPlayerName(target) .. " for " .. time .. " minutes and fined for $" .. fine .. ".")
														setElementData(target, "police.arrested", true)
														
														if getElementData(target, "police.cuffed") then
															toggleControl(target, "fire", true)
															toggleControl(target, "next_weapon", true)
															toggleControl(target, "previous_weapon", true)
															toggleControl(target, "sprint", true)
															toggleControl(target, "aim_weapon", true)
															toggleControl(target, "handbrake", true)
															toggleControl(target, "vehicle_fire", true)
															toggleControl(target, "vehicle_secondary_fire", true)
															toggleControl(target, "vehicle_left", true)
															toggleControl(target, "vehicle_right", true)
															toggleControl(target, "steer_forward", true)
															toggleControl(target, "steer_back", true)
															removeElementData(target, "police.cuffed")
														end
														
														jailed = setTimer(function(target)
															if getElementData(target, "police.arrested") then
																setElementPosition(target, releasepoint_x, releasepoint_y, releasepoint_z)
																setElementInterior(target, releasepoint_interior)
																setElementDimension(target, releasepoint_dimension)
																outputChatBox("Your time has been served - behave from now on.", target, 120, 120, 255, false)
																outputServerLog("[FACTIONS] [AUTO/RELEASE]: " .. getPlayerName(target) .. " was released from jail automatically.")
																removeElementData(target, "police.arrested")
															end
														end, time * 60000, 1, target)
													end
												end
											else
												outputChatBox("That player is already arrested.", player, 255, 0, 0, false)
											end
										else
											outputChatBox("You are too far from the target.", player, 255, 0, 0, false)
										end
									--else
									--	outputChatBox("You cannot arrest yourself.", player, 255, 0, 0, false)
									--end
								else
									outputChatBox("Couldn't find such player.", player, 255, 0, 0, false)
								end
							else
								outputChatBox("Syntax: /" .. cmd .. " <player> <time: 1-180 minutes> <fine: 0-20000> <reason>", player, 220, 220, 0, false)
							end
						else
							outputChatBox("Syntax: /" .. cmd .. " <player> <time: 1-180 minutes> <fine: 0-20000> <reason>", player, 220, 220, 0, false)
						end
					else
						outputChatBox("Syntax: /" .. cmd .. " <player> <time: 1-180 minutes> <fine: 0-20000> <reason>", player, 220, 220, 0, false)
					end
				end
			end
		end
	end
)

addCommandHandler({"release", "unjail"},
	function(player, cmd, name)
		for i,v in ipairs(getElementsByType("ped")) do
			if tonumber(getElementData(player, "factions.player")) == tonumber(getElementData(v, "factions.id")) then
				if exports.brpExports:getFactionType(v) == "law" then
					if name then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							--if player ~= target then
								if getElementData(target, "police.arrested") then
									if getElementData(target, "police.arrested") then
										setElementPosition(target, releasepoint_x, releasepoint_y, releasepoint_z)
										setElementInterior(target, releasepoint_interior)
										setElementDimension(target, releasepoint_dimension)
										outputChatBox("Your time has been served - behave from now on.", target, 120, 120, 255, false)
										outputServerLog("[FACTIONS] [CMD/RELEASE]: " .. getPlayerName(target) .. " was released from jail by " .. getPlayerName(player) .. ".")
										removeElementData(target, "police.arrested")
										if isTimer(jailed) then
											killTimer(jailed)
										end
									--else
									--	outputChatBox("You cannot release yourself.", player, 255, 0, 0, false)
									--end
								else
									outputChatBox("Couldn't find such player.", player, 255, 0, 0, false)
								end
							else
								outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
							end
						else
							outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
						end
					else
						outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
					end
				end
			end
		end
	end
)

function saveArrestsCuffs()
	local account = getPlayerAccount(source)
	if isGuestAccount(account) then return end
	if getElementData(source, "police.cuffed") then
		setAccountData(account, "basicrp.cuffed", true)
	else
		setAccountData(account, "basicrp.cuffed", false)
	end
	
	if getElementData(source, "police.arrested") then
		local remaining, executesRemaining, totalExecutes = getTimerDetails(jailed)
		setAccountData(account, "basicrp.arrested", true)
		setAccountData(account, "basicrp.arrested-remainingtime", remaining)
	else
		setAccountData(account, "basicrp.arrested", false)
		setAccountData(account, "basicrp.arrested-remainingtime", 0)
	end
end
addEventHandler("onPlayerQuit", cRoot, saveArrestsCuffs)
addEventHandler("onPlayerLogout", cRoot, saveArrestsCuffs)