--[[
	Basic Roleplay Gamemode
	~ Server-side functions for fuel
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
addEventHandler("onVehicleEnter", cRoot,
	function(player, seat, jacked)
		if seat == 0 then
			fuel = getElementData(source, "vehicle.fuel")
			fuelDisplay = textCreateDisplay()
			textDisplayAddObserver(fuelDisplay, player)
			fuelAmount = textCreateTextItem("Fuel: " .. fuel .. "%", 0.996, 0.99, "high", 255, 255, 255, 110, 1.0, "right", "bottom")
			textDisplayAddText(fuelDisplay, fuelAmount)
			timer = setTimer(updatetext, 1000, 0)
		end
	end
)

function updatetext()
	for i,v in ipairs(getElementsByType("player")) do
		local vehicle = getPedOccupiedVehicle(v)
		if vehicle then
			if getVehicleController(vehicle) == v then
				local fuel = getElementData(vehicle, "vehicle.fuel")
				if fuelAmount then
					textItemSetText(fuelAmount, "Fuel: " .. fuel .. "%")
				end
			end
		end
	end
end

addEventHandler("onVehicleStartExit", cRoot,
	function(player, seat, jacked, door)
		if seat == 0 and not isVehicleLocked(source) then
			if fuelAmount then
				textDestroyTextItem(fuelAmount)
				textDisplayRemoveObserver(fuelDisplay, player)
				textDestroyDisplay(fuelDisplay)
				if isTimer(timer) then
					killTimer(timer)
				end
			end
		end
	end
)

function fuelcounter()
	for i,v in ipairs(getElementsByType("vehicle")) do
		if tonumber(getElementData(v, "vehicle.fuel")) > 0 then
			if getVehicleEngineState(v) == true then
				setElementData(v, "vehicle.fuel", tonumber(getElementData(v, "vehicle.fuel")) - 1)
			end
		else
			if getVehicleEngineState(v) == true then
				setVehicleEngineState(v, false)
				setElementData(v, "vehicle.engine", 0)
			end
		end
	end
end
setTimer(fuelcounter, 300000, 0)