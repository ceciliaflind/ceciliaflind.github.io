--[[
	Basic Roleplay Gamemode
	~ Client-side functions for vehicles
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local sounds = {}

addEvent("startSiren", true)
addEventHandler("startSiren", cRoot,
	function(vehicle)
		local x, y, z = getElementPosition(vehicle)
		local siren = playSound3D("siren.wav", x, y, z, true)
		attachElements(siren, vehicle)
		sounds[vehicle] = siren
		setSoundVolume(siren, 0.5)
		setSoundMaxDistance(siren, 80)
		setElementData(siren, "siren", true)
	end
)

addEvent("stopSiren", true)
addEventHandler("stopSiren", cRoot,
	function(vehicle)
		local siren = sounds[vehicle]
		stopSound(siren)
	end
)

local heli = nil

function updateRotor()
	if isElement(heli) then
		if not getVehicleEngineState(heli) and getHelicopterRotorSpeed(heli) > 0 then
			local new = getHelicopterRotorSpeed(heli) - 0.0012
			setHelicopterRotorSpeed(heli, math.max(0, new))
		end
	else
		disableRotorUpdate()
	end
end

function disableRotorUpdate()
	if heli then
		heli = nil
		removeEventHandler("onClientPlayerVehicleExit", localPlayer, disableRotorUpdate)
		removeEventHandler("onClientPreRender", cRoot, updateRotor)
	end
end

function enableRotorUpdate(theVehicle)
	if getVehicleType(theVehicle) == "Helicopter" then
		heli = theVehicle
		
		addEventHandler("onClientPlayerVehicleExit", localPlayer, disableRotorUpdate)
		addEventHandler("onClientPreRender", cRoot, updateRotor)
	end
end
addEventHandler("onClientPlayerVehicleEnter", localPlayer, enableRotorUpdate)