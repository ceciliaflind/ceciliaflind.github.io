--[[
	Basic Roleplay Gamemode
	~ Server-side functions for vehicles
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Configurations (modifyable)
local rangeOfRadar = 50 -- Speed camera range
local policeVehicles = {[523] = true, [598] = true, [596] = true, [597] = true, [599] = true} -- Police vehicles
local governmentVehicles = {[523] = true, [598] = true, [596] = true, [597] = true, [599] = true, [416] = true, [490] = true, [427] = true, [407] = true, [544] = true} -- Government vehicles

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

-- ~ [SIREN] ~ --
function siren(player, cmd)
	local veh = getPedOccupiedVehicle(player)
	local sdata = getElementData(veh, "siren")
	local allowed = false
	
	for i,v in ipairs(getElementsByType("ped")) do
		if tonumber(getElementData(v, "factions.id")) == exports.brpExports:getVehicleFaction(veh) then
			if getElementData(v, "factions.type") == "law" or getElementData(v, "factions.type") == "medical" then
				allowed = true
			end
		end
	end
	
	if veh then
		if allowed == true then
			allowed = false
			if sdata == false then
				triggerClientEvent("startSiren", cRoot, veh)
				setElementData(veh, "siren", true)
				outputServerLog("[VEHICLE] [PLA/SIRENON]: " .. getPlayerName(player) .. " turned on vehicle ID " .. getElementData(veh, "vehicle.id") .. "'s emergency sirens.")
			elseif sdata == true then
				triggerClientEvent("stopSiren", cRoot, veh)
				setElementData(veh, "siren", false)
				outputServerLog("[VEHICLE] [PLA/SIRENOFF]: " .. getPlayerName(player) .. " turned off vehicle ID " .. getElementData(veh, "vehicle.id") .. "'s emergency sirens.")
			end
		end
	end
end
addCommandHandler("siren", siren)

addEventHandler("onVehicleEnter", cRoot,
	function(player, seat, jacked)
		if seat == 0 then
			bindKey(player, "n", "down", siren)
		end
	end
)

addEventHandler("onVehicleExit", cRoot,
	function(player, seat, jacker)
		if seat == 0 then
			unbindKey(player, "n", "down", siren)
		end
	end
)

-- ~ [CL] ~ --
function triggerEmergencyLights(player, cmd)
	local vehicle = getPedOccupiedVehicle(player)
	local allowed = false
	
	for i,v in ipairs(getElementsByType("ped")) do
		if tonumber(getElementData(v, "factions.id")) == exports.brpExports:getVehicleFaction(vehicle) then
			if getElementData(v, "factions.type") == "law" or getElementData(v, "factions.type") == "medical" then
				allowed = true
			end
		end
	end
	
	if vehicle then
		if getVehicleController(vehicle) == player then
			if allowed == true then
				allowed = false
				if not getElementData(vehicle, "vehicles.emergencylights") then
					setElementData(vehicle, "vehicles.emergencylights", true)
					triggerEvent("onLightsTrigger1", vehicle, vehicle)
					outputServerLog("[VEHICLE] [PLA/EMERGENCYLIGHTSON]: " .. getPlayerName(player) .. " turned on vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s emergency lights.")
				else
					removeElementData(vehicle, "vehicles.emergencylights")
					setVehicleHeadLightColor(vehicle, 255, 255, 255)
					setVehicleOverrideLights(vehicle, 2)
					outputServerLog("[VEHICLE] [PLA/EMERGENCYLIGHTSOFF]: " .. getPlayerName(player) .. " turned off vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s emergency lights.")
				end
			end
		end
	end
end
addCommandHandler("cl", triggerEmergencyLights)

addEvent("onLightsTrigger1", true)
addEventHandler("onLightsTrigger1", cRoot,
	function(vehicle)
		if getElementData(vehicle, "vehicles.emergencylights") then
			setVehicleHeadLightColor(vehicle, 255, 0, 0)
			setVehicleLightState(vehicle, 0,  0)
			setVehicleLightState(vehicle, 1,  1)
			setVehicleLightState(vehicle, 2,  1)
			setVehicleLightState(vehicle, 3,  0)
			setTimer(triggerEvent, 100, 1, "onLightsTrigger2", vehicle, vehicle)
		else
			setVehicleHeadLightColor(vehicle, 255, 255, 255)
			setVehicleOverrideLights(vehicle, 2)
		end
	end
)

addEvent("onLightsTrigger2", true)
addEventHandler("onLightsTrigger2", cRoot,
	function(vehicle)
		if getElementData(vehicle, "vehicles.emergencylights") then
			setVehicleHeadLightColor(vehicle, 0, 0, 255)
			setVehicleLightState(vehicle, 0,  1)
			setVehicleLightState(vehicle, 1,  0)
			setVehicleLightState(vehicle, 2,  0)
			setVehicleLightState(vehicle, 3,  1)
			setTimer(triggerEvent, 100, 1, "onLightsTrigger1", vehicle, vehicle)
		else
			setVehicleHeadLightColor(vehicle, 255, 255, 255)
			setVehicleOverrideLights(vehicle, 2)
		end
	end
)

function toggleVehicleEngine(source)
	local vehicle = getPedOccupiedVehicle(source)
	if vehicle then
		local control = getVehicleController(vehicle)
		if control == source then
			if exports.brpExports:isVehicleInFaction(vehicle) then
				if exports.brpExports:getVehicleFaction(vehicle) == exports.brpExports:getPlayerFaction(source) then
					local state = getVehicleEngineState(vehicle)
					if state == false then
						setVehicleEngineState(vehicle, true)
						setElementData(vehicle, "vehicle.engine", 1)
						outputServerLog("[VEHICLE] [FACTION/ENGINEON]: " .. getPlayerName(source) .. " turned on vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s engine.")
					else
						setVehicleEngineState(vehicle, false)
						setElementData(vehicle, "vehicle.engine", 0)
						outputServerLog("[VEHICLE] [FACTION/ENGINEOFF]: " .. getPlayerName(source) .. " turned off vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s engine.")
					end
				end
			elseif exports.brpExports:doesPlayerOwnVehicle(vehicle, source) then
				local state = getVehicleEngineState(vehicle)
				if state == false then
					setVehicleEngineState(vehicle, true)
					setElementData(vehicle, "vehicle.engine", 1)
					outputServerLog("[VEHICLE] [PLA/ENGINEON]: " .. getPlayerName(source) .. " turned on vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s engine.")
				else
					setVehicleEngineState(vehicle, false)
					setElementData(vehicle, "vehicle.engine", 0)
					outputServerLog("[VEHICLE] [PLA/ENGINEOFF]: " .. getPlayerName(source) .. " turned off vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s engine.")
				end
			elseif exports.brpExports:isPlayerAdmin(source) then
				local state = getVehicleEngineState(vehicle)
				if state == false then
					setVehicleEngineState(vehicle, true)
					setElementData(vehicle, "vehicle.engine", 1)
					outputServerLog("[VEHICLE] [ADMIN/ENGINEON]: " .. getPlayerName(source) .. " turned on vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s engine.")
				else
					setVehicleEngineState(vehicle, false)
					setElementData(vehicle, "vehicle.engine", 0)
					outputServerLog("[VEHICLE] [ADMIN/ENGINEOFF]: " .. getPlayerName(source) .. " turned off vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s engine.")
				end
			else
				outputChatBox("You do not have a car key to this vehicle.", source, 255, 0, 0, false)
			end
		end
	end
end

-- ~ [HANDBRAKE] ~ --
addCommandHandler("handbrake",
	function(player, cmd)
		local vehicle = getPedOccupiedVehicle(player)
		if vehicle and getVehicleController(vehicle) == player then
			if isElementFrozen(vehicle) then
				setElementData(vehicle, "vehicle.handbrake", 0)
				setElementFrozen(vehicle, false)
				outputChatBox("Handbrake unapplied.", player, 0, 255, 0, false)
				outputServerLog("[VEHICLE] [PLA/UNAPPLY/HANDBRAKE]: " .. getPlayerName(player) .. " unapplied vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s handbrake.")
			else
				setElementData(vehicle, "vehicle.handbrake", 1)
				setElementFrozen(vehicle, true)
				outputChatBox("Handbrake applied.", player, 0, 255, 0, false)
				outputServerLog("[VEHICLE] [CMD/APPLY/HANDBRAKE]: " .. getPlayerName(player) .. " applied vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s handbrake.")
			end
		end
	end
)

function toggleVehicleLights(source)
	local vehicle = getPedOccupiedVehicle(source)
	if vehicle and getVehicleController(vehicle) == source then
		if getVehicleOverrideLights(vehicle) == 1 then
			setElementData(vehicle, "vehicle.lights", 1)
            setVehicleOverrideLights(vehicle, 2)
			setVehicleHeadLightColor(vehicle, 255, 255, 255)
			outputServerLog("[VEHICLE] [PLA/LIGHTSON]: " .. getPlayerName(source) .. " switched on vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s headlights.")
			
			if getElementData(vehicle, "vehicles.emergencylights") then
				removeElementData(vehicle, "vehicles.emergencylights")
			end
        else
			setElementData(vehicle, "vehicle.lights", 0)
            setVehicleOverrideLights(vehicle, 1)
			setVehicleHeadLightColor(vehicle, 255, 255, 255)
			outputServerLog("[VEHICLE] [PLA/LIGHTSOFF]: " .. getPlayerName(source) .. " switched off vehicle ID " .. getElementData(vehicle, "vehicle.id") .. "'s headlights.")
			
			if getElementData(vehicle, "vehicles.emergencylights") then
				removeElementData(vehicle, "vehicles.emergencylights")
			end
        end
	end
end

function toggleVehicleLock(source)
	local vehicle = getPedOccupiedVehicle(source)
	if vehicle and getVehicleController(vehicle) == source then
		local x, y, z = getElementPosition(source)
		if isVehicleLocked(vehicle) then
			for i,v in ipairs(getElementsByType("player")) do
				if exports.brpExports:isElementInRangeOfPoint(v, x, y, z, 12) then
					setElementData(vehicle, "vehicle.lock", 0)
					outputChatBox("*" .. getPlayerName(source) .. " unlocks the vehicle doors.", v, 255, 90, 90, false)
				end
			end
			outputServerLog("[VEHICLE] [PLA/INSIDE/UNLOCKVEHICLE]: " .. getPlayerName(source) .. " unlocked vehicle ID " .. getElementData(vehicle, "vehicle.id") .. ".")
			setVehicleLocked(vehicle, false)
		else
			for i,v in ipairs(getElementsByType("player")) do
				if exports.brpExports:isElementInRangeOfPoint(v, x, y, z, 12) then
					setElementData(vehicle, "vehicle.lock", 1)
					outputChatBox("*" .. getPlayerName(source) .. " locks the vehicle doors.", v, 255, 90, 90, false)
				end
			end
			outputServerLog("[VEHICLE] [PLA/INSIDE/LOCKVEHICLE]: " .. getPlayerName(source) .. " locked vehicle ID " .. getElementData(vehicle, "vehicle.id") .. ".")
			setVehicleLocked(vehicle, true)
		end
	elseif not vehicle then
		for i,v in ipairs(getElementsByType("vehicle")) do
			local x, y, z = getElementPosition(source)
			local vx, vy, vz = getElementPosition(v)
			if exports.brpExports:isElementInRangeOfPoint(v, x, y, z, 20) then
				if exports.brpExports:doesPlayerOwnVehicle(vehicle, source) or exports.brpExports:isVehicleInFaction(v) and exports.brpExports:getVehicleFaction(v) == exports.brpExports:getPlayerFaction(source) then
					if isVehicleLocked(v) then
						setVehicleLocked(v, false)
						setElementData(v, "vehicle.lock", 0)
						for pi,pv in ipairs(getElementsByType("player")) do
							if exports.brpExports:isElementInRangeOfPoint(pv, x, y, z, 12) then
								outputChatBox("*" .. getPlayerName(source) .. " presses on the key to unlock the vehicle. ((" .. getVehicleName(v) .. "))", pv, 255, 90, 90, false)
							end
						end
						outputServerLog("[VEHICLE] [PLA/OUTSIDE/UNLOCKVEHICLE]: " .. getPlayerName(source) .. " unlocked vehicle ID " .. getElementData(vehicle, "vehicle.id") .. ".")
						break
					else
						setVehicleLocked(v, true)
						setElementData(v, "vehicle.lock", 1)
						for pi,pv in ipairs(getElementsByType("player")) do
							if exports.brpExports:isElementInRangeOfPoint(pv, x, y, z, 12) then
								outputChatBox("*" .. getPlayerName(source) .. " presses on the key to lock the vehicle. ((" .. getVehicleName(v) .. "))", pv, 255, 90, 90, false)
							end
						end
						outputServerLog("[VEHICLE] [PLA/OUTSIDE/LOCKVEHICLE]: " .. getPlayerName(source) .. " locked vehicle ID " .. getElementData(vehicle, "vehicle.id") .. ".")
						break
					end
				end
			end
		end
	end
end

-- ~ [REPAIRVEHICLE, REPAIRVEH, REPAIRCAR] ~ --
addCommandHandler({"repairvehicle", "repairveh", "repaircar"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local vehicle = getPedOccupiedVehicle(target)
					if vehicle then
						fixVehicle(vehicle)
						outputChatBox("You repaired " .. getPlayerName(target) .. "'s vehicle.", player, 220, 220, 0, true)
						outputChatBox(getPlayerName(player) .. " repaired your vehicle.", target, 220, 220, 0, true)
						outputServerLog("[VEHICLE] [CMD/REPAIRVEHICLE]: " .. getPlayerName(player) .. " repaired " .. getPlayerName(target) .. "'s vehicle.")
					else
						outputChatBox(getPlayerName(target) .. " is not in a vehicle.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [REFUELVEHICLE, REFUELVEH, REFUELCAR] ~ --
addCommandHandler({"refuelvehicle", "refuelveh", "refuelcar"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local vehicle = getPedOccupiedVehicle(target)
					if vehicle then
						setElementData(vehicle, "vehicle.fuel", 100)
						outputChatBox("You refueled " .. getPlayerName(target) .. "'s vehicle.", player, 220, 220, 0, true)
						outputChatBox(getPlayerName(player) .. " refueled your vehicle.", target, 220, 220, 0, true)
						outputServerLog("[VEHICLE] [CMD/REFUELVEHICLE]: " .. getPlayerName(player) .. " refueled " .. getPlayerName(target) .. "'s vehicle.")
					else
						outputChatBox(getPlayerName(target) .. " is not in a vehicle.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [RESPAWNVEHICLE, RESPAWNCAR, RESPAWNVEH] ~ --
addCommandHandler({"respawnvehicle", "respawncar", "respawnveh"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local vehicle = getPedOccupiedVehicle(target)
					if vehicle then
						removePedFromVehicle(target)
						respawnVehicle(vehicle)
						outputChatBox("You respawned " .. getPlayerName(target) .. "'s vehicle.", player, 220, 220, 0, true)
						outputChatBox(getPlayerName(player) .. " respawned your vehicle.", target, 220, 220, 0, true)
						outputServerLog("[VEHICLE] [CMD/RESPAWNVEHICLE]: " .. getPlayerName(player) .. " respawned " .. getPlayerName(target) .. "'s vehicle.")
					else
						outputChatBox(getPlayerName(target) .. " is not in a vehicle.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [REPAIRVEHICLES, REPAIRVEHS, REPAIRCARS] ~ --
addCommandHandler({"repairvehicles", "repairvehs", "repaircars"},
	function(player, cmd)
		if exports.brpExports:isPlayerAdmin(player) then
			for i,v in ipairs(getElementsByType("vehicle")) do
				fixVehicle(v)
			end
			outputChatBox(" ** All vehicles repaired **", cRoot, 220, 220, 0, true)
			outputServerLog("[VEHICLE] [CMD/REPAIRVEHICLES]: " .. getPlayerName(player) .. " repaired all vehicles.")
		end
	end
)

local spawned = 0 -- Do not change this integer
local notspawned = 0 -- Do not change this integer

-- ~ [RESPAWNVEHICLES, RESPAWNVEHS, RESPAWNCARS] ~ --
addCommandHandler({"respawnvehicles", "respawnvehs", "respawncars"},
	function(player, cmd, seconds)
		if exports.brpExports:isPlayerAdmin(player) then
			if seconds then
				if tonumber(seconds) then
					outputChatBox(" ** All unoccupied vehicles will be respawned in " .. tonumber(seconds) .. " seconds **", cRoot, 220, 220, 0, false)
					setTimer(function(player)
						for i,v in ipairs(getElementsByType("vehicle")) do
							if exports.brpExports:isVehicleEmpty(v) then
								respawnVehicle(v)
								if spawned == 0 then
									spawned = 1
								else
									spawned = spawned + 1
								end
							else
								if notspawned == 0 then
									notspawned = 1
								else
									notspawned = notspawned + 1
								end
							end
						end
						outputChatBox("Respawned " .. spawned - 1 .. " (" .. notspawned .. " occupied) unoccupied vehicles.", player, 220, 220, 0, false)
						outputChatBox(" ** All unoccupied vehicles respawned **", cRoot, 220, 220, 0, false)
						outputServerLog("[VEHICLE] [CMD/RESPAWNVEHICLES]: " .. getPlayerName(player) .. " respawned all vehicles (" .. spawned - 1 .. " respawned,  " .. notspawned .. " occupied).")
						spawned = 0
						notspawned = 0
					end, seconds * 1000, 1, player)
				else
					outputChatBox("Seconds value must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <seconds>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [RESPAWNBLOWNVEHICLES] ~ --
addCommandHandler("respawnblownvehicles",
	function(player, cmd, seconds)
		if exports.brpExports:isPlayerAdmin(player) then
			if seconds then
				if tonumber(seconds) then
					outputChatBox(" ** All blown vehicles will be respawned in " .. tonumber(seconds) .. " seconds **", cRoot, 220, 220, 0, false)
					setTimer(function(player)
						for i,v in ipairs(getElementsByType("vehicle")) do
							if isVehicleBlown(v) then
								respawnVehicle(v)
							end
						end
						outputChatBox(" ** All blown vehicles respawned **", cRoot, 220, 220, 0, false)
						outputServerLog("[VEHICLE] [CMD/RESPAWNBLOWNVEHICLES]: " .. getPlayerName(player) .. " respawned all blown vehicles.")
					end, seconds * 1000, 1, player)
				else
					outputChatBox("Seconds value must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <seconds>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [REFUELVEHICLES, REFUELVEHS, REFUELCARS, REFILLVEHS, REFILLVEHICLES] ~ --
addCommandHandler({"refuelvehicles", "refuelvehs", "refuelcars", "refillvehs", "refillvehicles"},
	function(player, cmd)
		if exports.brpExports:isPlayerAdmin(player) then
			for i,v in ipairs(getElementsByType("vehicle")) do
				setElementData(v, "vehicle.fuel", 100)
			end
			outputChatBox(" ** All vehicles refueled **", cRoot, 220, 220, 0, true)
			outputServerLog("[VEHICLE] [CMD/REFUELVEHICLES]: " .. getPlayerName(player) .. " refueled all vehicles.")
		end
	end
)

-- Do not change this integer
local foundcar = 0

addCommandHandler({"gotocar", "gotoveh", "gotovehicle", "warptocar", "warptoveh"},
	function(player, cmd, id)
		if exports.brpExports:isPlayerAdmin(player) then
			local id = tonumber(id)
			if id then
				for i,v in ipairs(getElementsByType("vehicle")) do
					if tonumber(getElementData(v, "vehicle.id")) == id then
						local x, y, z = getElementPosition(v)
						local interior = getElementInterior(v)
						local dimension = getElementDimension(v)
						setElementPosition(player, x - 2, y, z + 0.5)
						setElementInterior(player, interior)
						setElementDimension(player, dimension)
						foundcar = 1
						outputChatBox("Teleported to vehicle ID " .. id .. ".", player, 0, 255, 0, false)
						outputServerLog("[VEHICLES] [CMD/GOTOCAR]: " .. getPlayerName(player) .. " teleported to vehicle ID " .. id .. ".")
					end
				end
				
				if foundcar == 0 then
					outputChatBox("Invalid vehicle ID.", player, 255, 0, 0, false)
				else
					foundcar = 0
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <id>", player, 220, 220, 0, false)
			end
		end
	end
)

addEventHandler("onVehicleExplode", cRoot,
	function()
		setTimer(respawnVehicle, 75000, 1, source)
		outputServerLog("[VEHICLE] [PLA/EXPLOSION]: " .. getVehicleName(source) .. " exploded - respawn in 75 seconds (75000ms).")
	end
)

addEventHandler("onVehicleEnter", cRoot,
	function(player, seat, jacked)
		if isVehicleLocked(source) then
			local x, y, z = getElementPosition(player)
			removePedFromVehicle(player)
			setElementPosition(player, x, y, z + 2)
			outputChatBox("(( The door is locked. ))", player, 255, 0, 0, false)
		else
			if not getElementData(source, "vehicle.owner") then
				outputChatBox("This vehicle is unknown. Please report to an administrator.", player, 255, 0, 0, false)
				outputServerLog("[VEHICLE] [PLA/ENTER]: " .. getPlayerName(player) .. " entered a " .. getVehicleName(source) .. " [UNKNOWN], which belongs to UNKNOWN.")
			end
			
			if getElementData(source, "vehicle.owner") then
				if tonumber(getElementData(source, "vehicle.owner")) == 0 then
					outputChatBox("This is a civilian vehicle.", player, 220, 220, 0, false)
					outputServerLog("[VEHICLE] [PLA/ENTER]: " .. getPlayerName(player) .. " entered a " .. getVehicleName(source) .. " [" .. getElementData(source, "vehicle.id") .. "], which belongs to no one (Civilian).")
				elseif tonumber(getElementData(source, "vehicle.owner")) == -1 then
					for i,v in ipairs(getElementsByType("ped")) do
						if tonumber(getElementData(v, "factions.id")) == exports.brpExports:getVehicleFaction(source) then
							outputChatBox("This " .. getVehicleName(source) .. " belongs to " .. getElementData(v, "factions.name") .. ".", player, 220, 220, 0, false)
							outputServerLog("[VEHICLE] [PLA/ENTER]: " .. getPlayerName(player) .. " entered a " .. getVehicleName(source) .. " [" .. getElementData(source, "vehicle.id") .. "], which belongs to " .. getElementData(v, "factions.name") .. ".")
						end
					end
				else
					outputChatBox("This " .. getVehicleName(source) .. " belongs to " .. getElementData(source, "vehicle.owner") .. ".", player, 220, 220, 0, false)
					outputServerLog("[VEHICLE] [PLA/ENTER]: " .. getPlayerName(player) .. " entered a " .. getVehicleName(source) .. " [" .. getElementData(source, "vehicle.id") .. "], which belongs to " .. getElementData(source, "vehicle.owner") .. ".")
				end
			end
		
			if tonumber(getElementData(source, "vehicle.tint")) == 1 then
				setPlayerNametagText(player, "Unknown Person (Tint)")
			end
			
			if tonumber(getElementData(source, "vehicle.engine")) == 1 then
				setVehicleEngineState(source, true)
			else
				setVehicleEngineState(source, false)
			end
			
			if tonumber(getElementData(source, "vehicle.lights")) == 0 then
				setVehicleOverrideLights(source, 1)
			elseif tonumber(getElementData(source, "vehicle.lights")) == 1 then
				setVehicleOverrideLights(source, 2)
			end
			
			if tonumber(getElementData(source, "vehicle.handbrake")) == 1 then
				setElementFrozen(source, true)
			else
				setElementFrozen(source, false)
			end
			
			if tonumber(getElementData(source, "vehicle.lock")) == 1 then
				setVehicleLocked(source, true)
			else
				setVehicleLocked(source, false)
			end
		end
	end
)

addEventHandler("onVehicleStartExit", cRoot,
	function(player, seat, jacked, door)
		if isVehicleLocked(source) then
			cancelEvent()
			outputChatBox("The door is locked.", player, 220, 220, 0, false)
		else
			setPlayerNametagText(player, getPlayerName(player))
			outputServerLog("[VEHICLE] [PLA/EXIT]: " .. getPlayerName(player) .. " exited a " .. getVehicleName(source) .. " [" .. getElementData(source, "vehicle.id") .. "], which belongs to " .. getElementData(source, "vehicle.owner") .. ".")
		end
	end
)

-- ~ [CREATEVEHICLE, MAKEVEH, MAKEVEHICLE, MAKECAR] ~ --
addCommandHandler({"createvehicle", "makeveh", "makevehicle", "makecar"},
	function(player, cmd, name, color1, color2, tint, owner)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and color1 and color2 and tint then
				local find_ = string.find(name, "_")
				if tonumber(color1) >= 0 and tonumber(color1) <= 126 and tonumber(color2) >= 0 and tonumber(color2) <= 126 then
					local px, py, pz = getElementPosition(player)
					local rx, ry, rz = getElementRotation(player)
					local interior = getElementInterior(player)
					local dimension = getElementDimension(player)
					local model1 = getVehicleModelFromName(name:gsub("_", " "))
					local model2 = getVehicleModelFromName(tostring(name))
					local xml = xmlLoadFile("vehicles.map")
					local new = xmlCreateChild(xml, "veh")
					local id = math.random(1,99999)
					
					if find_ then
						vehh = createVehicle(model1, px + 4, py, pz, rx, ry, rz)
						outputChatBox("Created a " .. getVehicleNameFromModel(model1) .. " with ID " .. tonumber(id) .. ".", player, 0, 255, 0, false)
						outputServerLog("[VEHICLE] [CMD/CREATEVEHICLE]: " .. getPlayerName(player) .. " created a " .. getVehicleNameFromModel(model1) .. " with ID " .. tonumber(id) .. ".")
						xmlNodeSetAttribute(new, "model", tonumber(model1))
					else
						vehh = createVehicle(model2, px + 4, py, pz, rx, ry, rz)
						outputChatBox("Created a " .. getVehicleNameFromModel(model2) .. " with ID " .. tonumber(id) .. ".", player, 0, 255, 0, false)
						outputServerLog("[VEHICLE] [CMD/CREATEVEHICLE]: " .. getPlayerName(player) .. " created a " .. getVehicleNameFromModel(model2) .. " with ID " .. tonumber(id) .. ".")
						xmlNodeSetAttribute(new, "model", tonumber(model2))
					end
					
					local vpx, vpy, vpz = getElementPosition(vehh)
					local vrx, vry, vrz = getElementRotation(vehh)
					xmlNodeSetAttribute(new, "id", tonumber(id))
					xmlNodeSetAttribute(new, "posx", tonumber(vpx))
					xmlNodeSetAttribute(new, "posy", tonumber(vpy))
					xmlNodeSetAttribute(new, "posz", tonumber(vpz))
					xmlNodeSetAttribute(new, "rotx", tonumber(vrx))
					xmlNodeSetAttribute(new, "roty", tonumber(vry))
					xmlNodeSetAttribute(new, "rotz", tonumber(vrz))
					xmlNodeSetAttribute(new, "interior", tonumber(interior))
					xmlNodeSetAttribute(new, "dimension", tonumber(dimension))
					xmlNodeSetAttribute(new, "color1", tonumber(color1))
					xmlNodeSetAttribute(new, "color2", tonumber(color2))
					xmlNodeSetAttribute(new, "health", 1000)
					xmlNodeSetAttribute(new, "fuel", 100)
					xmlNodeSetAttribute(new, "engineState", 0)
					xmlNodeSetAttribute(new, "lightsState", 0)
					xmlNodeSetAttribute(new, "handbrakeState", 1)
					xmlNodeSetAttribute(new, "lockState", 0)
					xmlNodeSetAttribute(new, "factionid", 0)
					xmlNodeSetAttribute(new, "createdby", getPlayerName(player))
					
					if owner then
						local target = exports.brpExports:findPlayer(owner, player)
						if target then
							local acc = getPlayerAccount(target)
							xmlNodeSetAttribute(new, "owner", getAccountName(acc))
							setElementData(vehh, "vehicle.owner", getAccountName(acc))
						else
							outputChatBox("Failed to set the owner. Default set.", player, 255, 0, 0, false)
						end
					else
						xmlNodeSetAttribute(new, "owner", 0)
						setElementData(vehh, "vehicle.owner", 0)
					end
					
					if tonumber(tint) == 0 then
						xmlNodeSetAttribute(new, "tinted", 0)
					elseif tonumber(tint) == 1 then
						xmlNodeSetAttribute(new, "tinted", 1)
					else
						xmlNodeSetAttribute(new, "tinted", 0)
					end
					
					xmlSaveFile(xml)
					xmlUnloadFile(xml)
					
					-- Set current in-game datas
					setElementData(vehh, "vehicle.id", id)
					setElementData(vehh, "vehicle.engine", 0)
					setElementData(vehh, "vehicle.lights", 0)
					setElementData(vehh, "vehicle.lock", 0)
					setElementData(vehh, "vehicle.fuel", 100)
					setElementData(vehh, "vehicle.handbrake", 1)
					setElementData(vehh, "vehicle.faction", 0)
					setElementData(vehh, "factions.vehicle", 0)
					setElementData(vehh, "vehicle.tint", tint)
					setVehicleColor(vehh, tonumber(color1), tonumber(color2), 0, 0)
				else
					outputChatBox("Color values must be 0-126.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <name> <color 1> <color 2> <tinted> [<owner>]", player, 220, 220, 0, false)
				outputChatBox("If the vehicle name has spaces, just put on an underscore: _ and it will automaticly detect it.", player, 255, 255, 255, false)
				outputChatBox("Tints: 0 = false, 1 = true", player, 255, 255, 255, false)
			end
		end
	end
)

-- ~ [NEARBYVEHICLES, NEARBYCARS, NEARBYVEHS] ~ --
addCommandHandler({"nearbyvehicles", "nearbycars", "nearbyvehs"},
	function(player, cmd)
		if exports.brpExports:isPlayerAdmin(player) then
			local x, y, z = getElementPosition(player)
			outputChatBox("Nearby vehicles:", player, 190, 190, 0, false)
			for i,v in ipairs(getElementsByType("vehicle")) do
				local x, y, z = getElementPosition(player)
				if exports.brpExports:isElementInRangeOfPoint(v, x, y, z, 15) then
					outputChatBox(" Name: " .. getVehicleName(v) .. " - ID: " .. getElementData(v, "vehicle.id") .. " - Owner: " .. getElementData(v, "vehicle.owner") .. ".", player, 220, 220, 0, false)
				end
			end
			outputServerLog("[VEHICLE] [CMD/NEARBYVEHICLES]: " .. getPlayerName(player) .. " checked nearby vehicles at " .. (math.floor( x * 100 ) / 100) .. ", " .. (math.floor( y * 100 ) / 100) .. ", " .. (math.floor( z * 100 ) / 100) .. ".")
		end
	end
)

-- ~ [DELETEVEHICLE, DELVEH, DELCAR, DELETECAR, DELETEVEH] ~ --
addCommandHandler({"deletevehicle", "delveh", "delcar", "deletecar", "deleteveh"},
	function(player, cmd, id)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if id then
				for i,v in ipairs(getElementsByType("vehicle")) do
					for ii,vv in ipairs(getElementsByType("veh")) do
						if tonumber(getElementData(v, "vehicle.id")) == tonumber(getElementData(vv, "id")) then
							local xml = xmlLoadFile("vehicles.map")
							local new = xmlFindChild(xml, "veh", 0)
							xmlNodeSetName(new, "deleted")
							xmlNodeSetAttribute(new, "deletedby", getPlayerName(player))
							xmlSaveFile(xml)
							xmlUnloadFile(xml)
							blowVehicle(v, false)
							destroyElement(v)
							break
						end
					end
				end
				outputChatBox("Deleted vehicle " .. tonumber(id) .. ".", player, 0, 255, 0, false)
				outputServerLog("[VEHICLES] [CMD/DELETEVEHICLE]: " .. getPlayerName(player) .. " deleted vehicle " .. tonumber(id) .. ".")
			else
				outputChatBox("Syntax: /" .. cmd .. " <id>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [BLOWVEHICLE] ~ --
addCommandHandler("blowvehicle",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local vehicle = getPedOccupiedVehicle(target)
					blowVehicle(vehicle, true)
					setPlayerNametagText(target, getPlayerName(target))
					outputChatBox("Your vehicle got blown up by " .. getPlayerName(player) .. ".", target, 220, 220, 0, false)
					outputChatBox("You blew " .. getPlayerName(target) .. "'s vehicle.", player, 220, 220, 0, false)
					outputServerLog("[VEHICLE] [CMD/BLOWVEHICLE]: " .. getPlayerName(player) .. " blew " .. getPlayerName(target) .. "'s vehicle.")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETVEHICLECOLOR, SETVEHCOLOR, SETCOLOR] ~ --
addCommandHandler({"setvehiclecolor", "setvehcolor", "setcolor"},
	function(player, cmd, name, color1, color2)
		if exports.brpExports:isPlayerAdmin(player) then
			if name and color1 and color2 then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if tonumber(color1) >= 0 and tonumber(color1) <= 126 and tonumber(color2) >= 0 and tonumber(color2) <= 126 then
						local vehicle = getPedOccupiedVehicle(target)
						setVehicleColor(vehicle, color1, color2, 0, 0)
						outputChatBox("Your vehicle color has been modified by " .. getPlayerName(player) .. ".", target, 220, 220, 0, false)
						outputChatBox("You changed " .. getPlayerName(target) .. "'s vehicle color to " .. tonumber(color1) .. " and " .. tonumber(color2) .. ".", player, 220, 220, 0, false)
						outputServerLog("[VEHICLE] [CMD/SETVEHICLECOLOR]: " .. getPlayerName(player) .. " changed " .. getPlayerName(target) .. "'s vehicle color to " .. tonumber(color1) .. " and " .. tonumber(color2) .. ".")
					else
						outputChatBox("Color value must be within 0-126.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <color 1> <color 2>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETWINDOWSTINTED] ~ --
addCommandHandler("setwindowstinted",
	function(player, cmd, name, value)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and value then
				if tonumber(value) >= 0 and tonumber(value) <= 1 then
					local target = exports.brpExports:findPlayer(name, player)
					if target then
						local vehicle = getPedOccupiedVehicle(target)
						if vehicle then
							if tonumber(value) == 1 then
								setElementData(vehicle, "vehicle.tint", 1)
								setPlayerNametagText(target, "Unknown Person (Tint)")
								outputChatBox("Vehicle's (" .. getVehicleName(vehicle) .. ") window tints are now enabled.", player, 220, 220, 0, false)
								outputServerLog("[VEHICLE] [CMD/SETWINDOWSTINTED]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s vehicle windows as tinted.")
							elseif tonumber(value) == 0 then
								setElementData(vehicle, "vehicle.tint", 0)
								setPlayerNametagText(target, getPlayerName(target))
								outputChatBox("Vehicle's (" .. getVehicleName(vehicle) .. ") window tints are now disabled.", player, 220, 220, 0, false)
								outputServerLog("[VEHICLE] [CMD/SETWINDOWSTINTED]: " .. getPlayerName(player) .. " removed " .. getPlayerName(target) .. "'s vehicle window tints.")
							end
						else
							outputChatBox("Player is not in a vehicle.", player, 255, 0, 0, false)
						end
					else
						outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Value must be a number (0: false, 1: true).", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <0: false, 1: true>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETVEHICLEOWNER] ~ --
addCommandHandler("setvehicleowner",
	function(player, cmd, name, value)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and value then
				local target1 = exports.brpExports:findPlayer(name, player)
				if target1 then
					if tonumber(value) and tonumber(value) == 0 then
						local vehicle = getPedOccupiedVehicle(target1)
						if vehicle then
							setElementData(vehicle, "vehicle.owner", 0)
							outputChatBox(getPlayerName(target1) .. "'s vehicle owner reseted and set as 'Civilian'.", player, 220, 220, 0, false)
							outputServerLog("[VEHICLE] [CMD/SETVEHICLEOWNER]: " .. getPlayerName(player) .. " set " .. getPlayerName(target1) .. "'s vehicle owner reseted and set as 'Civilian'.")
						else
							outputChatBox("Player is not in a vehicle.", player, 255, 0, 0, false)
						end
					else
						local target2 = findPlayer(value, player)
						if target1 and target2 then
							local vehicle = getPedOccupiedVehicle(target1)
							if vehicle then
								setElementData(vehicle, "vehicle.owner", getPlayerName(target2))
								outputChatBox(getPlayerName(target1) .. "'s vehicle owner changed to " .. getPlayerName(target2) .. ".", player, 220, 220, 0, false)
								outputServerLog("[VEHICLE] [CMD/SETVEHICLEOWNER]: " .. getPlayerName(player) .. " set " .. getPlayerName(target1) .. "'s vehicle owner to " .. getPlayerName(target2) .. ".")
							else
								outputChatBox("Player is not in a vehicle.", player, 255, 0, 0, false)
							end
						else
							outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
						end
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <owner: name or 0 = civilian>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETVEHICLEFACTION] ~ --
addCommandHandler("setvehiclefaction",
	function(player, cmd, name, id)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and id then
				if tonumber(id) then
					if tonumber(id) > 0 then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							local vehicle = getPedOccupiedVehicle(target)
							if vehicle then
								for i,v in ipairs(getElementsByType("ped")) do
									if tonumber(getElementData(v, "factions.id")) == tonumber(id) then
										setElementData(vehicle, "vehicle.faction", tonumber(id))
										setElementData(vehicle, "factions.vehicle", tonumber(id))
										setElementData(vehicle, "vehicle.owner", -1)
										outputChatBox(getPlayerName(target) .. "'s vehicle faction changed to " .. getElementData(v, "factions.name") .. " (" .. tonumber(id) .. ")", player, 220, 220, 0, false)
										outputServerLog("[VEHICLE] [CMD/SETVEHICLEFACTION]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s vehicle faction to " .. tonumber(id) .. ".")
									end
								end
								for i,v in ipairs(getElementsByType("veh")) do
									local xml = xmlLoadFile("vehicles.map")
									local new = xmlFindChild(xml, "veh", 0)
									if getElementData(vehicle, "vehicle.id") == xmlNodeGetAttribute(new, "id") then
										xmlNodeSetAttribute(new, "factionid", id)
										xmlNodeSetAttribute(new, "owner", -1)
										xmlSaveFile(xml)
										xmlUnloadFile(xml)
									end
								end
							else
								outputChatBox("Player is not in a vehicle.", player, 255, 0, 0, false)
							end
						else
							outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
						end
					else
						setElementData(vehicle, "vehicle.faction", 0)
						setElementData(vehicle, "factions.vehicle", 0)
						outputChatBox(getPlayerName(target) .. "'s vehicle faction reseted.", player, 220, 220, 0, false)
						outputServerLog("[VEHICLE] [CMD/SETVEHICLEFACTION]: " .. getPlayerName(player) .. " reset " .. getPlayerName(target) .. "'s vehicle faction.")
					end
				else
					outputChatBox("ID value must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <faction id>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [PARK] ~ --
addCommandHandler("park",
	function(player, cmd)
		local vehicle = getPedOccupiedVehicle(player)
		if vehicle then
			if exports.brpExports:doesPlayerOwnVehicle(vehicle, player) and getVehicleController(vehicle) == player or exports.brpExports:isPlayerAdmin(player) and getVehicleController(vehicle) == player then
				for i,v in ipairs(getElementsByType("veh")) do
					local xml = xmlLoadFile("vehicles.map")
					local new = xmlFindChild(xml, "veh", 0)
					if tonumber(getElementData(v, "id")) == exports.brpExports:getIDVehicle(vehicle) then
						local vpx, vpy, vpz = getElementPosition(vehicle)
						local vrx, vry, vrz = getElementRotation(vehicle)
						xmlNodeSetAttribute(new, "posx", vpx)
						xmlNodeSetAttribute(new, "posy", vpy)
						xmlNodeSetAttribute(new, "posz", vpz)
						xmlNodeSetAttribute(new, "rotx", vrx)
						xmlNodeSetAttribute(new, "roty", vry)
						xmlNodeSetAttribute(new, "rotz", vrz)
						xmlSaveFile(xml)
						xmlUnloadFile(xml)
						outputChatBox("Vehicle respawn position saved.", player, 220, 220, 0, false)
						outputServerLog("[VEHICLE] [CMD/PARK] " .. getPlayerName(player) .. " parked vehicle ID " .. getElementData(vehicle, "vehicle.id") .. " to " .. math.floor(vpx * 100) / 100 .. ", " .. math.floor(vpy * 100) / 100 .. ", " .. math.floor(vpz * 100) / 100 .. ".")
						setVehicleRespawnPosition(vehicle, vpx, vpy, vpz, vrx, vry, vrz)
						break
					end
				end
			end
		else
			outputChatBox("You need to be in your vehicle first.", player, 255, 0, 0, false)
		end
	end
)

-- ~ [THISCAR] ~ --
addCommandHandler("thiscar",
	function(player, cmd)
		local vehicle = getPedOccupiedVehicle(player)
		if vehicle then
			outputChatBox("Vehicle ID " .. getElementData(vehicle, "vehicle.id") .. ".", player, 220, 220, 0, false)
			outputServerLog("[VEHICLE] [CMD/THISCAR]: " .. getPlayerName(player) .. " checked vehicle ID from vehicle ID " .. getElementData(vehicle, "vehicle.id") .. ".")
		else
			outputChatBox("You need to be in a vehicle to use this command.", player, 255, 0, 0, false)
		end
	end
)

local vehicles = 0 -- Do not change this integer

addEventHandler("onResourceStart", cThisRoot,
	function()
		for i,v in ipairs(getElementsByType("veh")) do
			local vehicle = createVehicle(tonumber(getElementData(v, "model")), tonumber(getElementData(v, "posx")), tonumber(getElementData(v, "posy")), tonumber(getElementData(v, "posz")), tonumber(getElementData(v, "rotx")), tonumber(getElementData(v, "roty")), tonumber(getElementData(v, "rotz")))
			setElementInterior(vehicle, tonumber(getElementData(v, "interior")))
			setElementDimension(vehicle, tonumber(getElementData(v, "dimension")))
			setElementData(vehicle, "vehicle.engine", tonumber(getElementData(v, "engineState")))
			setElementData(vehicle, "vehicle.lights", tonumber(getElementData(v, "lightsState")))
			setElementData(vehicle, "vehicle.lock", tonumber(getElementData(v, "lockState")))
			setElementData(vehicle, "vehicle.handbrake", tonumber(getElementData(v, "handbrakeState")))
			setElementData(vehicle, "vehicle.id", tonumber(getElementData(v, "id")))
			setElementData(vehicle, "vehicle.fuel", tonumber(getElementData(v, "fuel")))
			setElementData(vehicle, "vehicle.owner", getElementData(v, "owner"))
			setElementData(vehicle, "vehicle.tint", tonumber(getElementData(v, "tinted")))
			setElementData(vehicle, "vehicle.faction", tonumber(getElementData(v, "factionid")))
			setElementData(vehicle, "factions.vehicle", tonumber(getElementData(v, "factionid")))
			setVehicleColor(vehicle, tonumber(getElementData(v, "color1")), tonumber(getElementData(v, "color2")), 0, 0)
			setElementHealth(vehicle, tonumber(getElementData(v, "health")))
			
			if tonumber(getElementData(vehicle, "vehicle.engine")) == 1 then
				setVehicleEngineState(vehicle, true)
			else
				setVehicleEngineState(vehicle, false)
			end
			
			if tonumber(getElementData(vehicle, "vehicle.lights")) == 0 then
				setVehicleOverrideLights(vehicle, 1)
			elseif tonumber(getElementData(vehicle, "vehicle.lights")) == 1 then
				setVehicleOverrideLights(vehicle, 2)
			end
			
			if tonumber(getElementData(vehicle, "vehicle.handbrake")) == 1 then
				setElementFrozen(vehicle, true)
			else
				setElementFrozen(vehicle, false)
			end
			
			if tonumber(getElementData(vehicle, "vehicle.lock")) == 1 then
				setVehicleLocked(vehicle, true)
			else
				setVehicleLocked(vehicle, false)
			end
			
			setVehicleRespawnPosition(vehicle, getElementData(v, "posx"), getElementData(v, "posy"), getElementData(v, "posz"), getElementData(v, "rotx"), getElementData(v, "roty"), getElementData(v, "rotz"))
		end
		
		for i,v in ipairs(getElementsByType("player")) do
			bindKey(v, "j", "down", toggleVehicleEngine)
			bindKey(v, "l", "down", toggleVehicleLights)
			bindKey(v, "k", "down", toggleVehicleLock)
			bindKey(v, "p", "down", triggerEmergencyLights)
		end
		
		outputServerLog("[VEHICLES] [AUTO/SPAWN] All vehicles spawned as the resource started.")
		outputServerLog("[VEHICLES] [AUTO/BIND] All players binded with vehicle commands.")
	end
)

addEventHandler("onPlayerLogin", cRoot,
	function()
		bindKey(source, "j", "down", toggleVehicleEngine)
		bindKey(source, "l", "down", toggleVehicleLights)
		bindKey(source, "k", "down", toggleVehicleLock)
		bindKey(source, "p", "down", triggerEmergencyLights)
	end
)

addEventHandler("onResourceStop", cThisRoot,
	function()
		for vi,vv in ipairs(getElementsByType("vehicle")) do
			for i,v in ipairs(getElementsByType("veh")) do
				local xml = xmlLoadFile("vehicles.map")
				local new = xmlFindChild(xml, "veh", 0)
				if getElementData(vv, "vehicle.id") == xmlNodeGetAttribute(new, "id") then
					local vehicleowner = getElementData(vv, "vehicle.owner")
					local tinted = getElementData(vv, "vehicle.tint")
					local color1, color2, color3, color4 = getVehicleColor(vv)
					local vehiclehealth = getElementHealth(vv)
					local fuelamount = getElementData(vv, "vehicle.fuel")
					local enginestate = getElementData(vv, "vehicle.engine")
					local lightsstate = getElementData(vv, "vehicle.lights")
					local frozenstate = getElementData(vv, "vehicle.handbrake")
					local lockstate = getElementData(vv, "vehicle.lock")
					local factionid = getElementData(vv, "factions.vehicle")
					xmlNodeSetAttribute(new, "owner", vehicleowner)
					xmlNodeSetAttribute(new, "factionid", factionid)
					xmlNodeSetAttribute(new, "color1", color1)
					xmlNodeSetAttribute(new, "color2", color2)
					xmlNodeSetAttribute(new, "health", vehiclehealth)
					xmlNodeSetAttribute(new, "fuel", fuelamount)
					xmlNodeSetAttribute(new, "tinted", tinted)
					xmlNodeSetAttribute(new, "engineState", enginestate)
					xmlNodeSetAttribute(new, "lightsState", lightsstate)
					xmlNodeSetAttribute(new, "handbrakeState", frozenstate)
					xmlNodeSetAttribute(new, "lockState", lockstate)
					xmlSaveFile(xml)
					xmlUnloadFile(xml)
				end
			end
		end
		outputServerLog("[VEHICLES] [AUTO/SAVE] All vehicles saved as the resource stopped.")
	end
)