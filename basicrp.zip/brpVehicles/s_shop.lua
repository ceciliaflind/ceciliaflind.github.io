--[[
	Basic Roleplay Gamemode
	~ Server-side functions for vehicle shops
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Configurations (modifyable)
local shops = {
	-- Shop ID, shop name, blip ID, x position, y position, z position, interior, dimension, bought vehicle x position, bought vehicle y position, bought vehicle z position, bought vehicle x rotation, bought vehicle y rotation, bought vehicle z rotation
	{1, "Coutt and Schutz's Car Shop", 55, 2128.64, -1141.89, 25.05, 0, 0, 2128.02, -1117.03, 25.19, 0, 0, 70}
}

local vehicles = {
	-- Shop ID, vehicle id, x position, y position, z position, x rotation, y rotation, z rotation, price
	{1, 499, 2121.03, -1141.35, 24.87, 0, 0, 0, 500},
	{1, 588, 2125.03, -1141.35, 24.87, 0, 0, 0, 500}
}

-- Functions
addEventHandler("onResourceStart", resourceRoot,
	function()
		for i,v in ipairs(shops) do
			local blip = createBlip(shops[i][4], shops[i][5], shops[i][6], shops[i][3], 2, 255, 255, 255, 255, 0, 200)
			setElementInterior(blip, shops[i][7])
			setElementDimension(blip, shops[i][8])
			
			local marker = createMarker(shops[i][3], shops[i][4], shops[i][5], "cylinder", 50, 0, 0, 0, 0)
			setElementInterior(marker, shops[i][6])
			setElementDimension(marker, shops[i][7])
			setElementData(marker, "vehicles.shop", 1)
			setElementData(marker, "vehicles.shop-name", shops[i][1])
		end
		
		for i,v in ipairs(vehicles) do
			local vehicle = createVehicle(vehicles[i][2], vehicles[i][3], vehicles[i][4], vehicles[i][5], vehicles[i][6], vehicles[i][7], vehicles[i][8])
			setElementInterior(vehicle, shops[vehicles[i][1]][7])
			setElementDimension(vehicle, shops[vehicles[i][1]][8])
			setVehicleLocked(vehicle, true)
			setElementFrozen(vehicle, true)
			setVehicleDamageProof(vehicle, true)
			setVehicleDoorsUndamageable(vehicle, true)
			setElementData(vehicle, "vehicle.fuel", 100)
			setElementData(vehicle, "vehicle.id", -100)
			setElementData(vehicle, "vehicle.inshop", 1)
			setElementData(vehicle, "vehicle.price", vehicles[i][9])
			setElementData(vehicle, "vehicle.shop-name", shops[vehicles[i][1]][2])
			setElementData(vehicle, "vehicle.shop-id", vehicles[i][1])
		end
		
		outputServerLog("[VEHICLE] [SHOP/CREATE] Vehicle shops created.")
	end
)

function reloadShops()
	for i,v in ipairs(getElementsByType("vehicle")) do
		if getElementData(v, "vehicle.inshop") == 1 then
			destroyElement(v)
		end
	end
	
	for i,v in ipairs(vehicles) do
		local vehicle = createVehicle(vehicles[i][2], vehicles[i][3], vehicles[i][4], vehicles[i][5], vehicles[i][6], vehicles[i][7], vehicles[i][8])
		setElementInterior(vehicle, shops[vehicles[i][1]][7])
		setElementDimension(vehicle, shops[vehicles[i][1]][8])
		setVehicleLocked(vehicle, true)
		setElementData(vehicle, "vehicle.fuel", 100)
		setElementData(vehicle, "vehicle.id", -100)
		setElementData(vehicle, "vehicle.inshop", 1)
		setElementData(vehicle, "vehicle.price", vehicles[i][9])
		setElementData(vehicle, "vehicle.shop-name", shops[vehicles[i][1]][2])
		setElementData(vehicle, "vehicle.shop-id", vehicles[i][1])
	end
	
	outputServerLog("[VEHICLE] [SHOP/RELOAD] Reloaded vehicle shops.")
end
setTimer(reloadShops, 1800000, 0)

addEventHandler("onMarkerHit", root,
	function(hitElement, matchingDimension)
		if matchingDimension then
			if getElementType(hitElement) == "player" then
				if getElementData(source, "vehicles.shop") and getElementData(source, "vehicles.shop") == 1 then
					outputChatBox("Welcome to " .. getElementData(source, "vehicles.shop-name") .. ".", hitElement, 255, 255, 0, false)
					outputServerLog("[VEHICLE] [SHOP/ENTER]: " .. getPlayerName(hitElement) .. " hit the vehicle shop district at " .. getElementData(source, "vehicles.shop-name") .. ".")
				end
			end
		end
	end
)

addEventHandler("onVehicleStartEnter", root,
	function(player, seat, jacked, door)
		if getElementData(source, "vehicle.inshop") == 1 then
			local c1, c2, c3, c4 = getVehicleColor(source)
			cancelEvent()
			outputChatBox("[SHOP] Buy " .. getVehicleName(source) .. " with $" .. getElementData(source, "vehicle.price") .. ".", player, 255, 200, 0, false)
			outputChatBox("[SHOP] To buy the vehicle, press 'Y' or press 'N' to cancel this event.", player, 255, 200, 0, false)
			outputChatBox("[SHOP] You have 15 seconds until this is canceled automatically.", player, 255, 200, 0, false)
			outputServerLog("[VEHICLE] [SHOP/SESSIONSTART]: " .. getPlayerName(player) .. " started a vehicle shop session at " .. getElementData(source, "vehicle.shop-name") .. " for " .. getVehicleName(source) .. ".")
			setElementData(player, "shops.unverified", 1)
			setElementData(player, "shops.price", getElementData(source, "vehicle.price"))
			setElementData(player, "shops.id", getElementData(source, "vehicle.shop-id"))
			setElementData(player, "shops.shop-name", getElementData(source, "vehicle.shop-name"))
			setElementData(player, "shops.item-name", getVehicleName(source))
			setElementData(player, "shops.item-model", getElementModel(source))
			setElementData(player, "shops.item-color-1", c1)
			setElementData(player, "shops.item-color-2", c2)
			setElementData(source, "vehicle.confirmation", 1)
			bindKey(player, "y", "down", buyVehicle, player)
			bindKey(player, "n", "down", cancelConfirmation, player)
			cancel = setTimer(automaticCancel, 15 * 1000, 1, player)
		end
	end
)

function buyVehicle(player)
	if getPlayerMoney(player) >= tonumber(getElementData(player, "shops.price")) then
		takePlayerMoney(player, getElementData(player, "shops.price"))
		outputChatBox("Nice! That vehicle now belongs to you!", player, 0, 255, 0, false)
		unbindKey(player, "y", "down", buyVehicle)
		unbindKey(player, "n", "down", cancelConfirmation)
		
		if isTimer(cancel) then
			killTimer(cancel)
		end
		
		local interior = getElementInterior(player)
		local dimension = getElementDimension(player)
		local xml = xmlLoadFile("vehicles.map")
		local new = xmlCreateChild(xml, "veh")
		local id = math.random(1,99999)
		local model = tonumber(getElementData(player, "shops.item-model"))
		local tab = shops[tonumber(getElementData(player, "shops.id"))]
		local vehh = createVehicle(model, tab[9], tab[10], tab[11], tab[12], tab[13], tab[14])
		local accname = getAccountName(getPlayerAccount(player))
		local c1 = tonumber(getElementData(player, "shops.item-color-1"))
		local c2 = tonumber(getElementData(player, "shops.item-color-2"))
		
		outputServerLog("[VEHICLE] [SHOP/BUY]: " .. getPlayerName(player) .. " bought a vehicle (" .. getElementData(player, "shops.item-name") .. " [" .. model .. "]) from " .. getElementData(player, "shops.shop-name") .. " for $" .. getElementData(player, "shops.price") .. ".")
		xmlNodeSetAttribute(new, "model", model)
		xmlNodeSetAttribute(new, "id", tonumber(id))
		xmlNodeSetAttribute(new, "posx", tonumber(tab[9]))
		xmlNodeSetAttribute(new, "posy", tonumber(tab[10]))
		xmlNodeSetAttribute(new, "posz", tonumber(tab[11]))
		xmlNodeSetAttribute(new, "rotx", tonumber(tab[12]))
		xmlNodeSetAttribute(new, "roty", tonumber(tab[13]))
		xmlNodeSetAttribute(new, "rotz", tonumber(tab[14]))
		xmlNodeSetAttribute(new, "interior", tonumber(interior))
		xmlNodeSetAttribute(new, "dimension", tonumber(dimension))
		xmlNodeSetAttribute(new, "color1", c1)
		xmlNodeSetAttribute(new, "color2", c2)
		xmlNodeSetAttribute(new, "health", 1000)
		xmlNodeSetAttribute(new, "fuel", 100)
		xmlNodeSetAttribute(new, "engineState", 1)
		xmlNodeSetAttribute(new, "lightsState", 1)
		xmlNodeSetAttribute(new, "handbrakeState", 0)
		xmlNodeSetAttribute(new, "lockState", 0)
		xmlNodeSetAttribute(new, "factionid", 0)
		xmlNodeSetAttribute(new, "createdby", getPlayerName(player))
		xmlNodeSetAttribute(new, "owner", accname)
		xmlNodeSetAttribute(new, "tinted", 0)
		xmlSaveFile(xml)
		xmlUnloadFile(xml)
						
		-- Set current in-game datas
		setElementData(vehh, "vehicle.id", id)
		setElementData(vehh, "vehicle.engine", 1)
		setElementData(vehh, "vehicle.lights", 1)
		setElementData(vehh, "vehicle.lock", 0)
		setElementData(vehh, "vehicle.fuel", 100)
		setElementData(vehh, "vehicle.handbrake", 0)
		setElementData(vehh, "vehicle.faction", 0)
		setElementData(vehh, "factions.vehicle", 0)
		setElementData(vehh, "vehicle.tint", tint)
		setElementData(vehh, "vehicle.owner", accname)
		setVehicleColor(vehh, c1, c2, 0, 0)
		
		for i,v in ipairs(getElementsByType("vehicle")) do
			if getElementData(v, "vehicle.confirmation") and getElementData(v, "vehicle.confirmation") == 1 then
				destroyElement(v)
			end
		end
		
		removeElementData(player, "shops.unverified")
		removeElementData(player, "shops.price")
		removeElementData(player, "shops.id")
		removeElementData(player, "shops.shop-name")
		removeElementData(player, "shops.item-name")
		removeElementData(player, "shops.item-model")
		removeElementData(player, "shops.item-color-1")
		removeElementData(player, "shops.item-color-2")
	else
		outputChatBox("Unfortunately you do not have enough money to buy that vehicle.", player, 255, 0, 0, false)
		unbindKey(player, "y", "down", buyVehicle)
		unbindKey(player, "n", "down", cancelConfirmation)
		
		if isTimer(cancel) then
			killTimer(cancel)
		end
		
		for i,v in ipairs(getElementsByType("vehicle")) do
			if getElementData(v, "vehicle.confirmation") and getElementData(v, "vehicle.confirmation") == 1 then
				removeElementData(v, "vehicle.confirmation")
			end
		end
		
		outputServerLog("[VEHICLE] [SHOP/ERROR]: " .. getPlayerName(player) .. " couldn't buy " .. getElementData(player, "shops.item-name") .. " for $" .. getElementData(player, "shops.price") .. " at " .. getElementData(player, "shops.shop-name") .. ".")
		
		removeElementData(player, "shops.unverified")
		removeElementData(player, "shops.price")
		removeElementData(player, "shops.id")
		removeElementData(player, "shops.shop-name")
		removeElementData(player, "shops.item-name")
		removeElementData(player, "shops.item-model")
		removeElementData(player, "shops.item-color-1")
		removeElementData(player, "shops.item-color-2")
	end
end

function cancelConfirmation(player)
	outputChatBox("Okay, maybe some other time.", player, 220, 220, 0, false)
	outputServerLog("[VEHICLE] [SHOP/CANCEL]: " .. getPlayerName(player) .. " canceled their shopping session.")
	unbindKey(player, "y", "down", buyVehicle)
	unbindKey(player, "n", "down", cancelConfirmation)
	
	if isTimer(cancel) then
		killTimer(cancel)
	end
	
	removeElementData(player, "shops.unverified")
	removeElementData(player, "shops.price")
	removeElementData(player, "shops.id")
	removeElementData(player, "shops.shop-name")
	removeElementData(player, "shops.item-name")
	removeElementData(player, "shops.item-model")
	removeElementData(player, "shops.item-color-1")
	removeElementData(player, "shops.item-color-2")
end

function automaticCancel(player)
	if getElementData(player, "shops.unverified") == 1 then
		outputChatBox("Your shop session was canceled automatically after 15 seconds.", player, 220, 220, 0, false)
		outputServerLog("[VEHICLE] [SHOP/CANCEL]: " .. getPlayerName(player) .. "'s shopping session was automatically canceled.")
		unbindKey(player, "y", "down", buyVehicle)
		unbindKey(player, "n", "down", cancelConfirmation)
		removeElementData(player, "shops.unverified")
		removeElementData(player, "shops.price")
		removeElementData(player, "shops.id")
		removeElementData(player, "shops.shop-name")
		removeElementData(player, "shops.item-name")
		removeElementData(player, "shops.item-model")
		removeElementData(player, "shops.item-color-1")
		removeElementData(player, "shops.item-color-2")
	end
end