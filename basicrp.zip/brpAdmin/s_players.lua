--[[
	Basic Roleplay Gamemode
	~ Server-side functions for players
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

-- ~ [DISAPPEAR, INVISIBLE, INVIS, INV] ~ --
addCommandHandler({"disappear", "invisible", "invis", "inv"},
	function(player, cmd)
		if exports.brpExports:isPlayerAdmin(player) then
			if getElementAlpha(player) == 255 then
				setElementAlpha(player, 0)
				outputServerLog("[ADMIN] [CMD/DISAPPEAR]: " .. getPlayerName(player) .. " set their alpha to '0'.")
			else
				setElementAlpha(player, 255)
				outputServerLog("[ADMIN] [CMD/DISAPPEAR]: " .. getPlayerName(player) .. " set their alpha to '255'.")
			end
		end
	end
)

-- ~ [SETINTERIOR, SETINT, SINT] ~ --
addCommandHandler({"setinterior", "setint", "sint"},
	function(player, cmd, interior, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if interior then
				if tonumber(interior) then
					if name then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							setElementInterior(player, tonumber(interior))
							outputChatBox("You changed " .. getPlayerName(target) .. "'s interior to " .. tonumber(interior) .. ".", player, 220, 220, 0, false)
							outputServerLog("[ADMIN] [CMD/SETINTERIOR]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s interior to " .. tonumber(interior) .. ".")
						else
							outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
						end
					else
						setElementInterior(player, tonumber(interior))
						outputChatBox("Your interior was changed to " .. tonumber(interior) .. ".", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/SETINTERIOR]: " .. getPlayerName(player) .. " set their interior to " .. tonumber(interior) .. ".")
					end
				else
					outputChatBox("Interior value must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <interior> [<player>]", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETDIMENSION, SETDIM, SDIM] ~ --
addCommandHandler({"setdimension", "setdim", "sdim"},
	function(player, cmd, dimension, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if dimension then
				if tonumber(dimension) then
					if name then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							setElementDimension(player, tonumber(dimension))
							outputChatBox("You changed " .. getPlayerName(target) .. "'s dimension to " .. tonumber(dimension) .. ".", player, 220, 220, 0, false)
							outputServerLog("[ADMIN] [CMD/SETDIMENSION]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s dimension to " .. tonumber(dimension) .. ".")
						else
							outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
						end
					else
						setElementDimension(player, tonumber(dimension))
						outputChatBox("Your dimension was changed to " .. tonumber(dimension) .. ".", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/SETDIMENSION]: " .. getPlayerName(player) .. " set their dimension to " .. tonumber(dimension) .. ".")
					end
				else
					outputChatBox("Dimension value must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <dimension> [<player>]", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [GIVEWEAPON, GIVEWEP, GIVEGUN, MAKEWEAPON, MAKEGUN] ~ --
addCommandHandler({"giveweapon", "givewep", "givegun", "makeweapon", "makegun"},
	function(player, cmd, name, weapon)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and weapon then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if tonumber(weapon) then
						local weaponName = getWeaponNameFromID(weapon)
						giveWeapon(target, weapon, 1, true)
						for i,v in ipairs(getElementsByType("player")) do
							if exports.brpExports:isPlayerAdmin(v) then
								outputChatBox("[Wep]: " .. getPlayerName(player) .. " gave " .. getPlayerName(target) .. " a weapon (" .. weaponName .. ").", v, 255, 0, 0, false)
							end
						end
						outputServerLog("[ADMIN] [CMD/GIVEWEAPON]: " .. getPlayerName(player) .. " gave " .. getPlayerName(target) .. " a weapon (" .. weaponName .. ")")
					else
						local weaponID = getWeaponIDFromName(weapon)
						local weaponIDName = getWeaponNameFromID(weaponID)
						giveWeapon(target, weaponID, 1, true)
						for i,v in ipairs(getElementsByType("player")) do
							if exports.brpExports:isPlayerAdmin(v) then
								outputChatBox("[Wep]: " .. getPlayerName(player) .. " gave " .. getPlayerName(target) .. " a weapon (" .. weaponIDName .. ").", v, 255, 0, 0, false)
							end
						end
						outputServerLog("[ADMIN] [CMD/GIVEWEAPON]: " .. getPlayerName(player) .. " gave " .. getPlayerName(target) .. " a weapon (" .. weaponIDName .. ")")
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <weapon>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [GIVEWEAPONAMMO, GIVEAMMO, GIVEWEPAMMO, MAKEAMMO, GIVEGUNAMMO] ~ --
addCommandHandler({"giveweaponammo", "giveammo", "givewepammo", "makeammo", "givegunammo"},
	function(player, cmd, name, ammo, weapon)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and ammo and weapon then
				if tonumber(ammo) then
					local target = exports.brpExports:findPlayer(name, player)
					if target then
						if tonumber(weapon) then
							local weaponName = getWeaponNameFromID(weapon)
							giveWeapon(target, weapon, ammo, true)
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox("[WepAmmo]: " .. getPlayerName(player) .. " gave " .. getPlayerName(target) .. " bullets (" .. ammo .. ") to a weapon (" .. weaponName .. ").", v, 255, 0, 0, false)
								end
							end
							outputServerLog("[ADMIN] [CMD/GIVEWEAPONAMMO]: " .. getPlayerName(player) .. " gave " .. getPlayerName(target) .. " bullets (" .. ammo .. ") to a weapon (" .. weaponName .. ").")
						else
							local weaponID = getWeaponIDFromName(weapon)
							local weaponIDName = getWeaponNameFromID(weaponID)
							giveWeapon(target, weaponID, ammo, true)
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox("[WepAmmo]: " .. getPlayerName(player) .. " gave " .. getPlayerName(target) .. " bullets (" .. ammo .. ") to a weapon (" .. weaponIDName .. ").", v, 255, 0, 0, false)
								end
							end
							outputServerLog("[ADMIN] [CMD/GIVEWEAPONAMMO]: " .. getPlayerName(player) .. " gave " .. getPlayerName(target) .. " bullets (" .. ammo .. ") to a weapon (" .. weaponIDName .. ").")
						end
					else
						outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Syntax: /" .. cmd .. " <player> <ammo> <weapon>", player, 220, 220, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <ammo> <weapon>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [DISARM, TAKEGUN, TAKEWEP, TAKEWEAPON] ~ --
addCommandHandler({"disarm", "takegun", "takewep", "takeweapon"},
	function(player, cmd, name, weapon)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and weapon then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if tonumber(weapon) then
						local weaponName = getWeaponNameFromID(weapon)
						if getSlotFromWeapon(weapon) then
							takeWeapon(target, weaponID)
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox("DISARM: " .. getPlayerName(player) .. " disarmed " .. getPlayerName(target) .. "'s weapon (" .. weaponName .. ")", v, 255, 0, 0, false)
								end
							end
							outputServerLog("[ADMIN] [CMD/DISARM]: " .. getPlayerName(player) .. " disarmed " .. getPlayerName(target) .. "'s weapon (" .. weaponName .. ")")
						else
							outputChatBox(getPlayerName(target) .. " does not have that weapon.", player, 255, 0, 0, false)
						end
					else
						local weaponID = getWeaponIDFromName(weapon)
						local weaponIDName = getWeaponNameFromID(weaponID)
						if getSlotFromWeapon(weaponID) then
							takeWeapon(target, weaponID)
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox("DISARM: " .. getPlayerName(player) .. " disarmed " .. getPlayerName(target) .. "'s weapon (" .. weaponIDName .. ")", v, 255, 0, 0, false)
								end
							end
							outputServerLog("[ADMIN] [CMD/DISARM]: " .. getPlayerName(player) .. " disarmed " .. getPlayerName(target) .. "'s weapon (" .. weaponIDName .. ")")
						else
							outputChatBox(getPlayerName(target) .. " does not have that weapon.", player, 255, 0, 0, false)
						end
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <weapon>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [FULLDISARM, DISARMALL, TAKEALLWEAPONS, TAKEALLWEPS, TAKEALLGUNS] ~ --
addCommandHandler({"fulldisarm", "disarmall", "takeallweapons", "takeallweps", "takeallguns"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					takeAllWeapons(target)
					for i,v in ipairs(getElementsByType("player")) do
						if exports.brpExports:isPlayerAdmin(v) then
							outputChatBox("FULLDISARM: " .. getPlayerName(player) .. " disarmed " .. getPlayerName(target) .. "'s all weapons.", v, 255, 0, 0, false)
						end
					end
					outputServerLog("[ADMIN] [CMD/FULLDISARM]: " .. getPlayerName(player) .. " disarmed " .. getPlayerName(target) .. "'s all weapons.")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [CASH, MONEY] ~ --
addCommandHandler({"cash", "money"},
	function(player, cmd, name, state, value)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and state and value then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if tonumber(state) == 1 then
						if tonumber(value) > 0 then
							takePlayerMoney(target, tonumber(value))
							outputChatBox("You've taken " .. tonumber(value) .. " dollars from " .. getPlayerName(target) .. ".", player, 220, 220, 0, false)
							outputServerLog("[ADMIN] [CMD/CASH]: " .. getPlayerName(player) .. " took " .. tonumber(value) .. " dollars from " .. getPlayerName(target) .. ".")
						else
							outputChatBox("Value must be over 0 dollars.", player, 255, 0, 0, false)
						end
					elseif tonumber(state) == 2 then
						if tonumber(value) > 0 then
							givePlayerMoney(target, tonumber(value))
							outputChatBox("You've given " .. tonumber(value) .. " dollars to " .. getPlayerName(target) .. ".", player, 220, 220, 0, false)
							outputServerLog("[ADMIN] [CMD/CASH]: " .. getPlayerName(player) .. " gave " .. tonumber(value) .. " dollars to " .. getPlayerName(target) .. ".")
						else
							outputChatBox("Value must be over 0 dollars.", player, 255, 0, 0, false)
						end
					elseif tonumber(state) == 3 then
						setPlayerMoney(target, tonumber(value))
						outputChatBox("You've set " .. getPlayerName(target) .. "'s money to " .. tonumber(value) .. ".", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/CASH]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s money to " .. tonumber(value) .. ".")
					else
						outputChatBox("Invalid state set (1 = take money, 2 = give money, 3 = set money)", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <state: 1 = take money, 2 = give money, 3 = set money> <value>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [BANKCASH, BANKMONEY] ~ --
addCommandHandler({"bankcash", "bankmoney"},
	function(player, cmd, name, state, value)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and state and value then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if state == 1 then
						if value > 0 then
							takePlayerMoney(target, tonumber(value))
							outputChatBox("You've taken " .. tonumber(value) .. " dollars from " .. getPlayerName(target) .. "'s bank account.", player, 220, 220, 0, false)
							outputServerLog("[ADMIN] [CMD/BANKCASH]: " .. getPlayerName(player) .. " took " .. tonumber(value) .. " dollars from " .. getPlayerName(target) .. "'s bank account.")
						else
							outputChatBox("Value must be over 0 dollars.", player, 255, 0, 0, false)
						end
					elseif state == 2 then
						if value > 0 then
							givePlayerMoney(target, tonumber(value))
							outputChatBox("You've given " .. tonumber(value) .. " dollars to " .. getPlayerName(target) .. "'s bank account.", player, 220, 220, 0, false)
							outputServerLog("[ADMIN] [CMD/BANKCASH]: " .. getPlayerName(player) .. " gave " .. tonumber(value) .. " dollars to " .. getPlayerName(target) .. "'s bank account.")
						else
							outputChatBox("Value must be over 0 dollars.", player, 255, 0, 0, false)
						end
					elseif state == 3 then
						setPlayerMoney(target, tonumber(value))
						outputChatBox("You've set " .. getPlayerName(target) .. "'s bank account cash to " .. tonumber(value) .. ".", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/BANKCASH]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s bank account cash to " .. tonumber(value) .. ".")
					else
						outputChatBox("Invalid state set (1 = take money, 2 = give money, 3 = set money)", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <state: 1 = take money, 2 = give money, 3 = set money> <value>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [POS, GP, GETPOS] ~ --
addCommandHandler({"pos", "gp", "getpos"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local vpx, vpy, vpz = getElementPosition(target)
					outputChatBox("Position: " .. math.floor(vpx * 100) / 100 .. ", " .. math.floor(vpy * 100) / 100 .. ", " .. math.floor(vpz * 100) / 100, player, 220, 220, 0, false)
					outputChatBox("Dimension: " .. getElementDimension(target), player, 220, 220, 0, false)
					outputChatBox("Interior: " .. getElementInterior(target), player, 220, 220, 0, false)
					outputServerLog("[ADMIN] [CMD/POS]: " .. getPlayerName(player) .. " checked " .. getPlayerName(target) .. "'s current position.")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				local vpx, vpy, vpz = getElementPosition(player)
				outputChatBox("Position: " .. math.floor(vpx * 100) / 100 .. ", " .. math.floor(vpy * 100) / 100 .. ", " .. math.floor(vpz * 100) / 100, player, 220, 220, 0, false)
				outputChatBox("Dimension: " .. getElementDimension(player), player, 220, 220, 0, false)
				outputChatBox("Interior: " .. getElementInterior(player), player, 220, 220, 0, false)
				outputServerLog("[ADMIN] [CMD/POS]: " .. getPlayerName(player) .. " checked their current position.")
			end
		end
	end
)

-- ~ [A], ADMINCHAT, AC ~ --
addCommandHandler({"a", "adminchat", "ac"},
	function(player, cmd, ...)
		if exports.brpExports:isPlayerAdmin(player) then
			local message = table.concat({ ... }, " ")
			if #message > 0 then
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:isPlayerAdmin(v) then
						if exports.brpExports:getAdminLevel(player) == 1 then
							outputChatBox("Trial Admin " .. getPlayerName(player) .. ": " .. message, v, 200, 255, 0, false)
						elseif exports.brpExports:getAdminLevel(player) == 2 then
							outputChatBox("Admin " .. getPlayerName(player) .. ": " .. message, v, 200, 255, 0, false)
						elseif exports.brpExports:getAdminLevel(player) == 3 then
							outputChatBox("Lead Admin " .. getPlayerName(player) .. ": " .. message, v, 200, 255, 0, false)
						elseif exports.brpExports:getAdminLevel(player) == 4 then
							outputChatBox("Owner " .. getPlayerName(player) .. ": " .. message, v, 200, 255, 0, false)
						end
					end
				end
				outputServerLog("[ADMIN] [CMD/A]: " .. getPlayerName(player) .. ": " .. message)
			else
				outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [ANN, ANNOUNCE, ANNOUNCEMENT] ~ --
addCommandHandler({"ann", "announce", "announcement"},
	function(player, cmd, ...)
		if exports.brpExports:isPlayerAdmin(player) then
			local message = table.concat({ ... }, " ")
			if #message > 0 then
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:isPlayerAdmin(v) then
						if getElementData(player, "admin.hidden") == 1 then
							outputChatBox("Announcement made by " .. getPlayerName(player) .. " (Hidden Admin):", v, 220, 220, 0, false)
							outputServerLog("[ADMIN] [CMD/ANN]: announcement made by " .. getPlayerName(player) .. " (Hidden Admin):")
							outputServerLog("[ADMIN] [CMD/ANN]: " .. message)
						else
							outputChatBox("Announcement made by " .. getPlayerName(player) .. ":", v, 220, 220, 0, false)
							outputServerLog("[ADMIN] [CMD/ANN]: announcement made by " .. getPlayerName(player) .. ":")
							outputServerLog("[ADMIN] [CMD/ANN]: " .. message)
						end
					end
				end
				outputChatBox(" ** " .. message .. " **", root, 220, 220, 0, false)
			else
				outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [KICK] ~ --
addCommandHandler("kick",
	function(player, cmd, name, ...)
		if exports.brpExports:isPlayerAdmin(player) then
			local message = table.concat({ ... }, " ")
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if player ~= target then
						if message and #message > 0 then
							outputChatBox("kick: " .. getPlayerName(player) .. " kicked " .. getPlayerName(target) .. " from the server.", cRoot, 255, 0, 0, false)
							outputChatBox("kick: " .. tostring(message), cRoot, 255, 0, 0, false)
							outputServerLog("[ADMIN] [CMD/KICK]: " .. getPlayerName(player) .. " kicked " .. getPlayerName(target) .. " from the server.")
							outputServerLog("[ADMIN] [CMD/KICK]: Reason: " .. tostring(message))
							kickPlayer(target, player, tostring(message))
						else
							outputChatBox("kick: " .. getPlayerName(player) .. " kicked " .. getPlayerName(target) .. " from the server.", cRoot, 255, 0, 0, false)
							outputServerLog("[ADMIN] [CMD/KICK]: " .. getPlayerName(player) .. " kicked " .. getPlayerName(target) .. " from the server.")
							kickPlayer(target, player)
						end
					else
						outputChatBox("You cannot kick yourself.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> [<reason>]", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SKICK] ~ --
addCommandHandler("skick",
	function(player, cmd, name, ...)
		if exports.brpExports:isPlayerAdmin(player) then
			local message = table.concat({ ... }, " ")
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if player ~= target then
						if message and #message > 0 then
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox("skick: " .. getPlayerName(player) .. " silently kicked " .. getPlayerName(target) .. " from the server.", v, 255, 0, 0, false)
									outputChatBox("skick: Reason: " .. message, v, 255, 0, 0, false)
								end
							end
							outputServerLog("[ADMIN] [CMD/SKICK]: " .. getPlayerName(player) .. " kicked " .. getPlayerName(target) .. " from the server.")
							outputServerLog("[ADMIN] [CMD/SKICK]: Reason: " .. tostring(message))
							kickPlayer(target, player, tostring(message))
						else
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox("skick: " .. getPlayerName(player) .. " silently kicked " .. getPlayerName(target) .. " from the server.", v, 255, 0, 0, false)
								end
							end
							outputServerLog("[ADMIN] [CMD/SKICK]: " .. getPlayerName(player) .. " kicked " .. getPlayerName(target) .. " from the server.")
							kickPlayer(target, player)
						end
					else
						outputChatBox("You cannot kick yourself.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> [<reason>]", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [BAN] ~ --
addCommandHandler("ban",
	function(player, cmd, name, minutes, ...)
		if exports.brpExports:isPlayerAdmin(player) then
			local message = table.concat({ ... }, " ")
			if name and minutes then
				if tonumber(minutes) then
					if tonumber(minutes) > 0 then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							if player ~= target then
								if message and #message > 0 then
									outputChatBox("ban: " .. getPlayerName(player) .. " banned " .. getPlayerName(target) .. " from the server.", cRoot, 255, 0, 0, false)
									outputChatBox("ban: " .. tostring(message), cRoot, 255, 0, 0, false)
									outputServerLog("[ADMIN] [CMD/BAN]: " .. getPlayerName(player) .. " banned " .. getPlayerName(target) .. " from the server for " .. tonumber(minutes) .. " minutes.")
									outputServerLog("[ADMIN] [CMD/BAN]: " .. tostring(message))
									banPlayer(target, true, true, true, player, message, minutes * 60)
								else
									outputChatBox("ban: " .. getPlayerName(player) .. " banned " .. getPlayerName(target) .. " from the server.", cRoot, 255, 0, 0, false)
									outputServerLog("[ADMIN] [CMD/BAN]: " .. getPlayerName(player) .. " banned " .. getPlayerName(target) .. " from the server for " .. tonumber(minutes) .. " minutes.")
									banPlayer(target, true, true, true, player, nil, minutes * 60)
								end
							else
								outputChatBox("You cannot ban yourself.", player, 255, 0, 0, false)
							end
						else
							outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
						end
					else
						outputChatBox("Minutes value must be greater than 0 minutes.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Minutes has to be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <minutes> [<reason>]", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [FREEZE] ~ --
addCommandHandler("freeze",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if not isElementFrozen(target) then
						setElementFrozen(target, true)
						toggleAllControls(target, false, true, false)
						outputChatBox("You've been frozen by " .. getPlayerName(player) .. ", please wait for their orders and instructions.", target, 255, 0, 0, false)
						for i,v in ipairs(getElementsByType("player")) do
							if exports.brpExports:isPlayerAdmin(v) then
								outputChatBox("FREEZE: " .. getPlayerName(player) .. " froze " .. getPlayerName(target) .. ".", v, 255, 0, 0, false)
							end
						end
						outputServerLog("[ADMIN] [CMD/FREEZE]: " .. getPlayerName(player) .. " froze " .. getPlayerName(target) .. ".")
					else
						outputChatBox(getPlayerName(target) .. " is already frozen, failed.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [UNFREEZE] ~ --
addCommandHandler("unfreeze",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if isElementFrozen(target) then
						setElementFrozen(target, false)
						toggleAllControls(target, true, true, true)
						outputChatBox("You've been unfrozen by " .. getPlayerName(player) .. ".", target, 255, 0, 0, false)
						for i,v in ipairs(getElementsByType("player")) do
							if exports.brpExports:isPlayerAdmin(v) then
								outputChatBox("UNFREEZE: " .. getPlayerName(player) .. " unfroze " .. getPlayerName(target) .. ".", v, 255, 0, 0, false)
							end
						end
						outputServerLog("[ADMIN] [CMD/UNFREEZE]: " .. getPlayerName(player) .. " unfroze " .. getPlayerName(target) .. ".")
					else
						outputChatBox(getPlayerName(target) .. " is not frozen, failed.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [MUTE, UNMUTE] ~ --
addCommandHandler({"mute", "unmute"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if isPlayerMuted(target) then
						setPlayerMuted(target, false)
						outputChatBox("You've been unmuted by " .. getPlayerName(player) .. ".", target, 255, 0, 0, false)
						outputChatBox("You've unmuted " .. getPlayerName(target) .. ".", target, 255, 0, 0, false)
						outputServerLog("[ADMIN] [CMD/UNMUTE]: " .. getPlayerName(player) .. " unmuted " .. getPlayerName(target) .. ".")
					else
						setPlayerMuted(target, true)
						outputChatBox("You've been muted by " .. getPlayerName(player) .. ", please wait for orders and instructions.", target, 255, 0, 0, false)
						outputChatBox("You've muted " .. getPlayerName(target) .. ".", target, 255, 0, 0, false)
						outputServerLog("[ADMIN] [CMD/MUTE]: " .. getPlayerName(player) .. " muted " .. getPlayerName(target) .. ".")
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SLAP] ~ --
addCommandHandler("slap",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local x, y, z = getElementPosition(target)
					setElementPosition(target, x, y, z + 10)
					outputChatBox("You've been slapped by " .. getPlayerName(player) .. ".", target, 255, 0, 0, false)
					for i,v in ipairs(getElementsByType("player")) do
						if exports.brpExports:isPlayerAdmin(v) then
							outputChatBox("SLAP: " .. getPlayerName(player) .. " slapped " .. getPlayerName(target) .. ".", v, 255, 0, 0, false)
						end
					end
					outputServerLog("[ADMIN] [CMD/SLAP]: " .. getPlayerName(player) .. " slapped " .. getPlayerName(target) .. ".")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [HUGESLAP, HSLAP] ~ --
addCommandHandler({"hugeslap", "hslap"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local x, y, z = getElementPosition(target)
					setElementPosition(target, x, y, z + 50)
					outputChatBox("You've been hugeslapped by " .. getPlayerName(player) .. ".", target, 255, 0, 0, false)
					for i,v in ipairs(getElementsByType("player")) do
						if exports.brpExports:isPlayerAdmin(v) then
							outputChatBox("HUGESLAP: " .. getPlayerName(player) .. " hugeslapped " .. getPlayerName(target) .. ".", v, 255, 0, 0, false)
						end
					end
					outputServerLog("[ADMIN] [CMD/HUGESLAP]: " .. getPlayerName(player) .. " hugeslapped " .. getPlayerName(target) .. ".")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [CHANGENAME, SETNAME, EDITNAME] ~ --
addCommandHandler({"changename", "setname", "editname"},
	function(player, cmd, name, newname)
		if exports.brpExports:isPlayerAdmin(player) then
			if name and newname then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					setPlayerName(target, newname)
					outputChatBox(getPlayerName(player) .. " changed your name to " .. newname .. ".", target, 220, 220, 0, false)
					for i,v in ipairs(getElementsByType("player")) do
						if exports.brpExports:isPlayerAdmin(v) then
							outputChatBox(cmd .. ": " .. getPlayerName(player) .. " changed " .. getPlayerName(target) .. "'s name to " .. newname .. ".", v, 255, 0, 0, false)
						end
					end
					outputServerLog("[ADMIN] [CMD/CHANGENAME]: " .. getPlayerName(player) .. " changed " .. getPlayerName(target) .. "'s name to " .. newname .. ".")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <name>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETHEALTH, SETHP] ~ --
addCommandHandler({"sethealth", "sethp"},
	function(player, cmd, name, hp)
		if exports.brpExports:isPlayerAdmin(player) then
			if name and hp then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if tonumber(hp) >= 1 and tonumber(hp) <= 100 then
						setElementHealth(target, tonumber(hp))
						outputChatBox(getPlayerName(player) .. " changed your health to " .. tonumber(hp) .. ".", target, 220, 220, 0, false)
						outputChatBox("You changed " .. getPlayerName(target) .. "'s health to " .. tonumber(hp) .. ".", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/SETHEALTH]: " .. getPlayerName(player) .. " changed " .. getPlayerName(target) .. "'s health to " .. tonumber(hp) .. ".")
					elseif tonumber(hp) == 0 then
						killPed(target)
						outputChatBox(getPlayerName(player) .. " killed you.", target, 220, 220, 0, false)
						outputChatBox("You killed " .. getPlayerName(target) .. ".", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/SETHEALTH]: " .. getPlayerName(player) .. " killed " .. getPlayerName(target) .. ".")
					else
						outputChatBox("Health value must be within 0-100.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <value>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETARMOR, SETARMOUR] ~ --
addCommandHandler({"setarmor", "setarmour"},
	function(player, cmd, name, armor)
		if exports.brpExports:isPlayerAdmin(player) then
			if name and armor then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if tonumber(armor) >= 1 and tonumber(armor) <= 100 then
						setPedArmor(target, tonumber(armor))
						outputChatBox(getPlayerName(player) .. " changed your armor to " .. tonumber(armor) .. ".", target, 220, 220, 0, false)
						outputChatBox("You changed " .. getPlayerName(target) .. "'s armor to " .. tonumber(armor) .. ".", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/SETARMOR]: " .. getPlayerName(player) .. " changed " .. getPlayerName(target) .. "'s armor to " .. tonumber(armor) .. ".")
					elseif tonumber(armor) == 0 then
						killPed(target)
						outputChatBox(getPlayerName(player) .. " removed your armor.", target, 220, 220, 0, false)
						outputChatBox("You removed " .. getPlayerName(target) .. "'s armor.", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/SETARMOR]: " .. getPlayerName(player) .. " removed " .. getPlayerName(target) .. "'s armor.")
					else
						outputChatBox("Armor value must be within 0-100.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <value>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETSKIN] ~ --
addCommandHandler("setskin",
	function(player, cmd, name, skin)
		if exports.brpExports:isPlayerAdmin(player) then
			if name and skin then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if tonumber(skin) >= 0 and tonumber(skin) <= 312 then
						setElementModel(target, tonumber(skin))
						outputChatBox(getPlayerName(player) .. " changed your skin to " .. tonumber(skin) .. ".", target, 220, 220, 0, false)
						outputChatBox("You changed " .. getPlayerName(target) .. "'s skin to " .. tonumber(skin) .. ".", player, 220, 220, 0, false)
						outputServerLog("[ADMIN] [CMD/SETSKIN]: " .. getPlayerName(player) .. " changed " .. getPlayerName(target) .. "'s skin to " .. tonumber(skin) .. ".")
					elseif tonumber(skin) == 42 or tonumber(skin) == 65 or tonumber(skin) == 74 or tonumber(skin) == 86 or tonumber(skin) == 273 or tonumber(skin) == 289 then
						outputChatBox("Invalid skin.", player, 255, 0, 0, false)
					elseif tonumber(skin) >= 3 and tonumber(skin) <= 8 then
						outputChatBox("Invalid skin.", player, 255, 0, 0, false)
					else
						outputChatBox("Skin value must be within 0-312.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <value>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [GOTO, WT, WARPTO, TELEPORTTO, TPTO] ~ --
addCommandHandler({"goto", "wt", "warpto", "teleportto", "tpto"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local x, y, z = getElementPosition(target)
					setElementPosition(player, x + 3, y, z)
					setElementInterior(target, getElementInterior(player))
					setElementDimension(target, getElementDimension(player))
					outputChatBox(getPlayerName(player) .. " teleported to you.", target, 220, 220, 0, false)
					outputChatBox("You teleported to " .. getPlayerName(target) .. ".", player, 220, 220, 0, false)
					outputServerLog("[ADMIN] [CMD/GOTO]: " .. getPlayerName(player) .. " teleported to " .. getPlayerName(target) .. ".")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [GETHERE, GET, WH, WARPHERE] ~ --
addCommandHandler({"gethere", "get", "wh", "warphere"},
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					local x, y, z = getElementPosition(player)
					setElementPosition(target, x + 3, y, z)
					setElementInterior(target, getElementInterior(player))
					setElementDimension(target, getElementDimension(player))
					outputChatBox(getPlayerName(player) .. " teleported you to them.", target, 220, 220, 0, false)
					outputChatBox("You teleported " .. getPlayerName(target) .. " to you.", player, 220, 220, 0, false)
					outputServerLog("[ADMIN] [CMD/GETHERE]: " .. getPlayerName(player) .. " teleported " .. getPlayerName(target) .. " to them.")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SENDTO, SEND, TAKETO] ~ --
addCommandHandler({"sendto", "send", "taketo"},
	function(player, cmd, name1, name2)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local teleporter = exports.brpExports:findPlayer(name1, player)
				local teleported = exports.brpExports:findPlayer(name2, player)
				if teleporter and teleported then
					local x, y, z = getElementPosition(teleported)
					setElementPosition(teleporter, x + 3, y, z)
					setElementInterior(teleporter, getElementInterior(teleported))
					setElementDimension(teleporter, getElementDimension(teleported))
					outputChatBox(getPlayerName(player) .. " teleported " .. getPlayerName(teleporter) .. " to you.", teleported, 220, 220, 0, false)
					outputChatBox(getPlayerName(player) .. " teleported you to " .. getPlayerName(teleported) .. ".", teleporter, 220, 220, 0, false)
					outputServerLog("[ADMIN] [CMD/SENDTO]: " .. getPlayerName(player) .. " teleported " .. getPlayerName(teleporter) .. " to " .. getPlayerName(teleported) .. ".")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <target>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SERVERPASSWORD, SERVERPWD] ~ --
addCommandHandler({"serverpassword", "serverpwd"},
	function(player, cmd, password)
		if exports.brpExports:isPlayerHeadAdmin(player) then
			if password then
				setServerConfigSetting("password", tostring(password), false)
				outputChatBox("Server locked with password " .. tostring(password) .. ".", player, 220, 220, 0, false)
				outputServerLog("[ADMIN] [CMD/SERVERPASSWORD]: " .. getPlayerName(player) .. " changed the server password to " .. tostring(password) .. ".")
			else
				outputChatBox("Syntax: /" .. cmd .. " <password>", player, 220, 220, 0, false)
			end
		elseif getElementType(player) == "console" then
			if password then
				setServerConfigSetting("password", tostring(password), false)
				outputServerLog("Server locked with password " .. tostring(password) .. ".", player, 220, 220, 0, false)
			else
				outputServerLog("Syntax: /" .. cmd .. " <password>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [RELOADACL] ~ --
addCommandHandler("reloadacl",
	function(player, cmd)
		if exports.brpExports:isPlayerHeadAdmin(player) then
			aclReload()
			outputChatBox("Server ACL reloaded.", player, 220, 220, 0, false)
			outputServerLog("[ADMIN] [CMD/RELOADACL]: " .. getPlayerName(player) .. " reloaded the ACL.")
		elseif getElementType(player) == "console" then
			aclReload()
			outputServerLog("Server ACL reloaded.", player, 220, 220, 0, false)
		end
	end
)

-- ~ [RELOADBANS] ~ --
addCommandHandler("reloadbans",
	function(player, cmd)
		if exports.brpExports:isPlayerHeadAdmin(player) then
			reloadBans()
			outputChatBox("Server ban list reloaded.", player, 220, 220, 0, false)
			outputServerLog("[ADMIN] [CMD/RELOADBANS]: " .. getPlayerName(player) .. " reloaded the ban list.")
		elseif getElementType(player) == "console" then
			reloadBans()
			outputServerLog("Server ban list reloaded.", player, 220, 220, 0, false)
		end
	end
)

-- ~ [RELOADALL] ~ --
addCommandHandler("reloadall",
	function(player, cmd)
		if exports.brpExports:isPlayerHeadAdmin(player) then
			aclReload()
			reloadBans()
			outputChatBox("Server ACL and ban list reloaded.", player, 220, 220, 0, false)
			outputServerLog("[ADMIN] [CMD/RELOADALL]: " .. getPlayerName(player) .. " reloaded the ACL and ban list.")
		elseif getElementType(player) == "console" then
			aclReload()
			reloadBans()
			outputServerLog("Server ACL and ban list reloaded.")
		end
	end
)

-- ~ [CHECK] ~ --
addCommandHandler("check",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					outputChatBox(getPlayerName(target) .. "'s data:", player, 200, 200, 0, false)
					outputChatBox(" Health: " .. getElementHealth(target), player, 220, 220, 0, false)
					outputChatBox(" Armor: " .. getPedArmor(target), player, 220, 220, 0, false)
					outputChatBox(" Money: " .. getPlayerMoney(target), player, 220, 220, 0, false)
					outputChatBox(" Faction: " .. getElementData(target, "factions.fplayer") .. " (Leader: " .. getElementData(target, "factions.leader") .. ")", player, 220, 220, 0, false)
					outputChatBox(" Model: " .. getElementModel(target), player, 220, 220, 0, false)
					outputServerLog("[ADMIN] [CMD/CHECK]: " .. getPlayerName(player) .. " checked " .. getPlayerName(target) .. "'s information.")
				else
					outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [HIDEADMIN] ~ --
addCommandHandler("hideadmin",
	function(player, cmd)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if not getElementData(player, "admin.hidden") then
				setPlayerNametagColor(player, 255, 255, 255)
				setElementData(player, "admin.hidden", 1)
				outputServerLog("[ADMIN] [CMD/HIDEADMIN]: " .. getPlayerName(player) .. " enabled hidden admin mode.")
				
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:isPlayerAdmin(v) then
						outputChatBox(getPlayerName(player) .. " went in hidden admin mode.", v, 255, 0, 0, false)
					end
				end
			else
				setPlayerNametagColor(player, 255, 255, 0)
				removeElementData(player, "admin.hidden")
				outputServerLog("[ADMIN] [CMD/HIDEADMIN]: " .. getPlayerName(player) .. " disabled hidden admin mode.")
				
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:isPlayerAdmin(v) then
						outputChatBox(getPlayerName(player) .. " came from hidden admin mode.", v, 255, 0, 0, false)
					end
				end
			end
		end
	end
)

-- ~ [ADMINDUTY] ~ --
addCommandHandler("adminduty",
	function(player, cmd)
		if exports.brpExports:isPlayerAdmin(player) then
			if getElementData(player, "admin.duty") == 1 then
				setPlayerNametagColor(player, 255, 255, 255)
				setElementData(player, "admin.duty", 0)
				outputServerLog("[ADMIN] [CMD/ADMINDUTY]: " .. getPlayerName(player) .. " went off duty.")
				
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:isPlayerAdmin(v) then
						outputChatBox(getPlayerName(player) .. " went off duty.", v, 255, 0, 0, false)
					end
				end
			else
				setPlayerNametagColor(player, 255, 255, 0)
				setElementData(player, "admin.duty", 1)
				outputServerLog("[ADMIN] [CMD/ADMINDUTY]: " .. getPlayerName(player) .. " came on duty.")
				
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:isPlayerAdmin(v) then
						outputChatBox(getPlayerName(player) .. " came on duty.", v, 255, 0, 0, false)
					end
				end
			end
		end
	end
)

-- ~ [MAKEADMIN] ~ --
addCommandHandler({"makeadmin", "addadmin", "setadmin", "setadminlevel", "adminlevel", "admin"},
	function(player, cmd, name, level)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if name and level then
				if tonumber(level) then
					local target = exports.brpExports:findPlayer(name, player)
					if target then
						if tonumber(level) == 0 then
							if not getElementData(target, "admin.level") then
								outputChatBox("Player is not an administrator.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to reset " .. getPlayerName(target) .. "'s admin level but failed because the player is not an administrator.")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox(getPlayerName(target) .. "'s admin levels reseted.", player, 0, 255, 0, false)
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox(getPlayerName(target) .. "'s admin levels reseted.", player, 0, 255, 0, false)
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox(getPlayerName(target) .. "'s admin levels reseted.", player, 0, 255, 0, false)
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 4 then
								outputChatBox("Ha! You just got logged for trying to reset owner's admin level!", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to reset " .. getPlayerName(target) .. "'s admin level but failed because the player is a server owner.")
							end
							
							aclSave()
						elseif tonumber(level) == 1 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 1 (trial administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								outputChatBox("Player is already a trial administrator.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 1 (trial administrator) but failed because the player is already a trial administrator.")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 1 (trial administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 1 (trial administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 4 then
								outputChatBox("Ha! You just got logged for trying to set owner's admin level as trial administrator!", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 1 (trial administrator) but failed because the player is a server owner.")
							end
							
							aclSave()
						elseif tonumber(level) == 2 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 2 (game administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 2 (game administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 2 then
								outputChatBox("Player is already a game administrator.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 2 (game administrator) but failed because the player is already a game administrator.")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 2 (game administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 4 then
								outputChatBox("Ha! You just got logged for trying to set owner's admin level as game administrator!", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 2 (game administrator) but failed because the player is a server owner.")
							end
							
							aclSave()
						elseif tonumber(level) == 3 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 3 (lead administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 3 (lead administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 3 (lead administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 3 then
								outputChatBox("Player is already a lead administrator.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 3 (lead administrator) but failed because the player is already a lead administrator.")
							elseif getElementData(target, "admin.level") == 4 then
								outputChatBox("Ha! You just got logged for trying to set owner's admin level as lead administrator!", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 3 (lead administrator) but failed because the player is a server owner.")
							end
							
							aclSave()
						else
							outputChatBox("Invalid admin level inserted (0, 1, 2, 3)", player, 255, 0, 0, false)
						end
					else
						outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Level value must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <1: trial, 2: admin, 3: lead>", player, 220, 220, 0, false)
			end
		elseif exports.brpExports:isPlayerHeadAdmin(player) then
			if name and level then
				if tonumber(level) then
					local target = exports.brpExports:findPlayer(name, player)
					if target then
						if tonumber(level) == 0 then
							if not getElementData(target, "admin.level") then
								outputChatBox("Player is not an administrator.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to reset " .. getPlayerName(target) .. "'s admin level but failed because the player is not an administrator.")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox(getPlayerName(target) .. "'s admin levels reseted.", player, 0, 255, 0, false)
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox(getPlayerName(target) .. "'s admin levels reseted.", player, 0, 255, 0, false)
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox(getPlayerName(target) .. "'s admin levels reseted.", player, 0, 255, 0, false)
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 4 then
								aclGroupRemoveObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox(getPlayerName(target) .. "'s admin levels reseted.", player, 0, 255, 0, false)
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							end
							
							aclSave()
						elseif tonumber(level) == 1 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 1 (trial administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								outputChatBox("Player is already a trial administrator.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 1 (trial administrator) but failed because the player is already a trial administrator.")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 1 (trial administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 1 (trial administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 4 then
								aclGroupRemoveObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 1 (trial administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							end
							
							aclSave()
						elseif tonumber(level) == 2 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 2 (game administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 2 (game administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 2 then
								outputChatBox("Player is already a game administrator.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 2 (game administrator) but failed because the player is already a game administrator.")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 2 (game administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 4 then
								aclGroupRemoveObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 2 (game administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							end
							
							aclSave()
						elseif tonumber(level) == 3 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 3 (lead administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 3 (lead administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 3 (lead administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 3 then
								outputChatBox("Player is already a lead administrator.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 3 (lead administrator) but failed because the player is already a lead administrator.")
							elseif getElementData(target, "admin.level") == 4 then
								aclGroupRemoveObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 3 (lead administrator).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							end
							
							aclSave()
						elseif tonumber(level) == 4 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 4)
								aclGroupAddObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 4 (server owner).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 4 (server owner).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 4 (server owner).")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 4)
								aclGroupAddObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 4 (server owner).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 4 (server owner).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 4 (server owner).")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 4)
								aclGroupAddObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 4 (server owner).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 4 (server owner).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 4 (server owner).")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 4)
								aclGroupAddObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox(getPlayerName(target) .. "'s admin level set to 4 (server owner).", player, 0, 255, 0, false)
								outputChatBox("Your admin level was set to 4 (server owner).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 4 (server owner).")
							elseif getElementData(target, "admin.level") == 4 then
								outputChatBox("Player is already a server owner.", player, 255, 0, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 4 (server owner) but failed because the player is already a server owner.")
							end
							
							aclSave()
						else
							outputChatBox("Invalid admin level inserted (0, 1, 2, 3, 4)", player, 255, 0, 0, false)
						end
					else
						outputChatBox("No players or multiple were found.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Level value needs to be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player> <1: trial, 2: admin, 3: lead, 4: owner>", player, 220, 220, 0, false)
			end
		elseif getElementType(player) == "console" then
			if name and level then
				if tonumber(level) then
					local target = exports.brpExports:findPlayer(name, player)
					if target then
						if tonumber(level) == 0 then
							if not getElementData(target, "admin.level") then
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to reset " .. getPlayerName(target) .. "'s admin level but failed because the player is not an administrator.")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							elseif getElementData(target, "admin.level") == 4 then
								aclGroupRemoveObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								removeElementData(target, "admin.level")
								outputChatBox("Your admin levels are reseted.", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " reseted " .. getPlayerName(target) .. "'s admin level.")
							end
							
							aclSave()
						elseif tonumber(level) == 1 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 1 (trial administrator) but failed because the player is already a trial administrator.")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							elseif getElementData(target, "admin.level") == 4 then
								aclGroupRemoveObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 1)
								aclGroupAddObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 1 (trial administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 1 (trial administrator).")
							end
							
							aclSave()
						elseif tonumber(level) == 2 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 2 then
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 2 (game administrator) but failed because the player is already a game administrator.")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							elseif getElementData(target, "admin.level") == 4 then
								aclGroupRemoveObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 2)
								aclGroupAddObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 2 (game administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 2 (game administrator).")
							end
							
							aclSave()
						elseif tonumber(level) == 3 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							elseif getElementData(target, "admin.level") == 3 then
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 3 (lead administrator) but failed because the player is already a lead administrator.")
							elseif getElementData(target, "admin.level") == 4 then
								aclGroupRemoveObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 3)
								aclGroupAddObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 3 (lead administrator).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 3 (lead administrator).")
							end
							
							aclSave()
						elseif tonumber(level) == 4 then
							if not getElementData(target, "admin.level") then
								setElementData(target, "admin.level", 4)
								aclGroupAddObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 4 (server owner).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 4 (server owner).")
							elseif getElementData(target, "admin.level") == 1 then
								aclGroupRemoveObject(aclGetGroup("Trial Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 4)
								aclGroupAddObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 4 (server owner).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 4 (server owner).")
							elseif getElementData(target, "admin.level") == 2 then
								aclGroupRemoveObject(aclGetGroup("Game Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 4)
								aclGroupAddObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 4 (server owner).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 4 (server owner).")
							elseif getElementData(target, "admin.level") == 3 then
								aclGroupRemoveObject(aclGetGroup("Lead Administrator"), "user." .. getAccountName(getPlayerAccount(target)))
								setElementData(target, "admin.level", 4)
								aclGroupAddObject(aclGetGroup("Server Owner"), "user." .. getAccountName(getPlayerAccount(target)))
								outputChatBox("Your admin level was set to 4 (server owner).", target, 220, 220, 0, false)
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " set " .. getPlayerName(target) .. "'s admin level to 4 (server owner).")
							elseif getElementData(target, "admin.level") == 4 then
								outputServerLog("[ADMIN] [CMD/MAKEADMIN]: " .. getPlayerName(player) .. " tried to set " .. getPlayerName(target) .. "'s admin level as 4 (server owner) but failed because the player is already a server owner.")
							end
							
							aclSave()
						else
							outputServerLog("ERROR: Invalid admin level inserted (0, 1, 2, 3, 4)")
						end
					else
						outputServerLog("ERROR: No players or multiple were found.")
					end
				else
					outputServerLog("Level value needs to be numbers.")
				end
			else
				outputServerLog("Syntax: " .. cmd .. " <player> <1: trial, 2: admin, 3: lead, 4: owner>")
			end
		end
	end
)

-- ~ [RESCHECK, RESOURCECHECK] ~ --
addCommandHandler({"rescheck", "resourcecheck"},
	function(player, cmd)
		if exports.brpExports:isPlayerHeadAdmin(player) then
			local resources = getResources()
			
			outputChatBox("Resources:", player, 200, 200, 0, false)
			
			for i,v in ipairs(resources) do
				local name = getResourceName(v)
				outputChatBox(" " .. tostring(name) .. " resource state: " .. getResourceState(getResourceFromName(name)) .. ".", player, 220, 220, 0, false)
			end
			
			outputChatBox(" ", player, 255, 255, 255, false)
			outputChatBox("If a resource wasn't running - start it, all resources in the list should be running.", player, 255, 255, 255, false)
			outputServerLog("[ADMIN] [CMD/RESCHECK]: " .. getPlayerName(player) .. " checked all resources.")
		elseif getElementType(player) == "console" then
			local resources = getResources()
			
			outputServerLog("Resources:", player, 200, 200, 0, false)
			
			for i,v in ipairs(resources) do
				local name = getResourceName(v)
				outputServerLog(" " .. tostring(name) .. " resource state: " .. getResourceState(getResourceFromName(name)) .. ".", player, 220, 220, 0, false)
			end
			
			outputServerLog(" ", player, 255, 255, 255, false)
			outputServerLog("If a resource wasn't running - start it, all resources in the list should be running.", player, 255, 255, 255, false)
		end
	end
)

-- ~ [RESTARTALL, RESTARTALLRESOURCES, RESTARTRESOURCES] ~ --
addCommandHandler({"restartall", "restartallresources", "restartresources"},
	function(player, cmd)
		if exports.brpExports:isPlayerHeadAdmin(player) then
			local resources = getResources()
			
			outputChatBox("Restarting all resources...", player, 220, 220, 0, false)
			outputServerLog("[ADMIN] [CMD/RESTARTALL]: " .. getPlayerName(player) .. " restarted all resources.")
			
			for i,v in ipairs(resources) do
				if getResourceState(v) == "running" then
					restartResource(getResourceFromName(getResourceName(v)))
				end
			end
		elseif getElementType(player) == "console" then
			local resources = getResources()
			
			outputChatBox("Restarting all resources...", player, 220, 220, 0, false)
			
			for i,v in ipairs(resources) do
				if getResourceState(v) == "running" then
					restartResource(getResourceFromName(getResourceName(v)))
				end
			end
		end
	end
)

-- ~ [STOPALL, STOPALLRESOURCES, STOPRESOURCES] ~ --
addCommandHandler({"stopall", "stopallresources", "stopresources"},
	function(player, cmd)
		if exports.brpExports:isPlayerHeadAdmin(player) then
			local resources = getResources()
			
			outputChatBox("Stopping all resources...", player, 220, 220, 0, false)
			outputServerLog("[ADMIN] [CMD/STOPALL]: " .. getPlayerName(player) .. " stopped all resources.")
			
			for i,v in ipairs(resources) do
				if getResourceState(v) == "running" then
					stopResource(getResourceFromName(getResourceName(v)))
				end
			end
		elseif getElementType(player) == "console" then
			local resources = getResources()
			
			outputChatBox("Stopping all resources...", player, 220, 220, 0, false)
			
			for i,v in ipairs(resources) do
				if getResourceState(v) == "running" then
					stopResource(getResourceFromName(getResourceName(v)))
				end
			end
		end
	end
)

-- ~ [STARTALL, STARTALLRESOURCES, STARTRESOURCES] ~ --
addCommandHandler({"startall", "startallresources", "startresources"},
	function(player, cmd)
		if exports.brpExports:isPlayerHeadAdmin(player) then
			local resources = getResources()
			
			outputChatBox("Starting all resources...", player, 220, 220, 0, false)
			outputServerLog("[ADMIN] [CMD/STARTALL]: " .. getPlayerName(player) .. " started all resources.")
			
			for i,v in ipairs(resources) do
				if getResourceState(v) ~= "running" then
					startResource(getResourceFromName(getResourceName(v)))
				end
			end
		elseif getElementType(player) == "console" then
			local resources = getResources()
			
			outputServerLog("Starting all resources...", player, 220, 220, 0, false)
			
			for i,v in ipairs(resources) do
				if getResourceState(v) ~= "running" then
					startResource(getResourceFromName(getResourceName(v)))
				end
			end
		end
	end
)