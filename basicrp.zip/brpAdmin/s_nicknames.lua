--[[
	Basic Roleplay Gamemode
	~ Server-side functions for disallowed nicknames
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
addEventHandler("onPlayerJoin", cRoot,
	function()
		if string.lower(getPlayerName(source)) == string.lower("Player") then
			local name = "Player" .. math.random(1000,9999)
				while getPlayerFromName(name) do
					name = "Player" .. math.random(1000,9999)
				end
			setPlayerName(source, name)
		end
	end
)

addEventHandler("onPlayerChangeNick", cRoot,
	function(oldNick, newNick)
		if string.lower(newNick) == "player" then
			cancelEvent()
			outputChatBox("Name 'Player' is not allowed on our server.", source, 255, 0, 0, true)
			outputChatBox("Go to MTA settings or do /nick playername to change your nick.", source, 220, 220, 0, true)
		end
	end
)