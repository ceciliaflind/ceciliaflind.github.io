--[[
	Basic Roleplay Gamemode
	~ Server-side functions for teleports
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local places = {
	-- ID : Name, x position, y position, z position, interior, dimension
	ls = {"Los Santos", 1541.84, -1675.55, 13.55, 0, 0},
	sf = {"San Fierro", -1749.02, 858.08, 24.88, 0, 0},
	lv = {"Las Venturas", 1692.37, 1444.35, 10.76, 0, 0},
	igs = {"Idlewood Gas Station", 1951.87, -1772.63, 13.54, 0, 0}
}

-- ~ [GOTOPLACE] ~ --
addCommandHandler("gotoplace",
	function(player, cmd, place)
		if exports.brpExports:isPlayerAdmin(player) then
			if place then
				if places[place:lower()] then
					local x, y, z = places[place][2], places[place][3], places[place][4]
					local interior = places[place][5]
					local dimension = places[place][6]
					setElementPosition(player, x, y, z)
					setElementInterior(player, interior)
					setElementDimension(player, dimension)
					outputChatBox("You teleported to '" .. places[place][1] .. "'.", player, 220, 220, 0, false)
					outputServerLog("[ADMIN] [CMD/GOTOPLACE]: " .. getPlayerName(player) .. " teleported to '" .. places[place][1] .. "' [" .. place .. "].")
				else
					outputChatBox("Invalid place ID.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <id: ls/sf/lv/igs>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [XYZ] ~ --
addCommandHandler("xyz",
	function(player, cmd, x, y, z)
		if exports.brpExports:isPlayerAdmin(player) then
			local x, y, z = tonumber(x), tonumber(y), tonumber(z)
			if x and y and z then
				setElementPosition(player, x, y, z)
				outputChatBox("Position set.", player, 220, 220, 0, false)
				outputServerLog("[ADMIN] [CMD/XYZ]: " .. getPlayerName(player) .. " set their position to " .. x .. ", " .. y .. ", " .. z .. ".")
			else
				outputChatBox("Syntax: /xyz <x> <y> <z>", player, 220, 220, 0, false)
			end
		end
	end
)