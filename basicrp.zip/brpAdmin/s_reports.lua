--[[
	Basic Roleplay Gamemode
	~ Server-side functions for reports
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

-- ~ [REPORT] ~ --
addCommandHandler("report",
	function(player, cmd, name, ...)
		if name and (...) then
			local message = table.concat({ ... }, " ")
			if #message > 0 then
				if not getElementData(player, "report.reportername") then
					if name ~= "-" then
						local target = exports.brpExports:findPlayer(name, player)
						if target then
							local tarAccount = getPlayerAccount(target)
							if not isGuestAccount(tarAccount) then
								local hour, minutes = getTime()
								setElementData(player, "report.reportername", getPlayerName(player))
								setElementData(player, "report.reportedname", getPlayerName(target))
								setElementData(player, "report.reported", getAccountName(tarAccount))
								setElementData(player, "report.time", hour .. ":" .. minutes)
								setElementData(player, "report.report", message)
								setElementData(player, "report.admin", false)
								outputChatBox("Thank you for reporting. An administrator will handle your report soon.", player, 0, 255, 0, false)
								for i,v in ipairs(getElementsByType("player")) do
									if exports.brpExports:isPlayerAdmin(v) then
										outputChatBox("[" .. hour .. ":" .. minutes .. "] " .. getPlayerName(player) .. " reported " .. getPlayerName(target) .. ".", v, 255, 255, 0, false)
										outputChatBox("[" .. hour .. ":" .. minutes .. "] " .. message, v, 255, 255, 0, false)
									end
								end
							else
								outputChatBox("That player haven't logged in yet.", player, 255, 0, 0, false)
							end
						else
							outputChatBox("Couldn't find such player.", player, 255, 0, 0, false)
						end
					else
						local hour, minutes = getTime()
						setElementData(player, "report.reportername", getPlayerName(player))
						setElementData(player, "report.reportedname", getPlayerName(player))
						setElementData(player, "report.reported", getAccountName(getPlayerAccount(player)))
						setElementData(player, "report.time", hour .. ":" .. minutes)
						setElementData(player, "report.report", message)
						setElementData(player, "report.admin", false)
						outputChatBox("Thank you for reporting. An administrator will handle your report soon.", player, 0, 255, 0, false)
						for i,v in ipairs(getElementsByType("player")) do
							if exports.brpExports:isPlayerAdmin(v) then
								outputChatBox("[" .. hour .. ":" .. minutes .. "] " .. getPlayerName(player) .. " reported " .. getPlayerName(player) .. ".", v, 255, 255, 0, false)
								outputChatBox("[" .. hour .. ":" .. minutes .. "] " .. message, v, 255, 255, 0, false)
							end
						end
					end
				else
					outputChatBox("You have a report pending. To make a new report, use /endreport to close the existing one.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player or -> <report>", player, 220, 220, 0, false)
			end
		else
			outputChatBox("Syntax: /" .. cmd .. " <player or -> <report>", player, 220, 220, 0, false)
		end
	end
)

addCommandHandler("ar",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if getElementData(target, "report.reportername") then
						if getElementData(target, "report.admin") == false then
							setElementData(target, "report.admin", getAccountName(getPlayerAccount(player)))
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox(getPlayerName(player) .. " accepted a report (" .. getPlayerName(target) .. ").", v, 255, 255, 0, false)
								end
							end
							outputChatBox("Admin " .. getPlayerName(player) .. " has accepted your report. Please wait for them to respond.", target, 220, 220, 0, false)
						else
							outputChatBox("That report is already being handled.", player, 255, 0, 0, false)
						end
					else
						outputChatBox(getPlayerName(target) .. " doesn't have any reports open.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Couldn't find such player/report.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

addCommandHandler("cr",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if getElementData(target, "report.reportername") then
						if getElementData(target, "report.admin") == getAccountName(getPlayerAccount(player)) then
							removeElementData(target, "report.reportername")
							removeElementData(target, "report.reportedname")
							removeElementData(target, "report.reported")
							removeElementData(target, "report.time")
							removeElementData(target, "report.report")
							removeElementData(target, "report.admin")
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox(getPlayerName(player) .. " closed a report (" .. getPlayerName(target) .. ").", v, 255, 255, 0, false)
								end
							end
							outputChatBox("Admin " .. getPlayerName(player) .. " has closed your report. If else, report again.", target, 220, 220, 0, false)
						else
							outputChatBox("That's not your report.", player, 255, 0, 0, false)
						end
					else
						outputChatBox(getPlayerName(target) .. " doesn't have any reports open.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Couldn't find such player/report.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

addCommandHandler("fr",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if getElementData(target, "report.reportername") then
						if getElementData(target, "report.admin") == false then
							removeElementData(target, "report.reportername")
							removeElementData(target, "report.reportedname")
							removeElementData(target, "report.reported")
							removeElementData(target, "report.time")
							removeElementData(target, "report.report")
							removeElementData(target, "report.admin")
							for i,v in ipairs(getElementsByType("player")) do
								if exports.brpExports:isPlayerAdmin(v) then
									outputChatBox(getPlayerName(player) .. " marked " .. getPlayerName(target) .. "'s report as false.", v, 255, 255, 0, false)
								end
							end
							outputChatBox("Admin " .. getPlayerName(player) .. " has marked your report as false. If else, report again.", target, 220, 220, 0, false)
						else
							outputChatBox("To false a report, it must be pending.", player, 255, 0, 0, false)
						end
					else
						outputChatBox(getPlayerName(target) .. " doesn't have any reports open.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Couldn't find such player/report.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

addCommandHandler("ri",
	function(player, cmd, name)
		if exports.brpExports:isPlayerAdmin(player) then
			if name then
				local target = exports.brpExports:findPlayer(name, player)
				if target then
					if getElementData(target, "report.reportername") then
						outputChatBox(" [" .. getElementData(target, "report.time") .. "] " .. getPlayerName(target) .. " reported " .. getElementData(target, "report.reportedname") .. ".", player, 255, 255, 0, false)
						outputChatBox(" [" .. getElementData(target, "report.time") .. "] " .. getElementData(target, "report.report"), player, 255, 255, 0, false)
					else
						outputChatBox(getPlayerName(target) .. " doesn't have any reports open.", player, 255, 0, 0, false)
					end
				else
					outputChatBox("Couldn't find such player/report.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <player>", player, 220, 220, 0, false)
			end
		end
	end
)

-- Do not change this integer
local openreports = 0

addCommandHandler("reports",
	function(player, cmd)
		if exports.brpExports:isPlayerAdmin(player) then
			outputChatBox("Reports:", player)
			for i,v in ipairs(getElementsByType("player")) do
				if getElementData(v, "report.reportername") then
					if getElementData(v, "report.admin") ~= false then
						outputChatBox(" [" .. getElementData(v, "report.time") .. "] " .. getPlayerName(v) .. " reported " .. getElementData(v, "report.reportedname") .. ". Handler: " .. getElementData(v, "report.admin") .. ".", player, 255, 255, 0, false)
					else
						outputChatBox(" [" .. getElementData(v, "report.time") .. "] " .. getPlayerName(v) .. " reported " .. getElementData(v, "report.reportedname") .. ". Handler: None.", player, 255, 255, 0, false)
					end
					openreports = 1
				end
			end
			
			if openreports == 0 then
				outputChatBox(" No active reports at the moment.", player, 255, 0, 0, false)
			else
				outputChatBox(" To read a report, type /ri <player>", player, 255, 255, 0, false)
				openreports = 0
			end
		end
	end
)

addCommandHandler("endreport",
	function(player, cmd)
		if getElementData(player, "report.time") then
			removeElementData(player, "report.reportername")
			removeElementData(player, "report.reportedname")
			removeElementData(player, "report.reported")
			removeElementData(player, "report.time")
			removeElementData(player, "report.report")
			removeElementData(player, "report.admin")
			for i,v in ipairs(getElementsByType("player")) do
				if exports.brpExports:isPlayerAdmin(v) then
					outputChatBox(getPlayerName(player) .. " closed their report.", v, 255, 255, 0, false)
				end
			end
			outputChatBox("You closed your report. If else, report again.", player, 220, 220, 0, false)
		else
			outputChatBox("You have no pending reports at the moment. Type /report to make one.", player, 255, 0, 0, false)
		end
	end
)