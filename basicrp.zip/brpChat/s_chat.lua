--[[
	Basic Roleplay Gamemode
	~ Server-side functions for chat
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

-- ~ [CLEARCHAT] ~ --
addCommandHandler("clearchat",
	function(player, cmd)
		for i=1,50 do
			outputChatBox(" ", player)
		end
		outputServerLog("[CHAT] [CMD/CLEARCHAT]: " .. getPlayerName(player) .. " cleared their chatbox.")
	end
)

addEventHandler("onPlayerChat", cRoot,
	function(message, type)
		cancelEvent()
		if not isPedDead(source) then
			local px, py, pz = getElementPosition(source)
			if type == 0 then
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:isElementInRangeOfPoint(v, px, py, pz, 20) then
						outputChatBox(" " .. getPlayerName(source) .. " says: " .. message, v, 230, 230, 230, false)
					end
				end
				outputServerLog("[CHAT] [CMD/SAY]: " .. getPlayerName(source) .. " says: " .. message)
			elseif type == 1 then
				for i,v in ipairs(getElementsByType("player")) do
					if exports.brpExports:isElementInRangeOfPoint(v, px, py, pz, 20) then
						outputChatBox(" *" .. getPlayerName(source) .. " " .. message, v, 255, 40, 80, false)
					end
				end
				outputServerLog("[CHAT] [CMD/ME]: " .. getPlayerName(source) .. " " .. message)
			end
		end
	end
)

-- ~ [R] ~ --
addCommandHandler({"r", "radio", "teamsay"},
	function(player, cmd, ...)
		if exports.brpExports:isPlayerInFaction(player) then
			local message = table.concat({ ... }, " ")
			if #message > 0 then
				for i,v in ipairs(getElementsByType("player")) do
					if getElementData(v, "factions.player") == getElementData(player, "factions.player") then
						outputChatBox("[RADIO] " .. getPlayerName(player) .. ": " .. message, v, 120, 120, 255, false)
					end
				end
				outputServerLog("[CHAT] [CMD/R]: " .. getPlayerName(player) .. ": " .. message)
			else
				outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
			end
		else
			outputChatBox("You're not in a faction.", player, 255, 0, 0, false)
		end
	end
)

-- ~ [F] ~ --
addCommandHandler("f",
	function(player, cmd, ...)
		if exports.brpExports:isPlayerInFaction(player) then
			local message = table.concat({ ... }, " ")
			if #message > 0 then
				for i,v in ipairs(getElementsByType("player")) do
					if getElementData(v, "factions.player") == getElementData(player, "factions.player") then
						outputChatBox("[FACTION] " .. getPlayerName(player) .. ": " .. message, v, 0, 255, 255, false)
					end
				end
				outputServerLog("[CHAT] [CMD/F]: " .. getPlayerName(player) .. ": " .. message)
			else
				outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
			end
		else
			outputChatBox("You're not in a faction.", player, 255, 0, 0, false)
		end
	end
)

-- ~ [D] ~ --
addCommandHandler({"d", "department"},
	function(player, cmd, ...)
		if exports.brpExports:isPlayerInFaction(player) then
			local message = table.concat({ ... }, " ")
			if #message > 0 then
				for index,ped in ipairs(getElementsByType("ped")) do
					if exports.brpExports:isDepartmentRadioAllowed(ped) then
						for i,v in ipairs(getElementsByType("player")) do
							if tonumber(getElementData(v, "factions.player")) == tonumber(getElementData(ped, "factions.id")) then
								outputChatBox("[DEPARTMENT] " .. getPlayerName(player) .. ": " .. message, v, 120, 120, 255, false)
							end
						end
					end
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
			end
		else
			outputChatBox("You're not in a faction.", player, 255, 0, 0, false)
		end
	end
)

-- ~ [DO] ~ --
addCommandHandler("do",
	function(player, cmd, ...)
		local message = table.concat({ ... }, " ")
		if #message > 0 then
			local px, py, pz = getElementPosition(player)
			for i,v in ipairs(getElementsByType("player")) do
				local tx, ty, tz = getElementPosition(v)
				if exports.brpExports:isElementInRangeOfPoint(v, px, py, pz, 20) then
					outputChatBox(" *" .. message .. " ((" .. getPlayerName(player) .. "))", v, 255, 40, 80, false)
					outputServerLog("[CHAT] [CMD/DO]: *" .. message .. " (" .. getPlayerName(player) .. ")")
				end
			end
		else
			outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
		end
	end
)

-- ~ [M, MEGAPHONE, MP] ~ --
addCommandHandler({"m", "megaphone", "mp"},
	function(player, cmd, ...)
		local message = table.concat({ ... }, " ")
		if #message > 0 then
			local px, py, pz = getElementPosition(player)
			for i,v in ipairs(getElementsByType("player")) do
				local tx, ty, tz = getElementPosition(v)
				if exports.brpExports:isElementInRangeOfPoint(v, px, py, pz, 30) then
					outputChatBox(" Megaphone around the area: " .. message, v, 255, 255, 0, false)
					outputServerLog("[CHAT] [CMD/M]: Megaphone around the area (" .. getPlayerName(player) .. "): " .. message)
				end
			end
		else
			outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
		end
	end
)

-- ~ [O, LOCALOOC, B, LOOC] ~ --
addCommandHandler({"o", "localooc", "b", "looc"},
	function(player, cmd, ...)
		local message = table.concat({ ... }, " ")
		if #message > 0 then
			local px, py, pz = getElementPosition(player)
			for i,v in ipairs(getElementsByType("player")) do
				local tx, ty, tz = getElementPosition(v)
				if exports.brpExports:isElementInRangeOfPoint(v, px, py, pz, 20) then
					outputChatBox(" " .. getPlayerName(player) .. ": (( " .. message .. " ))", v, 230, 230, 230, false)
					outputServerLog("[CHAT] [CMD/LOCALOOC]: (" .. getPlayerName(player) .. "): (( " .. message .. " ))")
				end
			end
		else
			outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
		end
	end
)

addEventHandler("onResourceStart", cThisRoot,
	function()
		for i,v in ipairs(getElementsByType("player")) do
			bindKey(v, "b", "down", "chatbox", "o")
			bindKey(v, "u", "down", "chatbox", "ooc")
		end
	end
)

-- ~ [OOC, GLOBALOOC, GOOC] ~ --
addCommandHandler({"ooc", "globalooc", "gooc"},
	function(player, cmd, ...)
		local message = table.concat({ ... }, " ")
		if #message > 0 then
			outputChatBox("(( " .. getPlayerName(player) .. ": " .. message .. " ))", cRoot, 230, 230, 230, false)
			outputServerLog("[CHAT] [CMD/GLOBALOOC]: " .. getPlayerName(player) .. ": " .. message)
		else
			outputChatBox("Syntax: /" .. cmd .. " <message>", player, 220, 220, 0, false)
		end
	end
)