WELCOME
Thank you for downloading Basic Roleplay gamemode by Socialz.

DISCLAIMER
Socialz is not responsible for any harm towards your computer, server or scripts.
Socialz is not responsible to help you with this gamemode in any way.
Socialz is not responsible for your own modifications and edits towards this gamemode.

OTHER INFORMATION
This gamemode is using parts from the following scripts:
 - MTA PARADISE (Creator: mabako)
 - MTA VALHALLA GAMING (Creator: Daniels, mabako, Mount, Cyanide)

Socialz is giving full support to the above scripts and their creators.

This gamemode uses less than 5 percent of the above scripts.

By downloading this resource you have concluded to respect the owner's work.

FILES
I have included acl.xml and mtaserver.conf files in the package so that you can easily start
using the gamemode.

CONTACT DETAILS
e-mail: socialz.fin@gmail.com
mtasa forums: www.forum.mtasa.com/memberlist.php?mode=viewprofile&u=55648
website: www.socialz.comuv.com

=============================

If you have questions or issues with this script, you shall ask for help on the official
thread on MTA:SA forums. I am not responsible to help you, but I'll try to if I have time.

-Socialz