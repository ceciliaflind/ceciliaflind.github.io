﻿--[[
	Basic Roleplay Gamemode
	~ Client-side functions for weapon reload
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
addCommandHandler("reload",
	function(player, cmd)
		reloadPedWeapon(player)
	end
)

addEventHandler("onResourceStart", cThisRoot,
	function()
		for k,v in ipairs(getElementsByType("player")) do
			bindKey(v, "R", "down", "reload")
		end
	end
)

addEventHandler("onPlayerJoin", cRoot,
	function()
		bindKey(source, "R", "down", "reload")
	end
)