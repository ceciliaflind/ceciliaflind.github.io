--[[
	Basic Roleplay Gamemode
	~ Client-side functions for login
	
	Created by Socialz
]]--

-- Miniatures
local playerName = getPlayerName(localPlayer)
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

function createPasswordWindow()
	-- Changing password window
	brpPasswordWindow = guiCreateWindow(0.3859, 0.349, 0.15, 0.12, "Change Password", true)
	guiSetAlpha(brpPasswordWindow, 0.8)
	guiSetVisible(brpPasswordWindow, false)
	
	brpPasswordButton = guiCreateButton(10, 91, 265, 23, "Change Password", false, brpPasswordWindow)
	guiSetAlpha(brpPasswordButton, 1)
	
	-- Old password
	brpOldPasswordLabel = guiCreateLabel(10, 29, 90, 21, "Old Password:", false, brpPasswordWindow)
	guiSetAlpha(brpOldPasswordLabel, 1)
	guiLabelSetColor(brpOldPasswordLabel, 255, 255, 255)
	guiLabelSetVerticalAlign(brpOldPasswordLabel, "center")
	guiLabelSetHorizontalAlign(brpOldPasswordLabel, "left", false)
	
	brpOldPasswordEdit = guiCreateEdit(110, 29, 165, 21, "", false, brpPasswordWindow)
	guiSetAlpha(brpOldPasswordEdit, 1)
	guiEditSetMasked(brpOldPasswordEdit, true)
	
	-- New password
	brpNewPasswordLabel = guiCreateLabel(10, 60, 90, 21, "New Password:", false, brpPasswordWindow)
	guiSetAlpha(brpNewPasswordLabel, 1)
	guiLabelSetColor(brpNewPasswordLabel, 255, 255, 255)
	guiLabelSetVerticalAlign(brpNewPasswordLabel, "center")
	guiLabelSetHorizontalAlign(brpNewPasswordLabel, "left", false)
	
	brpNewPasswordEdit = guiCreateEdit(110, 60, 165, 21, "", false, brpPasswordWindow)
	guiSetAlpha(brpNewPasswordEdit, 1)
	guiEditSetMasked(brpNewPasswordEdit, true)
	guiEditSetMaxLength(brpNewPasswordEdit, 50)
	
	addEventHandler("onClientGUIClick", brpPasswordButton, brpChangePasswordClient, false)
end

function createLoginWindow()
	-- Logging in window
	brpLoginWindow = guiCreateWindow(0.3945, 0.3646, 0.2109, 0.2018, "Login", true)
	guiSetSize(brpLoginWindow, 270, 155, false)
	guiSetAlpha(brpLoginWindow, 1)
	guiSetVisible(brpLoginWindow, false)
	
	brpLoginButton = guiCreateButton(10, 121, 120, 21, "Log in", false, brpLoginWindow)
	guiSetAlpha(brpLoginButton, 1)
	
	brpRegisterButton = guiCreateButton(143, 121, 117, 21, "Register", false, brpLoginWindow)
	guiSetAlpha(brpRegisterButton, 1)
	
	-- Global
	brpLoginLabel = guiCreateLabel(10, 26, 250, 17, "Please login or register.", false, brpLoginWindow)
	guiSetAlpha(brpLoginLabel, 1)
	guiLabelSetColor(brpLoginLabel, 255, 255, 255)
	guiLabelSetVerticalAlign(brpLoginLabel, "top")
	guiLabelSetHorizontalAlign(brpLoginLabel, "center", false)
	guiSetFont(brpLoginLabel, "default-bold-small")
	
	-- Username
	brpUsernameLabel = guiCreateLabel(10, 52, 59, 24, "Username:", false, brpLoginWindow)
	guiSetAlpha(brpUsernameLabel, 1)
	guiLabelSetColor(brpUsernameLabel, 255, 255, 255)
	guiLabelSetVerticalAlign(brpUsernameLabel, "center")
	guiLabelSetHorizontalAlign(brpUsernameLabel, "left", false)
	
	brpUsernameEdit = guiCreateEdit(79, 52, 181, 25, playerName, false, brpLoginWindow)
	guiSetAlpha(brpUsernameEdit, 1)
	guiEditSetMaxLength(brpUsernameEdit, 50)
	
	-- Password
	brpPasswordLabel = guiCreateLabel(10, 86, 59, 24, "Password:", false, brpLoginWindow)
	guiSetAlpha(brpPasswordLabel, 1)
	guiLabelSetColor(brpPasswordLabel, 255, 255, 255)
	guiLabelSetVerticalAlign(brpPasswordLabel, "center")
	guiLabelSetHorizontalAlign(brpPasswordLabel, "left", false)
	
	brpPasswordEdit = guiCreateEdit(79, 86, 181, 25, "", false, brpLoginWindow)
	guiSetAlpha(brpPasswordEdit, 1)
	guiEditSetMasked(brpPasswordEdit, true)
	guiEditSetMaxLength(brpPasswordEdit, 50)
	
	addEventHandler("onClientGUIClick", brpLoginButton, brpLoginClient, false)
	addEventHandler("onClientGUIClick", brpRegisterButton, brpRegisterClient, false)
end

function brpResourceStart()
	createLoginWindow()
	if (brpLoginWindow ~= nil) then
		guiSetVisible(brpLoginWindow, true)
	else
		outputChatBox("An error has occurred.")
	end
	showCursor(true)
	guiSetInputEnabled(true)
end
addEventHandler("onClientResourceStart", cThisRoot, brpResourceStart)

addEvent("onForceLogout", true)
addEventHandler("onForceLogout", root,
	function(source)
		brpResourceStart()
	end
)

-- ~ [CHANGEPASS, CHANGEPASSWORD, CHANGEPWD] ~ --
addCommandHandler({"changepass", "changepassword", "changepwd"},
	function()
		if getElementData(localPlayer, "player.loggedin") == 1 then
			createPasswordWindow()
			guiSetVisible(brpPasswordWindow, true)
			showCursor(true)
			guiSetInputEnabled(true)
		else
			outputChatBox("Login first.", 255, 0, 0, false)
		end
	end
)

function brpLoginClient(button, state)
	if button == "left" and state == "up" then
		local username = guiGetText(brpUsernameEdit)
		local password = guiGetText(brpPasswordEdit)
		if username and password then
			triggerServerEvent("submitLogin", root, localPlayer, username, password)
		else
			guiSetText(brpLoginLabel, "Enter username and password.")
		end
	end
end

function brpRegisterClient(button, state)
	if button == "left" and state == "up" then
		local username = guiGetText(brpUsernameEdit)
		local password = guiGetText(brpPasswordEdit)
		if username and password then
			triggerServerEvent("submitRegister", root, localPlayer, username, password)
		else
			guiSetText(brpLoginLabel, "Enter username and password.")
		end
	end
end

function brpChangePasswordClient(button, state)
	if button == "left" and state == "up" then
		local oldpassword = guiGetText(brpOldPasswordEdit)
		local newpassword = guiGetText(brpNewPasswordEdit)
		if oldpassword and newpassword then
			triggerServerEvent("submitPassword", root, localPlayer, oldpassword, newpassword)
		else
			outputChatBox("Enter old and new password.")
		end
	end
end

function hideLoginWindow()
	guiSetInputEnabled(false)
	guiSetVisible(brpLoginWindow, false)
	showCursor(false)
end
addEvent("hideLoginWindow", true)
addEventHandler("hideLoginWindow", cRoot, hideLoginWindow)

function hidePasswordWindow()
	guiSetInputEnabled(false)
	guiSetVisible(brpPasswordWindow, false)
	showCursor(false)
end
addEvent("hidePasswordWindow", true)
addEventHandler("hidePasswordWindow", cRoot, hidePasswordWindow)

function unknownError()
	guiSetText(brpLoginLabel, "An unknown error occured.")
end
addEvent("unknownError", true)
addEventHandler("unknownError", cRoot, unknownError)

function loginWrong()
	guiSetText(brpLoginLabel, "Wrong username and/or password.")
end
addEvent("loginWrong", true)
addEventHandler("loginWrong", cRoot, loginWrong)

function registerTaken()
	guiSetText(brpLoginLabel, "This username already exists.")
end
addEvent("registerTaken", true)
addEventHandler("registerTaken", cRoot, registerTaken)