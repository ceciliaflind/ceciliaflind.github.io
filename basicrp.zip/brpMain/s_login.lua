--[[
	Basic Roleplay Gamemode
	~ Server-side functions for login
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Configurations (modifyable)
local cx1, cy1, cz1 = 1262, -1154, 96 -- Camera slider part 1 position
local cpx1, cpy1, cpz1 = 1190, -1195, 58 -- Camera slider part 1 point

local cx2, cy2, cz2 = 512.2, -1263.57, 32.53 -- Camera slider part 2 position
local cpx2, cpy2, cpz2 = 542.16, -1287.07, 17.24 -- Camera slider part 2 point

local cx3, cy3, cz3 = 1818.96, -1678.42, 17.77 -- Camera slider part 3 position
local cpx3, cpy3, cpz3 = 1831.63, -1679.9, 13.54 -- Camera slider part 3 point

local cx4, cy4, cz4 = 1517.72, -1724.66, 38.05 -- Camera slider part 4 position
local cpx4, cpy4, cpz4 = 1471.68, -1750.05, 15.44 -- Camera slider part 4 point

local cx5, cy5, cz5 = 951.71, -1122.66, 44.24 -- Camera slider part 5 position
local cpx5, cpy5, cpz5 = 890.43, -1092.08, 24.3 -- Camera slider part 5 point

local cx6, cy6, cz6 = 1051.84, -1157.98, 35.98 -- Camera slider part 6 position
local cpx6, cpy6, cpz6 = 1028.54, -1121.54, 28.4 -- Camera slider part 6 point

local cx7, cy7, cz7 = 1924.13, -1767.91, 88.08 -- Camera slider part 7 position
local cpx7, cpy7, cpz7 = 1765.62, -1864.89, 13.57 -- Camera slider part 7 point

local sx, sy, sz = 1743, -1861, 14 -- Original spawnpoint
local rx, ry, rz = 1183, -1323, 14 -- Respawnpoint
local rp_startcash = 500 -- Starting wallet cash
local rp_startbankcash = 1000 -- Starting bank cash
local regR, regG, regB = 255, 255, 255 -- Regular nametag color
local admR, admG, admB = 255, 255, 0 -- Admin nametag color

local notification_welcome = "Welcome to Basic Roleplay server." -- Notification: welcometext
local notification_regular = "Successfully logged in." -- Notification: ACL group note on log in, regular account
local notification_trialadmin = "You've logged in as a trial administrator." -- Notification: ACL group note on log in, trial administrator
local notification_gameadmin = "You've logged in as a game administrator." -- Notification: ACL group note on log in, game administrator
local notification_leadadmin = "You've logged in as a lead administrator." -- Notification: ACL group note on log in, lead administrator
local notification_owner = "You've logged in as a server owner." -- Notification: ACL group note on log in, server owner
local notification_password = "If you want to change your password, use /changepass" -- Notification: how to change password
local notification_loggedout = "You've been logged out - please log in again." -- Notification: forced logged out

local warning_password_notloggedin = "You must be logged in to change your password." -- Warning: not logged in when changing password
local warning_password_invalidlenght = "Your new password must be at least 5 characters long!" -- Warning: invalid lenght when changing password
local warning_password_invalid = "Old password invalid." -- Warning: invalid password
local warning_logout = "You are not able to log out." -- Warning: logging out disabled

local rp_hospitalMoney = 75 -- Hospital treatment's payment
local rp_notification_hospital_01 = "Los Santos Emergency Medical Services treated you in the hospital." -- Treatment info after respawn
local rp_notification_hospital_02 = "You have paid $" .. rp_hospitalMoney .. " for the treatment." -- Treatment info after respawn

local releasepoint_x = 0
local releasepoint_y = 0
local releasepoint_z = 0
local releasepoint_interior = 0
local releasepoint_dimension = 0

-- Functions
addEventHandler("onPlayerJoin", cRoot,
	function()
		for i=1,50 do
			outputChatBox(" ", source)
		end
		
		outputChatBox(notification_welcome, source, 255, 255, 0, true)
		outputChatBox("To continue, please login.", source, 255, 255, 255, true)
		outputChatBox(" ", source, 255, 255, 255, true)
		showPlayerHudComponent(source, "radar", false)
		showPlayerHudComponent(source, "area_name", false)
		setElementData(source, "basicrp.slider", 0)
		firstSlider(source)
	end
)

function firstSlider(source)
	if getElementData(source, "basicrp.slider") ~= 1 then
		fadeCamera(source, false, 1.0)
		setTimer(function()
			setCameraMatrix(source, cx1, cy1, cz1, cpx1, cpy1, cpz1)
			fadeCamera(source, true, 1.0)
		end, 1000, 1)
		setTimer(secondSlider, 4000, 1, source)
	end
end

function secondSlider(source)
	if getElementData(source, "basicrp.slider") ~= 1 then
		fadeCamera(source, false, 1.0)
		setTimer(function()
			setCameraMatrix(source, cx2, cy2, cz2, cpx2, cpy2, cpz2)
			fadeCamera(source, true, 1.0)
		end, 1000, 1)
		setTimer(thirdSlider, 4000, 1, source)
	end
end

function thirdSlider(source)
	if getElementData(source, "basicrp.slider") ~= 1 then
		fadeCamera(source, false, 1.0)
		setTimer(function()
			setCameraMatrix(source, cx3, cy3, cz3, cpx3, cpy3, cpz3)
			fadeCamera(source, true, 1.0)
		end, 1000, 1)
		setTimer(fourthSlider, 4000, 1, source)
	end
end

function fourthSlider(source)
	if getElementData(source, "basicrp.slider") ~= 1 then
		fadeCamera(source, false, 1.0)
		setTimer(function()
			setCameraMatrix(source, cx4, cy4, cz4, cpx4, cpy4, cpz4)
			fadeCamera(source, true, 1.0)
		end, 1000, 1)
		setTimer(fifthSlider, 4000, 1, source)
	end
end

function fifthSlider(source)
	if getElementData(source, "basicrp.slider") ~= 1 then
		fadeCamera(source, false, 1.0)
		setTimer(function()
			setCameraMatrix(source, cx5, cy5, cz5, cpx5, cpy5, cpz5)
			fadeCamera(source, true, 1.0)
		end, 1000, 1)
		setTimer(sixthSlider, 4000, 1, source)
	end
end

function sixthSlider(source)
	if getElementData(source, "basicrp.slider") ~= 1 then
		fadeCamera(source, false, 1.0)
		setTimer(function()
			setCameraMatrix(source, cx6, cy6, cz6, cpx6, cpy6, cpz6)
			fadeCamera(source, true, 1.0)
		end, 1000, 1)
		setTimer(seventhSlider, 4000, 1, source)
	end
end

function seventhSlider(source)
	if getElementData(source, "basicrp.slider") ~= 1 then
		fadeCamera(source, false, 1.0)
		setTimer(function()
			setCameraMatrix(source, cx7, cy7, cz7, cpx7, cpy7, cpz7)
			fadeCamera(source, true, 1.0)
		end, 1000, 1)
		setTimer(firstSlider, 4000, 1, source)
	end
end

function brpLogin(player, username, password)
	local account = getAccount(username, password)
	if account ~= false then
		if logIn(player, account, password) == true then
			local acc = getPlayerAccount(player)
			
			if isObjectInACLGroup("user." .. getAccountName(acc), aclGetGroup("Trial Administrator")) then
				outputChatBox(notification_trialadmin, player, 200, 200, 0, false)
				setElementData(player, "admin.level", 1)
				setPlayerNametagColor(player, admR, admG, admB)
			elseif isObjectInACLGroup("user." .. getAccountName(acc), aclGetGroup("Game Administrator")) then
				outputChatBox(notification_gameadmin, player, 200, 200, 0, false)
				setElementData(player, "admin.level", 2)
				setPlayerNametagColor(player, admR, admG, admB)
			elseif isObjectInACLGroup("user." .. getAccountName(acc), aclGetGroup("Lead Administrator")) then
				outputChatBox(notification_leadadmin, player, 200, 200, 0, false)
				setElementData(player, "admin.level", 3)
				setPlayerNametagColor(player, admR, admG, admB)
			elseif isObjectInACLGroup("user." .. getAccountName(acc), aclGetGroup("Server Owner")) then
				outputChatBox(notification_owner, player, 200, 200, 0, false)
				setElementData(player, "admin.level", 4)
				setPlayerNametagColor(player, admR, admG, admB)
			else
				outputChatBox(notification_regular, player, 220, 220, 0, false)
				setElementData(player, "admin.level", 0)
				setPlayerNametagColor(player, regR, regG, regB)
			end
			
			setElementData(player, "accountname", getAccountName(acc))
			setElementData(player, "player.loggedin", 1)
			outputChatBox(notification_password, player, 255, 255, 255, false)
			triggerClientEvent(player, "hideLoginWindow", cRoot)
			setElementData(player, "basicrp.slider", 1)
			fadeCamera(player, false, 2.0)
			
			if isElementFrozen(player) then
				setElementFrozen(player, false)
			end
		
			setTimer(function()
				local money = getAccountData(acc, "basicrp.money")
				local bank = getAccountData(acc, "basicrp.bank")
				local faction = getAccountData(acc, "basicrp.faction")
				local fname = getAccountData(acc, "basicrp.fname")
				local factionleader = getAccountData(acc, "basicrp.factionleader")
				local health = getAccountData(acc, "basicrp.health")
				local armor = getAccountData(acc, "basicrp.armor")
				local model = getAccountData(acc, "basicrp.model")
				local points = getAccountData(acc, "basicrp.points")
				local interior = getAccountData(acc, "basicrp.interior")
				local dimension = getAccountData(acc, "basicrp.dimension")
				local x = getAccountData(acc, "basicrp.posx")
				local y = getAccountData(acc, "basicrp.posy")
				local z = getAccountData(acc, "basicrp.posz")
				local rx = getAccountData(acc, "basicrp.rotx")
				local ry = getAccountData(acc, "basicrp.roty")
				local rz = getAccountData(acc, "basicrp.rotz")
				local cuffed = getAccountData(acc, "basicrp.cuffed")
				local arrested = getAccountData(acc, "basicrp.arrested")
				local arrestedtime = getAccountData(acc, "basicrp.arrested-remainingtime")
				
				if cuffed == true then
					setElementData(player, "police.cuffed", true)
					toggleControl(player, "fire", false)
					toggleControl(player, "next_weapon", false)
					toggleControl(player, "previous_weapon", false)
					toggleControl(player, "sprint", false)
					toggleControl(player, "aim_weapon", false)
					toggleControl(player, "handbrake", false)
					toggleControl(player, "vehicle_fire", false)
					toggleControl(player, "vehicle_secondary_fire", false)
					toggleControl(player, "vehicle_left", false)
					toggleControl(player, "vehicle_right", false)
					toggleControl(player, "steer_forward", false)
					toggleControl(player, "steer_back", false)
				end
				
				if arrested == true then
					setElementData(player, "police.arrested", true)
					outputChatBox("You still have some time to spent in jail.", player, 120, 120, 255, false)
					setTimer(function(player)
						if getElementData(player, "police.arrested") then
							setElementPosition(player, releasepoint_x, releasepoint_y, releasepoint_z)
							setElementInterior(player, releasepoint_interior)
							setElementDimension(player, releasepoint_dimension)
							outputChatBox("Your time has been served - behave from now on.", player, 120, 120, 255, false)
							outputServerLog("[FACTIONS] [AUTO/RELEASE]: " .. getPlayerName(player) .. " was released from jail automatically.")
							removeElementData(player, "police.arrested")
							setAccountData(acc, "basicrp.arrested", false)
							setAccountData(acc, "basicrp.arrested-remainingtime", 0)
						end
					end, arrestedtime, 1, player)
				end
				
				if bank then
					setElementData(player, "account.bank", tonumber(bank))
				else
					setElementData(player, "account.bank", tonumber(rp_startbankcash))
				end
				
				if health <= 10 then
					setElementHealth(player, 100)
				else
					setElementHealth(player, tonumber(health))
				end
				
				if faction and fname then
					setElementData(player, "factions.player", tonumber(faction))
					setElementData(player, "factions.fplayer", tostring(fname))
				else
					setElementData(player, "factions.player", 0)
					setElementData(player, "factions.fplayer", "false")
				end
				
				if factionleader then
					setElementData(player, "factions.leader", "Yes")
				else
					setElementData(player, "factions.leader", "No")
				end
				
				spawnPlayer(player, tonumber(x), tonumber(y), tonumber(z))
				setElementInterior(player, tonumber(interior))
				setElementDimension(player, tonumber(dimension))
				setElementRotation(player, tonumber(rx), tonumber(ry), tonumber(rz))
				setCameraTarget(player, player)
				showChat(player, true)
				setPedHeadless(player, false)
				setPlayerMoney(player, money)
				setElementModel(player, model)
				setPedArmor(player, armor)
				setElementFrozen(player, false)
				showPlayerHudComponent(player, "ammo", false)
				showPlayerHudComponent(player, "armour", false)
				showPlayerHudComponent(player, "health", false)
				showPlayerHudComponent(player, "breath", false)
				showPlayerHudComponent(player, "radar", true)
				showPlayerHudComponent(player, "weapon", false)
				showPlayerHudComponent(player, "money", false)
				fadeCamera(player, true, 2.0)
			end, 2000, 1, player, acc)
		else
			triggerClientEvent(player, "unknownError", cRoot)
		end
	else
		triggerClientEvent(player, "loginWrong", cRoot)
	end
end
addEvent("submitLogin", true)
addEventHandler("submitLogin", cRoot, brpLogin)

function brpRegister(player, username, password)
	local account = getAccount(username, password)
	if account ~= false then
		triggerClientEvent(player, "registerTaken", cRoot)
	else
		account = addAccount(username, password)
		if logIn(player, account, password) == true then
			outputChatBox(notification_regular, player, 220, 220, 0, false)
			outputChatBox(notification_password, player, 255, 255, 255, false)
			triggerClientEvent(player, "hideLoginWindow", cRoot)
			setElementData(player, "basicrp.slider", 1)
			fadeCamera(player, false, 2.0)
			setTimer(function()
				spawnPlayer(player, tonumber(sx), tonumber(sy), tonumber(sz))
				setElementRotation(player, 0, 0, 0)
				setCameraTarget(player, player)
				showChat(player, true)
				setPedHeadless(player, false)
				setPlayerMoney(player, rp_startcash)
				setElementHealth(player, 100)
				setElementModel(player, math.random(9, 270))
				setPedArmor(player, 0)
				setElementFrozen(player, false)
				setElementData(player, "player.loggedin", 1)
				setElementData(player, "admin.level", 0)
				setElementData(player, "factions.player", 0)
				setElementData(player, "factions.fplayer", "false")
				setElementData(player, "factions.leader", "No")
				setElementData(player, "account.bank", tonumber(rp_startbankcash))
				setPlayerNametagColor(player, regR, regG, regB)
				showPlayerHudComponent(player, "ammo", false)
				showPlayerHudComponent(player, "area_name", false)
				showPlayerHudComponent(player, "armour", false)
				showPlayerHudComponent(player, "health", false)
				showPlayerHudComponent(player, "breath", false)
				showPlayerHudComponent(player, "weapon", false)
				showPlayerHudComponent(player, "money", false)
				fadeCamera(player, true, 2.0)
			end, 2000, 1, player)
		else
			triggerClientEvent(player, "unknownError", cRoot)
		end
	end
end
addEvent("submitRegister", true)
addEventHandler("submitRegister", cRoot, brpRegister)

function brpPassword(player, oldpassword, newpassword)
	local account = getPlayerAccount(player)
	if (account) then
		if (isGuestAccount(account)) then
			outputChatBox(warning_password_notloggedin, player, 255, 255, 255, false)
			return
		end
		local playerName = getPlayerName(player)
		local password_check = getAccount(playerName, oldpassword)
		if (password_check ~= false) then
			if (string.len(newpassword) >= 5) then
				setAccountPassword(account, newpassword)
				triggerClientEvent(player, "hidePasswordWindow", cRoot)
				outputChatBox("Password changed successfully.", player, 0, 255, 0, false)
			else
				outputChatBox(warning_password_invalidlenght, player, 255, 255, 255, false)
			end
		else
			outputChatBox(warning_password_invalid, player)
		end
	end
end
addEvent("submitPassword", true)
addEventHandler("submitPassword", cRoot, brpPassword)

addEventHandler("onPlayerWasted", cRoot,
	function(ammo, killer, weapon, bodypart, stealth)
		for i,v in ipairs(getElementsByType("player")) do
			if exports.brpExports:isPlayerAdmin(v) then
				if killer then
					if weapon then
						outputChatBox("KILL: " .. getPlayerName(killer) .. " killed " .. getPlayerName(source) .. " with a " .. getWeaponNameFromID(weapon) .. ".", v, 255, 0, 0, false)
					else
						outputChatBox("KILL: " .. getPlayerName(killer) .. " killed " .. getPlayerName(source) .. ".", v, 255, 0, 0, false)
					end
				else
					outputChatBox("KILL: " .. getPlayerName(source) .. " died.", v, 255, 0, 0, false)
				end
			end
		end
		fadeCamera(source, false, 5.0)
		setTimer(function(source)
			fadeCamera(source, true, 5.0)
			spawnPlayer(source, rx, ry, rz)
			outputChatBox(rp_notification_hospital_01, source, 220, 220, 0, false)
			outputChatBox(rp_notification_hospital_02, source, 220, 220, 0, false)
			takePlayerMoney(source, rp_hospitalMoney)
			setPedRotation(source, -90)
			setPlayerNametagText(source, getPlayerName(source))
			setElementModel(source, getAccountData(getPlayerAccount(source), "basicrp.model"))
		end, 5000, 1, source)
	end
)

addEventHandler("onPlayerChangeNick", cRoot,
	function(old, new)
		local vehicle = getPedOccupiedVehicle(source)
		outputServerLog("changenick: " .. tostring(old) .. " changed his name to " .. tostring(new) .. ".")
		if vehicle then
			if not getElementData(vehicle, "vehicle.tint") == 1 then
				setPlayerNametagText(source, tostring(new))
			end
		end
	end
)

addEventHandler("onPlayerQuit", cRoot,
	function()
		saveAccount(source)
	end
)

addEventHandler("onResourceStop", cThisRoot,
	function()
		for i,v in ipairs(getElementsByType("player")) do
			saveAccount(v)
			logOut(v)
		end
	end
)

addEventHandler("onPlayerLogout", root,
	function()
		setElementHealth(source, 100)
		setElementCollisionsEnabled(source, false)
		setElementFrozen(source, true)
		setElementData(source, "basicrp.slider", 0)
		setElementPosition(source, 0, 0, 0)
		setElementInterior(source, 0)
		setElementDimension(source, 0)
		outputChatBox(notification_loggedout, source, 255, 0, 0, false)
		firstSlider(source)
		showPlayerHudComponent(source, "radar", false)
		showPlayerHudComponent(source, "area_name", false)
		triggerClientEvent("onForceLogout", source, source)
		setElementData(source, "admin.level", 0)
		setElementData(source, "player.loggedin", 0)
		saveAccount(source)
	end
)

function saveAccount(player)
	local account = getPlayerAccount(player)
	if isGuestAccount(account) then return end
	local money = getPlayerMoney(player)
	local bank = getElementData(player, "account.bank")
	local faction = getElementData(player, "factions.player")
	local fname = getElementData(player, "factions.fplayer")
	local factionleader = getElementData(player, "factions.leader")
	local health = getElementHealth(player)
	local armor = getPedArmor(player)
	local x, y, z = getElementPosition(player)
	local interior = getElementInterior(player)
	local dimension = getElementDimension(player)
	local model = getElementModel(player)
	local rx, ry, rz = getElementRotation(player)
	setAccountData(account, "basicrp.money", tonumber(money))
	setAccountData(account, "basicrp.bank", tonumber(bank))
	setAccountData(account, "basicrp.factionleader", tonumber(factionleader))
	setAccountData(account, "basicrp.faction", tonumber(faction))
	setAccountData(account, "basicrp.fname", tostring(fname))
	setAccountData(account, "basicrp.health", tonumber(health))
	setAccountData(account, "basicrp.armor", tonumber(armor))
	setAccountData(account, "basicrp.model", tonumber(model))
	setAccountData(account, "basicrp.interior", tonumber(interior))
	setAccountData(account, "basicrp.dimension", tonumber(dimension))
	setAccountData(account, "basicrp.posx", tonumber(x))
	setAccountData(account, "basicrp.posy", tonumber(y))
	setAccountData(account, "basicrp.posz", tonumber(z))
	setAccountData(account, "basicrp.rotx", tonumber(rx))
	setAccountData(account, "basicrp.roty", tonumber(ry))
	setAccountData(account, "basicrp.rotz", tonumber(rz))
end