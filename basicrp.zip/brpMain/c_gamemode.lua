--[[
	Basic Roleplay Gamemode
	~ Client-side functions for gamemode
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
addEventHandler("onClientResourceStart", cThisRoot,
	function()
		setBirdsEnabled(false)
		setAmbientSoundEnabled("gunfire", false)
	end
)