--[[
	Basic Roleplay Gamemode
	~ Server-side functions for commands
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

addEventHandler("onPlayerCommand", root,
	function(cmd)
		if isGuestAccount(getPlayerAccount(source)) then
			outputChatBox("Log in first to use this command.", source, 255, 0, 0, false)
			cancelEvent()
		end
	end
)

-- ~ [TOGCURSOR] ~ --
addCommandHandler("togcursor",
	function(player, cmd)
		local isShowing = isCursorShowing(player)
		local toggleCursor = not isShowing
		showCursor(player, toggleCursor)
		outputServerLog("[COMMON] [CMD/togcursor]: " .. getPlayerName(player) .. " toggled their cursor.")
	end
)

addEventHandler("onResourceStart", resourceRoot,
	function()
		for i,v in ipairs(getElementsByType("player")) do
			bindKey(v, "M", "down", "togcursor")
		end
	end
)

addEventHandler("onPlayerJoin", resourceRoot,
	function()
		bindKey(source, "M", "down", "togcursor")
	end
)

-- ~ [ADMINS, SHOWADMINS, STAFF, MODS, MODERATORS] ~ --
addCommandHandler({"admins", "showadmins", "staff", "mods", "moderators"},
	function(player, cmd)
		admins = 0
		outputChatBox("ADMINS:", player)
		
		for i,v in ipairs(getElementsByType("player")) do
			if isGuestAccount(getPlayerAccount(v)) then return end
			if isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(v)), aclGetGroup("Server Owner")) then
				if getElementData(player, "admin.hidden") == 0 or not getElementData(player, "admin.hidden") then
					if getElementData(player, "admin.duty") == 1 then
						outputChatBox(" Server Owner " .. getPlayerName(v) .. " - On Duty", player, 220, 220, 0, false)
						admins = 1
					else
						outputChatBox(" Server Owner " .. getPlayerName(v), player, 220, 220, 0, false)
						admins = 1
					end
				else
					return
				end
			end
				
			if isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(v)), aclGetGroup("Lead Administrator")) then
				if getElementData(player, "admin.hidden") == 0 or not getElementData(player, "admin.hidden") then
					if getElementData(player, "admin.duty") == 1 then
						outputChatBox(" Lead Administrator " .. getPlayerName(v) .. " - On Duty", player, 220, 220, 0, false)
						admins = 1
					else
						outputChatBox(" Lead Administrator " .. getPlayerName(v), player, 220, 220, 0, false)
						admins = 1
					end
				else
					return
				end
			end
				
			if isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(v)), aclGetGroup("Game Administrator")) then
				if getElementData(player, "admin.hidden") == 0 or not getElementData(player, "admin.hidden") then
					if getElementData(player, "admin.duty") == 1 then
						outputChatBox(" Game Administrator " .. getPlayerName(v) .. " - On Duty", player, 220, 220, 0, false)
						admins = 1
					else
						outputChatBox(" Game Administrator " .. getPlayerName(v), player, 220, 220, 0, false)
						admins = 1
					end
				else
					return
				end
			end
				
			if isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(v)), aclGetGroup("Trial Administrator")) then
				if getElementData(player, "admin.hidden") == 0 or not getElementData(player, "admin.hidden") then
					if getElementData(player, "admin.duty") == 1 then
						outputChatBox(" Trial Administrator " .. getPlayerName(v) .. " - On Duty", player, 220, 220, 0, false)
						admins = 1
					elseif getElementData(player, "admin.duty") == 0 then
						outputChatBox(" Trial Administrator " .. getPlayerName(v), player, 220, 220, 0, false)
						admins = 1
					end
				else
					return
				end
			end
		end
			
		if admins == 0 then
			outputChatBox(" No administrators online.", player, 220, 220, 0, false)
		end
		
		outputServerLog("[COMMON] [CMD/ADMINS]: " .. getPlayerName(player) .. " checked for online administrators.")
	end
)