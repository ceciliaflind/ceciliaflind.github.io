--[[
	Basic Roleplay Gamemode
	~ Server-side functions for gamemode
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
addEventHandler("onResourceStart", cThisRoot,
	function()
		local realtime = getRealTime()
		setTime(realtime.hour, realtime.minute)
		setMinuteDuration(60000)
		setGameType("Basic Roleplay")
		setMapName("Basic Roleplay: Los Santos")
		setWeather(10)
		setWaterColor(0, 0, 0)
		setWaveHeight(1)
	end
)