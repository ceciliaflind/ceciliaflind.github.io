--[[
	Basic Roleplay Gamemode
	~ Client-side functions for pedestrians
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
addEventHandler("onClientPedDamage", cRoot,
	function(attacker, weapon, bodypart, loss)
		cancelEvent()
	end
)