--[[
	Basic Roleplay Gamemode
	~ Client-side functions for GUIs
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Configurations (modifyable)
-- Use \n for a new line

local help_title = "Server Information (updated 18/02/2012)" -- Title of the window

local rules_title = "Rules" -- Title of the tab
local rules_memo = "1. Do not deathmatch. Instead of scriptwise hitting, you can use the commands (/me and /do).\n\n2. Do not powergame. Instead of running away after you've typed your sentence, you could wait for the other part's reaction.\n\n3. Do not metagame. Instead of looking the other part's name from the chatbox or over their head, you could ask their name in-charactively.\n\n4. Do not bunnyhop. Instead of jumping around and trying to get faster to a location, you could call a taxi with your cellphone.\n\n5. Do not mess around. Instead of hitting fellow players and running around, you could join a roleplay or possibly join a faction.\n\n6. Do not make unrealistic decisions. Instead of doing unrealistic actions, you could use common sense and do what you would do in real life.\n\n7. Do not insult or show racistic decisions to other players. Instead of calling others 'niggars' in out-of-character chat, you could simply leave the 'niggar' word off and continue your discussion without such words.\n\n8. Do not override admin's decision. Instead of saying the admin a cheater or noob, you could do just what the admin told you. Admin's decision is final.\n\n9. Do not provoke via emergency phone. Instead of calling the emergency number and saying 'you suck badass cops', you could use the number for real emergency situations that might appear during gameplay.\n\n10. Do not force-rape. Instead of forcing someone for a rape, you could ask the player in out-of-character chat if they accept the rape. Child molestion and pedophilia is completely disallowed.\n\n11. Do not cheat. Instead of using cheats in our server, you could turn them off to avoid admin actions. We want everybody to play fairly.\n\n12. Do not advertise other servers. We do not want players to leave our server, we want new players to join our server.\n\n13. Do not tell admins what actions they should do. Instead of telling admins what actions they should do, you could wait for them to do their job and let them see the situation.\n\n14. Do not go away from keyboard while at a public/featured location. You can go away from keyboard in your own apartments, houses or jail. However, going away from keyboard for a long time is not allowed. Maximum of 30 minutes is allowed. Moneyfarming is completely disallowed.\n\n15. Do not mix out-of-character chat with in-character chat.\n\n16. Do not revenge kill. If you get player killed, you're not allowed to go and kill the killer."

local roleplay_title = "Roleplay" -- Title of the tab
local roleplay_memo = "Metagaming\nWhat is metagaming? Should I metagame? When is it allowed? Metagaming is using out-of-character information in-charactively. For example knowing names out-of-charactively and using them in-charactively. It is not allowed at all, so do not use it.\n\nPowergaming\nWhat is powergaming? Should I powergame? When is it allowed? Powergaming is giving no reaction time to the other part. For example killing a player without giving the player no reaction time for your kicks and punches. It is not allowed either, so do not use it.\n\nPassive RP\nWhat is passive RP? Should I passive RP? When is it allowed? Passive RP is a good way of learning new words and seeing the roleplay world more interesting. Passive RP is when you roleplay things that aren't appearing in-game, such as water flowing down from a faucet or when a train is approaching. Suggested but not a must."

local information_title = "Information" -- Title of the tab
local information_memo = "Server Staff\n Server owner - Socialz\n Lead Administrator - Socialz\n Game Administrator - Socialz\n Trial Administrator - Socialz\n\nServer script developed by Socialz - Copyright 2012."

-- Functions
addEventHandler("onClientResourceStart", cThisRoot,
	function()
		local screenx, screeny = guiGetScreenSize()
		
		helpWindow = guiCreateWindow((screenx - 605) / 2, (screeny - 372) / 2, 692, 355, help_title, false)
		guiWindowSetMovable(helpWindow, true)
		guiWindowSetSizable(helpWindow, false)
		guiSetVisible(helpWindow, false)
		
		helpTabs = guiCreateTabPanel(10, 26, 673, 320, false, helpWindow)
		
		-- Rules
		tab_rules = guiCreateTab(rules_title, helpTabs)
		tab_rules_memo = guiCreateMemo(12, 11, 649, 275, rules_memo, false, tab_rules)
		guiMemoSetReadOnly(tab_rules_memo, true)
		
		-- Roleplay
		tab_roleplay = guiCreateTab(roleplay_title, helpTabs)
		tab_roleplay_memo = guiCreateMemo(12, 11, 649, 275, roleplay_memo, false, tab_roleplay)
		guiMemoSetReadOnly(tab_roleplay_memo, true)
		
		-- Information
		tab_information = guiCreateTab(information_title, helpTabs)
		tab_information_memo = guiCreateMemo(12, 11, 649, 275, information_memo, false, tab_information)
		guiMemoSetReadOnly(tab_information_memo, true)
	end
)

function showGUI()
	if guiGetVisible(helpWindow) == true then
		guiSetVisible(helpWindow, false)
		showCursor(false)
		guiSetInputEnabled(false)
	else
		guiSetVisible(helpWindow, true)
		showCursor(true)
		guiSetInputEnabled(true)
	end
end
addCommandHandler("help", showGUI)

function bindShowGUI()
	bindKey("F1", "down", showGUI)
end
addEventHandler("onClientResourceStart", cThisRoot, bindShowGUI)
addEventHandler("onPlayerJoin", cThisRoot, bindShowGUI)