--[[
	Basic Roleplay Gamemode
	~ Client-side functions for water shader
	
	Created by MTA Developers, final version by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
addEventHandler("onClientResourceStart", cThisRoot,
	function()
		local shader, tec = dxCreateShader("water.fx")
		local textureVol = dxCreateTexture("images/smallnoise3d.dds")
		local textureCube = dxCreateTexture("images/cube_env256.dds")
		dxSetShaderValue(shader, "microflakeNMapVol_Tex", textureVol)
		dxSetShaderValue(shader, "showroomMapCube_Tex", textureCube)
		engineApplyShaderToWorldTexture(shader, "waterclear256")
		setTimer(function()
			if shader then
				local r, g, b, a = getWaterColor()
				dxSetShaderValue(shader, "gWaterColor", r / 255, g / 255, b / 255, a / 255)
			end
		end, 50, 0)
	end
)