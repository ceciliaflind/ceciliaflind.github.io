--[[
	Basic Roleplay Gamemode
	~ Server-side functions for exported functions
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
function isPlayerAdmin(player)
	return tonumber(getElementData(player, "admin.level")) > 0
end

function isPlayerFullAdmin(player)
	return tonumber(getElementData(player, "admin.level")) > 1
end

function isPlayerLeadAdmin(player)
	return tonumber(getElementData(player, "admin.level")) > 2
end

function isPlayerHeadAdmin(player)
	return tonumber(getElementData(player, "admin.level")) > 3
end

function getAdminLevel(player)
	return tonumber(getElementData(player, "admin.level"))
end

function isLoggedIn(player)
	return tonumber(getElementData(player, "player.loggedin")) > 0
end

function getIDVehicle(vehicle)
	return tonumber(getElementData(vehicle, "vehicle.id"))
end

function isElementInRangeOfPoint(element, x, y, z, range)
	local px, py, pz = getElementPosition(element)
	return ((x-px) ^ 2 + (y-py) ^ 2 + (z-pz) ^ 2) ^ 0.5 <= range
end

function findPlayer(name, player)
	local matches = {}
	for i, v in ipairs(getElementsByType("player")) do
		if getPlayerName(v) == name then
			return v
		end
		local playerName = getPlayerName(v):gsub("#%x%x%x%x%x%x", "")
		playerName = playerName:lower()
		if playerName:find(name:lower(), 0) then
			table.insert(matches, v)
		end
	end
	if #matches == 1 then
		return matches[1]
	end
	return false
end

function isVehicleEmpty(vehicle)
    local passengers = getVehicleMaxPassengers(vehicle)
    if type(passengers) == 'number' then
        for seat = 0, passengers do
            if getVehicleOccupant(vehicle, seat) then
                return false
            end
        end
    end
    return true
end

function getPlayerFaction(player)
	return tonumber(getElementData(player, "factions.player"))
end

function isPlayerInFaction(player)
	return tonumber(getElementData(player, "factions.player")) > 0
end

function isPlayerFactionLeader(player)
	return tonumber(getElementData(player, "factions.leader")) > 0
end

function getVehicleFaction(vehicle)
	return tonumber(getElementData(vehicle, "factions.vehicle"))
end

function isVehicleInFaction(vehicle)
	return tonumber(getElementData(vehicle, "factions.vehicle")) > 0
end

function doesPlayerOwnVehicle(vehicle, player)
	return getElementData(vehicle, "vehicle.owner") == getElementData(player, "accountname")
end

function isDepartmentRadioAllowed(faction)
	return getElementData(faction, "factions.type") == "law" or getElementData(faction, "factions.type") == "medical" or getElementData(faction, "factions.type") == "news"
end

function getFactionType(faction)
	return tostring(getElementData(faction, "factions.type"))
end