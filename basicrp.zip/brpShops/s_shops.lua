--[[
	Basic Roleplay Gamemode
	~ Server-side functions for shops
	
	Created by Socialz
]]--

--[[
	Notes:
	Hey there. All items haven't been done yet, so you can do them yourself or wait for the next patch to come up.
	
	Only shops that work well are: Cafe, Gun Store, Restaurant, Clothing
	
	-Socialz 04/06/2012 11:34:00 GMT +02
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Configurations (modifyable)
-- Remember to edit in the client-side script as well
local types = {
	-- ID : Shop name
	[1] = {"Cafe"},
	[2] = {"General Store"},
	[3] = {"Gun Store"},
	[4] = {"Restaurant"},
	[5] = {"Burgershot"},
	[6] = {"Pizza Stack Co."},
	[7] = {"Cluckin' Bell"},
	[8] = {"Electronics"},
	[9] = {"Clothing"}
}

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

addCommandHandler({"makeshop", "createshop"},
	function(player, cmd, type, skin)
		if exports.brpExports:isPlayerAdmin(player) then
			local type = tonumber(type)
			if type then
				if types[type] then
					local skin = tonumber(skin)
					local x, y, z = getElementPosition(player)
					local rot = getPedRotation(player)
					if skin then
						local xml = xmlLoadFile("shops.map")
						local new = xmlCreateChild(xml, "shop")
						local id = math.random(1,99999)
						local interior = getElementInterior(player)
						local dimension = getElementDimension(player)
						local ped = createPed(skin, x, y, z, rot)
						setElementInterior(ped, interior)
						setElementDimension(ped, dimension)
						setElementFrozen(ped, true)
						xmlNodeSetAttribute(new, "id", tonumber(id))
						xmlNodeSetAttribute(new, "posx", tonumber(x))
						xmlNodeSetAttribute(new, "posy", tonumber(y))
						xmlNodeSetAttribute(new, "posz", tonumber(z))
						xmlNodeSetAttribute(new, "rotation", tonumber(rot))
						xmlNodeSetAttribute(new, "interior", tonumber(interior))
						xmlNodeSetAttribute(new, "dimension", tonumber(dimension))
						xmlNodeSetAttribute(new, "skin", tonumber(skin))
						xmlNodeSetAttribute(new, "type", type)
						xmlSaveFile(xml)
						xmlUnloadFile(xml)
						setElementData(ped, "shops.id", id)
						setElementData(ped, "shops.type", type)
						local marker = createMarker(x, y, z - 1, "cylinder", 5, 255, 0, 0, 70)
						setElementInterior(marker, interior)
						setElementDimension(marker, dimension)
						setElementData(marker, "shops.id", id)
						setElementData(marker, "shops.type", type)
						outputChatBox("Shop created (" .. id .. ").", player, 0, 255, 0, false)
					else
						local xml = xmlLoadFile("shops.map")
						local new = xmlCreateChild(xml, "shop")
						local id = math.random(1,99999)
						local skin = math.random(10,15)
						local interior = getElementInterior(player)
						local dimension = getElementDimension(player)
						local ped = createPed(skin, x, y, z, rot)
						setElementInterior(ped, interior)
						setElementDimension(ped, dimension)
						setElementFrozen(ped, true)
						xmlNodeSetAttribute(new, "id", tonumber(id))
						xmlNodeSetAttribute(new, "posx", tonumber(x))
						xmlNodeSetAttribute(new, "posy", tonumber(y))
						xmlNodeSetAttribute(new, "posz", tonumber(z))
						xmlNodeSetAttribute(new, "rotation", tonumber(rot))
						xmlNodeSetAttribute(new, "interior", tonumber(interior))
						xmlNodeSetAttribute(new, "dimension", tonumber(dimension))
						xmlNodeSetAttribute(new, "skin", tonumber(skin))
						xmlNodeSetAttribute(new, "type", type)
						xmlSaveFile(xml)
						xmlUnloadFile(xml)
						setElementData(ped, "shops.id", id)
						setElementData(ped, "shops.type", type)
						local marker = createMarker(x, y, z - 1, "cylinder", 5, 255, 0, 0, 70)
						setElementInterior(marker, interior)
						setElementDimension(marker, dimension)
						setElementData(marker, "shops.id", id)
						setElementData(marker, "shops.type", type)
						outputChatBox("Shop created (" .. id .. ").", player, 0, 255, 0, false)
					end
				else
					outputChatBox("Invalid shop type entered.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <type> [<skin>]", player, 220, 220, 0, false)
				outputChatBox("Types:", player)
				for i,v in ipairs(types) do
					outputChatBox(" " .. i .. " = " .. types[i][1], player, 220, 220, 0, false)
				end
			end
		end
	end
)

addCommandHandler("deleteshop",
	function(player, cmd, id)
		if exports.brpExports:isPlayerAdmin(player) then
			local id = tonumber(id)
			if id then
				for index,shop in ipairs(getElementsByType("shop")) do
					for i,v in ipairs(getElementsByType("ped")) do
						if tonumber(getElementData(shop, "id")) == tonumber(getElementData(v, "shops.id")) then
							local xml = xmlLoadFile("shops.map")
							local new = xmlFindChild(xml, "shop", 0)
							xmlNodeSetName(new, "deleted")
							xmlNodeSetAttribute(new, "deletedby", getPlayerName(player))
							xmlSaveFile(xml)
							xmlUnloadFile(xml)
							for k,m in ipairs(getElementsByType("marker")) do
								if tonumber(getElementData(m, "shops.id")) == tonumber(getElementData(v, "shops.id")) then
									destroyElement(m)
								end
							end
							destroyElement(v)
							outputChatBox("Shop deleted.", player, 0, 255, 0, false)
							break
						end
					end
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <id>", player, 220, 220, 0, false)
			end
		end
	end
)

-- Do not change this integer
local shops = 0

addCommandHandler("nearbyshops",
	function(player, cmd)
		if exports.brpExports:isPlayerAdmin(player) then
			outputChatBox("Nearby shops:", player)
			for i,v in ipairs(getElementsByType("ped")) do
				if getElementData(v, "shops.id") then
					local x, y, z = getElementPosition(player)
					if exports.brpExports:isElementInRangeOfPoint(v, x, y, z, 15) then
						outputChatBox(" [" .. getElementData(v, "shops.id") .. "] " .. types[tonumber(getElementData(v, "shops.type"))][1], player, 220, 220, 0, false)
						shops = 1
					end
				end
			end
			
			if shops == 0 then
				outputChatBox(" No shops nearby.", player, 255, 0, 0, false)
			else
				shops = 0
			end
		end
	end
)

addEvent("onItemBuy", true)
addEventHandler("onItemBuy", root,
	function(item, price)
		outputServerLog("[SHOPS] [PLA/BUY]: " .. getPlayerName(source) .. " bought '" .. item .. "' for $" .. price .. ".")
		takePlayerMoney(source, price)
	end
)

addEvent("onWeaponBuy", true)
addEventHandler("onWeaponBuy", root,
	function(weapon, ammo)
		giveWeapon(source, weapon, ammo, true)
		outputServerLog("[SHOPS] [PLA/BUYINFO]: Additional information: [Weapon ID: " .. weapon .. "] [Ammo Amount: " .. ammo .. "].")
	end
)

addEventHandler("onMarkerHit", root,
	function(hitElement, matchingDimension)
		if getElementType(hitElement) == "player" then
			if matchingDimension then
				if getElementData(source, "shops.id") then
					setElementData(hitElement, "shops.in", getElementData(source, "shops.id"))
				end
			end
		end
	end
)

addEventHandler("onMarkerLeave", root,
	function(hitElement, matchingDimension)
		if getElementType(hitElement) == "player" then
			if matchingDimension then
				if getElementData(source, "shops.id") then
					removeElementData(hitElement, "shops.in")
				end
			end
		end
	end
)

addEventHandler("onResourceStart", resourceRoot,
	function()
		for i,v in ipairs(getElementsByType("shop")) do
			local ped = createPed(getElementData(v, "skin"), getElementData(v, "posx"), getElementData(v, "posy"), getElementData(v, "posz"), getElementData(v, "rotation"))
			setElementInterior(ped, getElementData(v, "interior"))
			setElementDimension(ped, getElementData(v, "dimension"))
			setElementFrozen(ped, true)
			setElementData(ped, "shops.id", getElementData(v, "id"))
			setElementData(ped, "shops.type", getElementData(v, "type"))
			
			local marker = createMarker(getElementData(v, "posx"), getElementData(v, "posy"), getElementData(v, "posz") - 1, "cylinder", 5, 255, 0, 0, 70)
			setElementInterior(marker, getElementData(v, "interior"))
			setElementDimension(marker, getElementData(v, "dimension"))
			setElementData(marker, "shops.id", getElementData(v, "id"))
			setElementData(marker, "shops.type", getElementData(v, "type"))
		end
		outputServerLog("[SHOPS] [AUTO/SPAWN] All shops spawned as the resource started.")
	end
)