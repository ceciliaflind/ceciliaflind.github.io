--[[
	Basic Roleplay Gamemode
	~ Client-side functions for shops
	
	Created by Socialz
]]--

--[[
	Notes:
	Hey there. All items haven't been done yet, so you can do them yourself or wait for the next patch to come up.
	
	Only shops that work well are: Cafe, Gun Store, Restaurant, Clothing
	
	-Socialz 04/06/2012 11:34:00 GMT +02
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)
local sx, sy = guiGetScreenSize()

-- Configurations (modifyable)
-- Remember to edit in the server-side script as well
local types = {
	-- ID : Shop name
	[1] = {"Cafe"},
	[2] = {"General Store"},
	[3] = {"Gun Store"},
	[4] = {"Restaurant"},
	[5] = {"Burgershot"},
	[6] = {"Pizza Stack Co."},
	[7] = {"Cluckin' Bell"},
	[8] = {"Electronics"},
	[9] = {"Clothing"}
}

local items = {
	-- ID : Item name, Item description, Shop, Drink=1/Food=2, Weapon/Model, Ammo, Price
	-- If the item is not a drink or food, then put 'nil', same goes to weapon/model and ammo
	-- i.e. [1] = {"Example", "Example Description", 1, nil, nil, nil, 500}
	
	[1] = {"Coffee", "Tasty but hot drink.", 1, 1, nil, nil, 2},
	[2] = {"Tea", "Great English tea, delivered by the queen.", 1, 1, nil, nil, 2},
	[3] = {"Cake", "It's just a regular piece of cake.", 1, 2, nil, nil, 4},
	[4] = {"Donut", "Chocolate, strawberry and citrus, your choise.", 1, 2, nil, nil, 4},
	
	[5] = {"Map", "See where you're going.", 2, nil, nil, nil, 10},
	[6] = {"Backpack", "For larger deliveries.", 2, nil, nil, nil, 30},
	[7] = {"Notebook", "Write on it with any pencil.", 2, nil, nil, nil, 15},
	[8] = {"Pencil", "You know what to do with it.", 2, nil, nil, nil, 1},
	
	[9] = {"Colt 45", "Handgun for your usual needs.", 3, nil, 22, 40, 200},
	[10] = {"Shotgun", "Handle tough home raids with this little guy.", 3, nil, 25, 20, 400},
	[11] = {"Country Rifle", "Protect your land with a proper rifle.", 3, nil, 33, 20, 600},
	
	[12] = {"Pizza", "Mamma mia!", 4, 2, nil, nil, 15},
	[13] = {"Spaghetti", "Straight from Italy.", 4, 2, nil, nil, 15},
	[14] = {"Soup", "Nothing solid.", 4, 2, nil, nil, 12},
	[15] = {"Coffee", "Tasty but hot drink.", 4, 1, nil, nil, 2},
	[16] = {"Tea", "Great English tea, delivered by the queen.", 4, 1, nil, nil, 2},
	[17] = {"Cake", "It's just a regular piece of cake.", 4, 2, nil, nil, 4},
	[18] = {"Donut", "Chocolate, strawberry and citrus, your choise.", 4, 2, nil, nil, 4},
	
	[19] = {"Radio", "Like a phone but you don't have to pay the bills.", 8, nil, nil, nil, 50},
	[20] = {"Cell phone", "Phone with phone bills.", 8, nil, nil, nil, 50},
	[21] = {"MP3 Player", "Play your favorite music where-ever you go.", 8, nil, nil, nil, 100},
	
	[22] = {"Skin 0", "Clothes.", 9, 0, nil, nil, 20},
	[22] = {"Skin 1", "Clothes.", 9, 1, nil, nil, 20},
	[23] = {"Skin 2", "Clothes.", 9, 2, nil, nil, 20},
	[24] = {"Skin 7", "Clothes.", 9, 7, nil, nil, 20},
	[25] = {"Skin 11", "Clothes.", 9, 11, nil, nil, 20},
	[26] = {"Skin 12", "Clothes.", 9, 12, nil, nil, 20},
	[27] = {"Skin 13", "Clothes.", 9, 13, nil, nil, 20},
	[28] = {"Skin 14", "Clothes.", 9, 14, nil, nil, 20},
	[29] = {"Skin 15", "Clothes.", 9, 15, nil, nil, 20},
	[30] = {"Skin 16", "Clothes.", 9, 16, nil, nil, 20},
	[31] = {"Skin 17", "Clothes.", 9, 17, nil, nil, 20},
	[32] = {"Skin 18", "Clothes.", 9, 18, nil, nil, 20},
	[33] = {"Skin 19", "Clothes.", 9, 19, nil, nil, 20},
	[34] = {"Skin 20", "Clothes.", 9, 20, nil, nil, 20},
	[35] = {"Skin 21", "Clothes.", 9, 21, nil, nil, 20},
	[36] = {"Skin 22", "Clothes.", 9, 22, nil, nil, 20},
	[37] = {"Skin 23", "Clothes.", 9, 23, nil, nil, 20},
	[38] = {"Skin 24", "Clothes.", 9, 24, nil, nil, 20},
	[39] = {"Skin 25", "Clothes.", 9, 25, nil, nil, 20},
	[40] = {"Skin 26", "Clothes.", 9, 26, nil, nil, 20},
	[41] = {"Skin 27", "Clothes.", 9, 27, nil, nil, 20},
	[42] = {"Skin 28", "Clothes.", 9, 28, nil, nil, 20},
	[43] = {"Skin 29", "Clothes.", 9, 29, nil, nil, 20},
	[44] = {"Skin 30", "Clothes.", 9, 30, nil, nil, 20},
	[45] = {"Skin 31", "Clothes.", 9, 31, nil, nil, 20},
	[46] = {"Skin 32", "Clothes.", 9, 32, nil, nil, 20},
	[47] = {"Skin 33", "Clothes.", 9, 33, nil, nil, 20},
	[48] = {"Skin 34", "Clothes.", 9, 34, nil, nil, 20},
	[49] = {"Skin 35", "Clothes.", 9, 35, nil, nil, 20},
	[50] = {"Skin 36", "Clothes.", 9, 36, nil, nil, 20},
	[51] = {"Skin 37", "Clothes.", 9, 37, nil, nil, 20},
	[52] = {"Skin 38", "Clothes.", 9, 38, nil, nil, 20},
	[53] = {"Skin 39", "Clothes.", 9, 39, nil, nil, 20},
	[54] = {"Skin 40", "Clothes.", 9, 40, nil, nil, 20},
	[55] = {"Skin 41", "Clothes.", 9, 41, nil, nil, 20},
	[56] = {"Skin 43", "Clothes.", 9, 43, nil, nil, 20},
	[57] = {"Skin 44", "Clothes.", 9, 44, nil, nil, 20},
	[58] = {"Skin 45", "Clothes.", 9, 45, nil, nil, 20},
	[59] = {"Skin 46", "Clothes.", 9, 46, nil, nil, 20},
	[60] = {"Skin 47", "Clothes.", 9, 47, nil, nil, 20},
	[61] = {"Skin 48", "Clothes.", 9, 48, nil, nil, 20},
	[62] = {"Skin 49", "Clothes.", 9, 49, nil, nil, 20},
	[63] = {"Skin 50", "Clothes.", 9, 50, nil, nil, 20},
	[64] = {"Skin 51", "Clothes.", 9, 51, nil, nil, 20},
	[65] = {"Skin 52", "Clothes.", 9, 52, nil, nil, 20},
	[66] = {"Skin 53", "Clothes.", 9, 53, nil, nil, 20},
	[67] = {"Skin 54", "Clothes.", 9, 54, nil, nil, 20},
	[68] = {"Skin 55", "Clothes.", 9, 55, nil, nil, 20},
	[69] = {"Skin 56", "Clothes.", 9, 56, nil, nil, 20},
	[70] = {"Skin 57", "Clothes.", 9, 57, nil, nil, 20},
	[71] = {"Skin 58", "Clothes.", 9, 58, nil, nil, 20},
	[72] = {"Skin 59", "Clothes.", 9, 59, nil, nil, 20},
	[73] = {"Skin 60", "Clothes.", 9, 60, nil, nil, 20},
	[74] = {"Skin 61", "Clothes.", 9, 61, nil, nil, 20},
	[75] = {"Skin 62", "Clothes.", 9, 62, nil, nil, 20},
	[76] = {"Skin 63", "Clothes.", 9, 63, nil, nil, 20},
	[77] = {"Skin 64", "Clothes.", 9, 64, nil, nil, 20},
	[78] = {"Skin 66", "Clothes.", 9, 66, nil, nil, 20},
	[79] = {"Skin 67", "Clothes.", 9, 67, nil, nil, 20},
	[80] = {"Skin 68", "Clothes.", 9, 68, nil, nil, 20},
	[81] = {"Skin 69", "Clothes.", 9, 69, nil, nil, 20},
	[82] = {"Skin 70", "Clothes.", 9, 70, nil, nil, 20},
	[83] = {"Skin 71", "Clothes.", 9, 71, nil, nil, 20},
	[84] = {"Skin 72", "Clothes.", 9, 72, nil, nil, 20},
	[85] = {"Skin 73", "Clothes.", 9, 73, nil, nil, 20},
	[86] = {"Skin 75", "Clothes.", 9, 75, nil, nil, 20},
	[87] = {"Skin 76", "Clothes.", 9, 76, nil, nil, 20},
	[88] = {"Skin 77", "Clothes.", 9, 77, nil, nil, 20},
	[89] = {"Skin 78", "Clothes.", 9, 78, nil, nil, 20},
	[90] = {"Skin 79", "Clothes.", 9, 79, nil, nil, 20},
	[91] = {"Skin 80", "Clothes.", 9, 80, nil, nil, 20},
	[92] = {"Skin 81", "Clothes.", 9, 81, nil, nil, 20},
	[93] = {"Skin 82", "Clothes.", 9, 82, nil, nil, 20},
	[94] = {"Skin 83", "Clothes.", 9, 83, nil, nil, 20},
	[95] = {"Skin 84", "Clothes.", 9, 84, nil, nil, 20},
	[96] = {"Skin 85", "Clothes.", 9, 85, nil, nil, 20},
	[97] = {"Skin 87", "Clothes.", 9, 87, nil, nil, 20},
	[98] = {"Skin 88", "Clothes.", 9, 88, nil, nil, 20},
	[99] = {"Skin 89", "Clothes.", 9, 89, nil, nil, 20},
	[100] = {"Skin 90", "Clothes.", 9, 90, nil, nil, 20},
	[101] = {"Skin 91", "Clothes.", 9, 91, nil, nil, 20},
	[102] = {"Skin 92", "Clothes.", 9, 92, nil, nil, 20},
	[103] = {"Skin 93", "Clothes.", 9, 93, nil, nil, 20},
	[104] = {"Skin 94", "Clothes.", 9, 94, nil, nil, 20},
	[105] = {"Skin 95", "Clothes.", 9, 95, nil, nil, 20},
	[106] = {"Skin 96", "Clothes.", 9, 96, nil, nil, 20},
	[107] = {"Skin 97", "Clothes.", 9, 97, nil, nil, 20},
	[108] = {"Skin 98", "Clothes.", 9, 98, nil, nil, 20},
	[109] = {"Skin 99", "Clothes.", 9, 99, nil, nil, 20},
	[110] = {"Skin 100", "Clothes.", 9, 100, nil, nil, 20},
	[111] = {"Skin 101", "Clothes.", 9, 101, nil, nil, 20},
	[112] = {"Skin 102", "Clothes.", 9, 102, nil, nil, 20},
	[113] = {"Skin 103", "Clothes.", 9, 103, nil, nil, 20},
	[114] = {"Skin 104", "Clothes.", 9, 104, nil, nil, 20},
	[115] = {"Skin 105", "Clothes.", 9, 105, nil, nil, 20},
	[116] = {"Skin 106", "Clothes.", 9, 106, nil, nil, 20},
	[117] = {"Skin 107", "Clothes.", 9, 107, nil, nil, 20},
	[118] = {"Skin 108", "Clothes.", 9, 108, nil, nil, 20},
	[119] = {"Skin 109", "Clothes.", 9, 109, nil, nil, 20},
	[120] = {"Skin 110", "Clothes.", 9, 110, nil, nil, 20},
	[121] = {"Skin 111", "Clothes.", 9, 111, nil, nil, 20},
	[122] = {"Skin 112", "Clothes.", 9, 112, nil, nil, 20},
	[123] = {"Skin 113", "Clothes.", 9, 113, nil, nil, 20},
	[124] = {"Skin 114", "Clothes.", 9, 114, nil, nil, 20},
	[125] = {"Skin 115", "Clothes.", 9, 115, nil, nil, 20},
	[126] = {"Skin 116", "Clothes.", 9, 116, nil, nil, 20},
	[127] = {"Skin 117", "Clothes.", 9, 117, nil, nil, 20},
	[128] = {"Skin 118", "Clothes.", 9, 118, nil, nil, 20},
	[129] = {"Skin 120", "Clothes.", 9, 120, nil, nil, 20},
	[130] = {"Skin 121", "Clothes.", 9, 121, nil, nil, 20},
	[131] = {"Skin 122", "Clothes.", 9, 122, nil, nil, 20},
	[132] = {"Skin 123", "Clothes.", 9, 123, nil, nil, 20},
	[133] = {"Skin 124", "Clothes.", 9, 124, nil, nil, 20},
	[134] = {"Skin 125", "Clothes.", 9, 125, nil, nil, 20},
	[135] = {"Skin 126", "Clothes.", 9, 126, nil, nil, 20},
	[136] = {"Skin 127", "Clothes.", 9, 127, nil, nil, 20},
	[137] = {"Skin 128", "Clothes.", 9, 128, nil, nil, 20},
	[138] = {"Skin 129", "Clothes.", 9, 129, nil, nil, 20},
	[139] = {"Skin 130", "Clothes.", 9, 130, nil, nil, 20},
	[140] = {"Skin 131", "Clothes.", 9, 131, nil, nil, 20},
	[141] = {"Skin 132", "Clothes.", 9, 132, nil, nil, 20},
	[142] = {"Skin 133", "Clothes.", 9, 133, nil, nil, 20},
	[143] = {"Skin 134", "Clothes.", 9, 134, nil, nil, 20},
	[144] = {"Skin 135", "Clothes.", 9, 135, nil, nil, 20},
	[145] = {"Skin 136", "Clothes.", 9, 136, nil, nil, 20},
	[146] = {"Skin 137", "Clothes.", 9, 137, nil, nil, 20},
	[147] = {"Skin 138", "Clothes.", 9, 138, nil, nil, 20},
	[148] = {"Skin 139", "Clothes.", 9, 139, nil, nil, 20},
	[149] = {"Skin 140", "Clothes.", 9, 140, nil, nil, 20},
	[150] = {"Skin 141", "Clothes.", 9, 141, nil, nil, 20},
	[151] = {"Skin 142", "Clothes.", 9, 142, nil, nil, 20},
	[152] = {"Skin 143", "Clothes.", 9, 143, nil, nil, 20},
	[153] = {"Skin 144", "Clothes.", 9, 144, nil, nil, 20},
	[154] = {"Skin 145", "Clothes.", 9, 145, nil, nil, 20},
	[155] = {"Skin 146", "Clothes.", 9, 146, nil, nil, 20},
	[156] = {"Skin 147", "Clothes.", 9, 147, nil, nil, 20},
	[157] = {"Skin 148", "Clothes.", 9, 148, nil, nil, 20},
	[158] = {"Skin 150", "Clothes.", 9, 150, nil, nil, 20},
	[159] = {"Skin 151", "Clothes.", 9, 151, nil, nil, 20},
	[160] = {"Skin 152", "Clothes.", 9, 152, nil, nil, 20},
	[161] = {"Skin 153", "Clothes.", 9, 153, nil, nil, 20},
	[162] = {"Skin 154", "Clothes.", 9, 154, nil, nil, 20},
	[163] = {"Skin 155", "Clothes.", 9, 155, nil, nil, 20},
	[164] = {"Skin 156", "Clothes.", 9, 156, nil, nil, 20},
	[165] = {"Skin 157", "Clothes.", 9, 157, nil, nil, 20},
	[166] = {"Skin 158", "Clothes.", 9, 158, nil, nil, 20},
	[167] = {"Skin 159", "Clothes.", 9, 159, nil, nil, 20},
	[168] = {"Skin 160", "Clothes.", 9, 160, nil, nil, 20},
	[169] = {"Skin 161", "Clothes.", 9, 161, nil, nil, 20},
	[170] = {"Skin 162", "Clothes.", 9, 162, nil, nil, 20},
	[171] = {"Skin 163", "Clothes.", 9, 163, nil, nil, 20},
	[172] = {"Skin 164", "Clothes.", 9, 164, nil, nil, 20},
	[173] = {"Skin 165", "Clothes.", 9, 165, nil, nil, 20},
	[174] = {"Skin 166", "Clothes.", 9, 166, nil, nil, 20},
	[175] = {"Skin 167", "Clothes.", 9, 167, nil, nil, 20},
	[176] = {"Skin 168", "Clothes.", 9, 168, nil, nil, 20},
	[177] = {"Skin 169", "Clothes.", 9, 169, nil, nil, 20},
	[178] = {"Skin 170", "Clothes.", 9, 170, nil, nil, 20},
	[179] = {"Skin 171", "Clothes.", 9, 171, nil, nil, 20},
	[180] = {"Skin 172", "Clothes.", 9, 172, nil, nil, 20},
	[181] = {"Skin 173", "Clothes.", 9, 173, nil, nil, 20},
	[182] = {"Skin 174", "Clothes.", 9, 174, nil, nil, 20},
	[183] = {"Skin 175", "Clothes.", 9, 175, nil, nil, 20},
	[184] = {"Skin 176", "Clothes.", 9, 176, nil, nil, 20},
	[185] = {"Skin 177", "Clothes.", 9, 177, nil, nil, 20},
	[186] = {"Skin 178", "Clothes.", 9, 178, nil, nil, 20},
	[187] = {"Skin 179", "Clothes.", 9, 179, nil, nil, 20},
	[188] = {"Skin 180", "Clothes.", 9, 180, nil, nil, 20},
	[189] = {"Skin 181", "Clothes.", 9, 181, nil, nil, 20},
	[190] = {"Skin 182", "Clothes.", 9, 182, nil, nil, 20},
	[191] = {"Skin 183", "Clothes.", 9, 183, nil, nil, 20},
	[192] = {"Skin 184", "Clothes.", 9, 184, nil, nil, 20},
	[193] = {"Skin 185", "Clothes.", 9, 185, nil, nil, 20},
	[194] = {"Skin 186", "Clothes.", 9, 186, nil, nil, 20},
	[195] = {"Skin 187", "Clothes.", 9, 187, nil, nil, 20},
	[196] = {"Skin 188", "Clothes.", 9, 188, nil, nil, 20},
	[197] = {"Skin 189", "Clothes.", 9, 189, nil, nil, 20},
	[198] = {"Skin 190", "Clothes.", 9, 190, nil, nil, 20},
	[199] = {"Skin 191", "Clothes.", 9, 191, nil, nil, 20},
	[200] = {"Skin 192", "Clothes.", 9, 192, nil, nil, 20},
	[201] = {"Skin 193", "Clothes.", 9, 193, nil, nil, 20},
	[202] = {"Skin 194", "Clothes.", 9, 194, nil, nil, 20},
	[203] = {"Skin 195", "Clothes.", 9, 195, nil, nil, 20},
	[204] = {"Skin 196", "Clothes.", 9, 196, nil, nil, 20},
	[205] = {"Skin 197", "Clothes.", 9, 197, nil, nil, 20},
	[206] = {"Skin 198", "Clothes.", 9, 198, nil, nil, 20},
	[207] = {"Skin 199", "Clothes.", 9, 199, nil, nil, 20},
	[208] = {"Skin 200", "Clothes.", 9, 200, nil, nil, 20},
	[209] = {"Skin 201", "Clothes.", 9, 201, nil, nil, 20},
	[210] = {"Skin 202", "Clothes.", 9, 202, nil, nil, 20},
	[211] = {"Skin 203", "Clothes.", 9, 203, nil, nil, 20},
	[212] = {"Skin 204", "Clothes.", 9, 204, nil, nil, 20},
	[213] = {"Skin 205", "Clothes.", 9, 205, nil, nil, 20},
	[214] = {"Skin 206", "Clothes.", 9, 206, nil, nil, 20},
	[215] = {"Skin 207", "Clothes.", 9, 207, nil, nil, 20},
	[216] = {"Skin 209", "Clothes.", 9, 209, nil, nil, 20},
	[217] = {"Skin 210", "Clothes.", 9, 210, nil, nil, 20},
	[218] = {"Skin 211", "Clothes.", 9, 211, nil, nil, 20},
	[219] = {"Skin 212", "Clothes.", 9, 212, nil, nil, 20},
	[220] = {"Skin 213", "Clothes.", 9, 213, nil, nil, 20},
	[221] = {"Skin 214", "Clothes.", 9, 214, nil, nil, 20},
	[222] = {"Skin 215", "Clothes.", 9, 215, nil, nil, 20},
	[223] = {"Skin 216", "Clothes.", 9, 216, nil, nil, 20},
	[224] = {"Skin 217", "Clothes.", 9, 217, nil, nil, 20},
	[225] = {"Skin 218", "Clothes.", 9, 218, nil, nil, 20},
	[226] = {"Skin 219", "Clothes.", 9, 219, nil, nil, 20},
	[227] = {"Skin 220", "Clothes.", 9, 220, nil, nil, 20},
	[228] = {"Skin 221", "Clothes.", 9, 221, nil, nil, 20},
	[229] = {"Skin 222", "Clothes.", 9, 222, nil, nil, 20},
	[230] = {"Skin 223", "Clothes.", 9, 223, nil, nil, 20},
	[231] = {"Skin 224", "Clothes.", 9, 224, nil, nil, 20},
	[232] = {"Skin 225", "Clothes.", 9, 225, nil, nil, 20},
	[233] = {"Skin 226", "Clothes.", 9, 226, nil, nil, 20},
	[234] = {"Skin 227", "Clothes.", 9, 227, nil, nil, 20},
	[235] = {"Skin 228", "Clothes.", 9, 228, nil, nil, 20},
	[236] = {"Skin 229", "Clothes.", 9, 229, nil, nil, 20},
	[237] = {"Skin 230", "Clothes.", 9, 230, nil, nil, 20},
	[238] = {"Skin 231", "Clothes.", 9, 231, nil, nil, 20},
	[239] = {"Skin 232", "Clothes.", 9, 232, nil, nil, 20},
	[240] = {"Skin 233", "Clothes.", 9, 233, nil, nil, 20},
	[241] = {"Skin 234", "Clothes.", 9, 234, nil, nil, 20},
	[242] = {"Skin 235", "Clothes.", 9, 235, nil, nil, 20},
	[243] = {"Skin 236", "Clothes.", 9, 236, nil, nil, 20},
	[244] = {"Skin 237", "Clothes.", 9, 237, nil, nil, 20},
	[245] = {"Skin 238", "Clothes.", 9, 238, nil, nil, 20},
	[246] = {"Skin 240", "Clothes.", 9, 240, nil, nil, 20},
	[247] = {"Skin 241", "Clothes.", 9, 241, nil, nil, 20},
	[248] = {"Skin 242", "Clothes.", 9, 242, nil, nil, 20},
	[249] = {"Skin 243", "Clothes.", 9, 243, nil, nil, 20},
	[250] = {"Skin 244", "Clothes.", 9, 244, nil, nil, 20},
	[251] = {"Skin 245", "Clothes.", 9, 245, nil, nil, 20},
	[252] = {"Skin 246", "Clothes.", 9, 246, nil, nil, 20},
	[253] = {"Skin 247", "Clothes.", 9, 247, nil, nil, 20},
	[254] = {"Skin 248", "Clothes.", 9, 248, nil, nil, 20},
	[255] = {"Skin 249", "Clothes.", 9, 249, nil, nil, 20},
	[256] = {"Skin 250", "Clothes.", 9, 250, nil, nil, 20},
	[257] = {"Skin 251", "Clothes.", 9, 251, nil, nil, 20},
	[258] = {"Skin 252", "Clothes.", 9, 252, nil, nil, 20},
	[259] = {"Skin 253", "Clothes.", 9, 253, nil, nil, 20},
	[260] = {"Skin 254", "Clothes.", 9, 254, nil, nil, 20},
	[261] = {"Skin 255", "Clothes.", 9, 255, nil, nil, 20},
	[262] = {"Skin 256", "Clothes.", 9, 256, nil, nil, 20},
	[263] = {"Skin 257", "Clothes.", 9, 257, nil, nil, 20},
	[264] = {"Skin 258", "Clothes.", 9, 258, nil, nil, 20},
	[265] = {"Skin 259", "Clothes.", 9, 259, nil, nil, 20},
	[266] = {"Skin 260", "Clothes.", 9, 260, nil, nil, 20},
	[267] = {"Skin 261", "Clothes.", 9, 261, nil, nil, 20},
	[268] = {"Skin 262", "Clothes.", 9, 262, nil, nil, 20},
	[269] = {"Skin 263", "Clothes.", 9, 263, nil, nil, 20},
	[270] = {"Skin 264", "Clothes.", 9, 264, nil, nil, 20},
	[271] = {"Skin 268", "Clothes.", 9, 268, nil, nil, 20},
	[272] = {"Skin 269", "Clothes.", 9, 269, nil, nil, 20},
	[273] = {"Skin 270", "Clothes.", 9, 270, nil, nil, 20},
	[274] = {"Skin 271", "Clothes.", 9, 271, nil, nil, 20},
	[275] = {"Skin 272", "Clothes.", 9, 272, nil, nil, 20},
	[276] = {"Skin 273", "Clothes.", 9, 273, nil, nil, 20},
	[277] = {"Skin 289", "Clothes.", 9, 289, nil, nil, 20},
	[278] = {"Skin 290", "Clothes.", 9, 290, nil, nil, 20},
	[279] = {"Skin 291", "Clothes.", 9, 291, nil, nil, 20},
	[280] = {"Skin 292", "Clothes.", 9, 292, nil, nil, 20},
	[281] = {"Skin 293", "Clothes.", 9, 293, nil, nil, 20},
	[282] = {"Skin 294", "Clothes.", 9, 294, nil, nil, 20},
	[283] = {"Skin 295", "Clothes.", 9, 295, nil, nil, 20},
	[284] = {"Skin 296", "Clothes.", 9, 296, nil, nil, 20},
	[285] = {"Skin 297", "Clothes.", 9, 297, nil, nil, 20},
	[286] = {"Skin 298", "Clothes.", 9, 298, nil, nil, 20},
	[287] = {"Skin 299", "Clothes.", 9, 299, nil, nil, 20},
	[288] = {"Skin 300", "Clothes.", 9, 300, nil, nil, 20},
	[289] = {"Skin 301", "Clothes.", 9, 301, nil, nil, 20},
	[290] = {"Skin 302", "Clothes.", 9, 302, nil, nil, 20},
	[291] = {"Skin 303", "Clothes.", 9, 303, nil, nil, 20},
	[292] = {"Skin 304", "Clothes.", 9, 304, nil, nil, 20},
	[293] = {"Skin 305", "Clothes.", 9, 305, nil, nil, 20},
	[294] = {"Skin 306", "Clothes.", 9, 306, nil, nil, 20},
	[295] = {"Skin 307", "Clothes.", 9, 307, nil, nil, 20},
	[296] = {"Skin 308", "Clothes.", 9, 308, nil, nil, 20},
	[297] = {"Skin 309", "Clothes.", 9, 309, nil, nil, 20},
	[298] = {"Skin 310", "Clothes.", 9, 310, nil, nil, 20},
	[299] = {"Skin 311", "Clothes.", 9, 311, nil, nil, 20},
	[300] = {"Skin 312", "Clothes.", 9, 312, nil, nil, 20}
}

-- Functions
function createShopList(type)
	shop_window = guiCreateWindow((sx - 490) / 2, (sy - 300) / 2, 393, 310, types[tonumber(type)][1], false)
	guiWindowSetSizable(shop_window, false)
	
	shop_list = guiCreateGridList(17, 28, 358, 224, false, shop_window)
	guiGridListSetSelectionMode(shop_list, 0)
	guiGridListSetSortingEnabled(shop_list, false)
	local itemColumn = guiGridListAddColumn(shop_list, "Item", 0.2)
	local priceColumn = guiGridListAddColumn(shop_list, "Price", 0.1)
	local descriptionColumn = guiGridListAddColumn(shop_list, "Description", 1.0)

	for i,v in ipairs(items) do
		local row = guiGridListAddRow(shop_list)
		if items[i][3] == tonumber(type) then
			guiGridListSetItemText(shop_list, row, itemColumn, items[i][1], false, false)
			guiGridListSetItemText(shop_list, row, priceColumn, "$" .. items[i][7], false, false)
			guiGridListSetItemText(shop_list, row, descriptionColumn, items[i][2], false, false)
		end
	end
	
	shop_buy = guiCreateButton(17, 257, 171, 38, "Buy Item", false, shop_window)
	guiSetFont(shop_buy, "clear-normal")
	
	shop_close = guiCreateButton(204 ,257, 171, 38, "Close Window", false, shop_window)
	guiSetFont(shop_close, "clear-normal")
	
	addEventHandler("onClientGUIClick", shop_buy, buyItem, false)
	addEventHandler("onClientGUIClick", shop_close, closeShop, false)
end

function createNoticeWindow()
	notice_window = guiCreateWindow((sx - 450) / 2, (sy - 250) / 2, 349, 90, "Notice!", false)
	guiWindowSetSizable(notice_window, false)
	guiSetAlpha(notice_window, 0.9)
	
	notice_label = guiCreateLabel(61, 39, 208, 18, "You cannot afford to buy that item.", false, notice_window)
	guiLabelSetColor(notice_label, 255, 0, 0)
	guiLabelSetVerticalAlign(notice_label, "center")
	guiLabelSetHorizontalAlign(notice_label, "center", false)
	guiSetFont(notice_label, "default-bold-small")
	
	setTimer(function()
		destroyElement(notice_window)
	end, 2000, 1)
end

addEventHandler("onClientClick", root,
	function(button, state, absoluteX, absoluteY, worldX, worldY, worldZ, clickedElement)
		if button == "left" and state == "up" then
			if clickedElement and getElementType(clickedElement) == "ped" then
				if getElementData(clickedElement, "shops.id") then
					if getElementData(localPlayer, "shops.in") then
						if not isElement(shop_window) then
							createShopList(getElementData(clickedElement, "shops.type"))
							outputChatBox("Welcome to our shop!", 255, 255, 255, false)
							showCursor(true)
							guiSetInputEnabled(true)
						else
							destroyElement(shop_window)
							showCursor(false)
							guiSetInputEnabled(false)
						end
					else
						outputChatBox("Get nearer the shopkeeper.", 200, 0, 0, false)
					end
				end
			end
		end
	end
)

function buyItem(button, state, x, y)
	local selectedRow, selectedCol = guiGridListGetSelectedItem(shop_list)
    local item = guiGridListGetItemText(shop_list, selectedRow, selectedCol)
	if item ~= "" then
		for key,value in ipairs(items) do
			if items[key][1] == item then
				if getPlayerMoney(localPlayer) >= items[key][7] then
					destroyElement(shop_window)
					showCursor(false)
					guiSetInputEnabled(false)
					outputChatBox("You bought '" .. item .. "'.", 255, 255, 0, false)
					triggerServerEvent("onItemBuy", localPlayer, item, items[key][7])
					
					for i,v in ipairs(items) do
						if items[i][5] ~= nil and items[i][3] == 3 and items[i][1] == item then
							triggerServerEvent("onWeaponBuy", localPlayer, items[i][4], items[i][5])
						end
					end
					
					for i,v in ipairs(items) do
						if items[i][4] ~= nil and items[i][3] == 1 or items[i][3] == 4 or items[i][3] == 5 or items[i][3] == 6 or items[i][3] == 7 and items[i][1] == item then
							if items[i][4] == 1 then
								setPedAnimation(localPlayer, "BAR", "dnk_stndM_loop", -1, false, false, false, true)
								setTimer(setPedAnimation, 2000, 1, localPlayer)
							else
								setPedAnimation(localPlayer, "FOOD", "EAT_Burger", -1, false, false, false, true)
								setTimer(setPedAnimation, 2000, 1, localPlayer)
							end
						end
					end
					
					for i,v in ipairs(items) do
						if items[i][4] ~= nil and items[i][3] == 9 and items[i][1] == item then
							setElementModel(localPlayer, items[i][4], items[i][5])
						end
					end
					break
				else
					if not isElement(notice_window) then
						createNoticeWindow()
					end
				end
			end
		end
	else
		outputChatBox("Choose an item first to buy it.", 255, 0, 0, false)
	end
end

function closeShop()
	destroyElement(shop_window)
	showCursor(false)
	guiSetInputEnabled(false)
	outputChatBox("Thanks for visiting - welcome back later!", 255, 255, 0, false)
end