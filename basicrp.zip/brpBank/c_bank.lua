--[[
	Basic Roleplay Gamemode
	~ Client-side functions for bank
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)
local screenx, screeny = guiGetScreenSize()

-- Configurations (modifyable)
local bank_name = "First Bank of Los Santos"

-- Functions
function createBankWindow()
	-- Bank
	bank_window = guiCreateWindow((screenx - 839) / 2, (screeny - 419) / 2, 259, 199, bank_name, false)
	
	bank_welcome = guiCreateLabel(14, 25, 234, 16, "Welcome to the First Bank of Los Santos!", false, bank_window)
	guiSetFont(bank_welcome, "default-bold-small")
	
	bank_balance = guiCreateLabel(16, 47, 234, 16, "", false, bank_window)
	guiSetFont(bank_balance, "default-bold-small")
	
	bank_withdraw = guiCreateEdit(17, 80, 112, 30, "", false, bank_window)
	bank_withdrawbutton = guiCreateButton(136, 81, 110, 31, "Withdraw", false, bank_window)
	
	bank_deposit = guiCreateEdit(17, 116, 112, 30, "", false, bank_window)
	bank_depositbutton = guiCreateButton(137, 116, 109, 31, "Deposit", false, bank_window)
	
	bank_closebutton = guiCreateButton(16, 153, 229, 32, "Close Window", false, bank_window)
		
	addEventHandler("onClientGUIClick", bank_withdrawbutton, brpWithdraw, false)
	addEventHandler("onClientGUIClick", bank_depositbutton, brpDeposit, false)
	addEventHandler("onClientGUIClick", bank_closebutton, brpCloseWindow, false)
end

function createATMWindow()
	-- ATMs
	atm_window = guiCreateWindow((screenx - 839) / 2, (screeny - 419) / 2, 259, 199, bank_name, false)
	
	atm_welcome = guiCreateLabel(14, 25, 234, 16, "Welcome to the First Bank of Los Santos!", false, atm_window)
	guiSetFont(atm_welcome, "default-bold-small")
	
	atm_balance = guiCreateLabel(16, 47, 234, 16, "", false, atm_window)
	guiSetFont(atm_balance, "default-bold-small")
	
	atm_withdraw = guiCreateEdit(17, 80, 112, 30, "", false, atm_window)
	atm_withdrawbutton = guiCreateButton(136, 81, 110, 31, "Withdraw", false, atm_window)
	
	atm_deposit = guiCreateEdit(17, 116, 112, 30, "", false, atm_window)
	atm_depositbutton = guiCreateButton(137, 116, 109, 31, "Deposit", false, atm_window)
	guiSetEnabled(atm_deposit, false)
	guiSetEnabled(atm_depositbutton, false)
	
	atm_closebutton = guiCreateButton(16, 153, 229, 32, "Close Window", false, atm_window)
		
	addEventHandler("onClientGUIClick", atm_withdrawbutton, brpWithdraw, false)
	addEventHandler("onClientGUIClick", atm_closebutton, brpCloseWindow, false)
end

function brpWithdraw()
	local bank = guiGetText(bank_withdraw)
	local atm = guiGetText(atm_withdraw)
	
	if isElement(bank_window) then
		if tonumber(bank) then
			if tonumber(bank) > 0 and tonumber(bank) <= getElementData(localPlayer, "account.bank") then
				destroyElement(bank_window)
				showCursor(false)
				guiSetInputEnabled(false)
				setElementData(localPlayer, "account.bank", getElementData(localPlayer, "account.bank") - tonumber(bank))
				outputChatBox(" You withdrawed " .. tonumber(bank) .. " dollars from your bank account.", 0, 255, 0, false)
				triggerServerEvent("onBankWithdraw", localPlayer, bank)
			else
				outputChatBox("Value must be numbers, over 0 dollars and less than in your bank account.", 255, 0, 0, false)
			end
		else
			outputChatBox("Enter a value first.", 255, 0, 0, false)
		end
	elseif isElement(atm_window) then
		if tonumber(atm) then
			if tonumber(atm) > 0 and tonumber(atm) <= getElementData(localPlayer, "account.bank") then
				destroyElement(atm_window)
				showCursor(false)
				guiSetInputEnabled(false)
				setElementData(localPlayer, "account.bank", getElementData(localPlayer, "account.bank") - tonumber(atm))
				outputChatBox(" You withdrawed " .. tonumber(bank) .. " dollars from your bank account.", 0, 255, 0, false)
				triggerServerEvent("onATMWithdraw", localPlayer, atm)
			else
				outputChatBox("Value must be numbers, over 0 dollars and less than in your bank account.", 255, 0, 0, false)
			end
		else
			outputChatBox("Enter a value first.", 255, 0, 0, false)
		end
	end
end

function brpDeposit()
	local bank = guiGetText(bank_deposit)
	if tonumber(bank) then
		if tonumber(bank) > 0 and tonumber(bank) <= getPlayerMoney(localPlayer) then
			destroyElement(bank_window)
			showCursor(false)
			guiSetInputEnabled(false)
			setElementData(localPlayer, "account.bank", getElementData(localPlayer, "account.bank") + tonumber(bank))
			outputChatBox(" You deposited " .. tonumber(bank) .. " dollars to your bank account.", 0, 255, 0, false)
			triggerServerEvent("onBankDeposit", localPlayer, bank)
		else
			outputChatBox("Value must be numbers, over 0 dollars and less than in your wallet.", 255, 0, 0, false)
		end
	else
		outputChatBox("Enter a value first.", 255, 0, 0, false)
	end
end

function brpCloseWindow()
	if isElement(bank_window) then
		destroyElement(bank_window)
		showCursor(false)
		guiSetInputEnabled(false)
	elseif isElement(atm_window) then
		destroyElement(atm_window)
		showCursor(false)
		guiSetInputEnabled(false)
	end
end

addEventHandler("onClientClick", cRoot,
	function(button, state, absoluteX, absoluteY, worldX, worldY, worldZ, clickedElement)
		if button == "left" and state == "up" then
			if clickedElement then
				if getElementData(clickedElement, "world.bank") == 1 then
					if isElement(bank_window) then
						destroyElement(bank_window)
						showCursor(false)
						guiSetInputEnabled(false)
					else
						outputChatBox("Welcome to First Bank of Los Santos.", 255, 255, 255, false)
						createBankWindow()
						showCursor(true)
						guiSetInputEnabled(true)
						guiSetText(bank_balance, "Cash: $" .. getElementData(localPlayer, "account.bank"))
					end
				elseif getElementData(clickedElement, "world.atm") == 1 then
					if isElement(atm_window) then
						destroyElement(atm_window)
						showCursor(false)
						guiSetInputEnabled(false)
					else
						outputChatBox("Welcome to First Bank of Los Santos.", 255, 255, 255, false)
						createATMWindow()
						showCursor(true)
						guiSetInputEnabled(true)
						guiSetText(atm_balance, "Cash: $" .. getElementData(localPlayer, "account.bank"))
					end
				end
			end
		end
	end
)