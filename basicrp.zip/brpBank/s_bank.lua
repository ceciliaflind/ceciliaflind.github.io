--[[
	Basic Roleplay Gamemode
	~ Server-side functions for bank
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
local addCommandHandler_ = addCommandHandler
      addCommandHandler  = function(commandName, fn, restricted, caseSensitive)
	if type(commandName) ~= "table" then
		commandName = {commandName}
	end
	for key, value in ipairs(commandName) do
		if key == 1 then
			addCommandHandler_(value, fn, restricted, caseSensitive)
		else
			addCommandHandler_(value,
				function(player, ...)
					fn(player, ...)
				end
			)
		end
	end
end

addEventHandler("onResourceStart", cThisRoot,
	function()
		local bankwoman = createPed(150, 2306.97, -8.63, 26.88)
		setElementData(bankwoman, "world.bank", 1)
		setElementFrozen(bankwoman, true)
		setElementDimension(bankwoman, 0)
		setElementInterior(bankwoman, 0)
		setPedRotation(bankwoman, -90)
		setTimer(setPedAnimation, 1000, 1, bankwoman, "FOOD", "FF_Sit_Look", -1, true, false, false, true)
		setTimer(setPedAnimation, 20000, 0, bankwoman, "FOOD", "FF_Sit_Look", -1, true, false, false, true)
		outputServerLog("[BANK] [AUTO/SPAWN]: Bank spawned as the resource started.")
	end
)

-- ~ [MYMONEY, WALLET, MYWALLET] ~ --
addCommandHandler({"mymoney", "wallet", "mywallet"},
	function(player, cmd)
		outputChatBox("Current money in your wallet: $" .. getPlayerMoney(player) .. ".", player, 255, 255, 0, false)
		outputServerLog("[BANK] [CMD/MYMONEY]: " .. getPlayerName(player) .. " checked their current money in wallet.")
	end
)

addEvent("onBankWithdraw", true)
addEventHandler("onBankWithdraw", cRoot,	
	function(bank)
		givePlayerMoney(source, tonumber(bank))
		outputServerLog("[BANK] [PLA/BANK/WITHDRAW]: " .. getPlayerName(player) .. " withdraw'd " .. tonumber(bank) .. " dollars from their bank account via a bank.")
	end
)

addEvent("onBankDeposit", true)
addEventHandler("onBankDeposit", cRoot,	
	function(bank)
		takePlayerMoney(source, tonumber(bank))
		outputServerLog("[BANK] [PLA/BANK/DEPOSIT]: " .. getPlayerName(player) .. " deposit'd " .. tonumber(bank) .. " dollars to their bank account via a bank.")
	end
)

addEvent("onATMWithdraw", true)
addEventHandler("onATMWithdraw", cRoot,	
	function(atm)
		givePlayerMoney(source, tonumber(atm))
		outputServerLog("[BANK] [PLA/ATM/WITHDRAW]: " .. getPlayerName(player) .. " withdraw'd " .. tonumber(atm) .. " dollars from their bank account via an ATM.")
	end
)

addCommandHandler("createatm",
	function(player, cmd)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			local xml = xmlLoadFile("atms.map")
			local new = xmlCreateChild(xml, "atm")
			local px, py, pz = getElementPosition(player)
			local rx, ry, rz = getElementRotation(player)
			local interior = getElementInterior(player)
			local dimension = getElementDimension(player)
			local id = math.random(0,9999)
			local atm = createObject(2942, tonumber(px), tonumber(py), tonumber(pz) - 0.3, tonumber(rx), tonumber(ry), tonumber(rz) - 180)
			setElementFrozen(atm, true)
			setElementInterior(atm, tonumber(interior))
			setElementDimension(atm, tonumber(dimension))
			xmlNodeSetAttribute(new, "id", tonumber(id))
			xmlNodeSetAttribute(new, "posx", tonumber(px))
			xmlNodeSetAttribute(new, "posy", tonumber(py))
			xmlNodeSetAttribute(new, "posz", tonumber(pz) - 0.3)
			xmlNodeSetAttribute(new, "rotx", tonumber(rx))
			xmlNodeSetAttribute(new, "roty", tonumber(ry))
			xmlNodeSetAttribute(new, "rotz", tonumber(rz) - 180)
			xmlNodeSetAttribute(new, "createdby", getPlayerName(player))
			xmlSaveFile(xml)
			xmlUnloadFile(xml)
			setElementData(atm, "world.atm", 1)
			setElementData(atm, "world.atm_id", tonumber(id))
			outputChatBox("Successfully created ATM ID " .. tonumber(id) .. ".", player, 220, 220, 0, false)
			outputServerLog("[BANK] [CMD/CREATEATM]: " .. getPlayerName(player) .. " created an ATM [" .. id .. "] at " .. px .. ", " .. py .. ", " .. pz .. ".")
		end
	end
)

addCommandHandler("nearbyatms",
	function(player, cmd)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			local x, y, z = getElementPosition(player)
			outputChatBox("Nearby ATMs:", player)
				for i,v in ipairs(getElementsByType("object")) do
					local x, y, z = getElementPosition(player)
					if exports.brpExports:isElementInRangeOfPoint(v, x, y, z, 10) then
						outputChatBox(" [" .. getElementData(v, "world.atm_id") .. "] ATM machine", player, 220, 220, 0, false)
					end
				end
			outputServerLog("[BANK] [CMD/NEARBYATMS]: " .. getPlayerName(player) .. " checked nearby ATMs at " .. (math.floor( x * 100 ) / 100) .. ", " .. (math.floor( y * 100 ) / 100) .. ", " .. (math.floor( z * 100 ) / 100) .. ".")
		end
	end
)

addCommandHandler({"deleteatm", "delatm"},
	function(player, cmd, id)
		if exports.brpExports:isPlayerLeadAdmin(player) then
			if id then
				local xml = xmlLoadFile("atms.map")
				for i,v in ipairs(xmlNodeGetChildren(xml)) do
					if xmlNodeGetAttribute(v, "id") == id then
						xmlNodeSetName(v, "deleted")
						xmlNodeSetAttribute(v, "deletedby", getPlayerName(player))
						xmlSaveFile(xml)
						xmlUnloadFile(xml)
						outputChatBox("Deleted ATM ID " .. tonumber(id) .. ".", player, 0, 255, 0, false)
						outputServerLog("[BANK] [CMD/DELETEATM]: " .. getPlayerName(player) .. " deleted ATM ID " .. tonumber(id) .. ".")
						for index,atm in ipairs(getElementsByType("object", cThisRoot)) do
							if getElementData(atm, "world.atm_id") == id or getElementID(atm) == id then
								destroyElement(atm)
								break
							end
						end
						break
					end
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <id>", player, 220, 220, 0, false)
			end
		end
	end
)

addEventHandler("onResourceStart", cThisRoot,
	function()
		for i,v in ipairs(getElementsByType("atm")) do
			local atm = createObject(2942, getElementData(v, "posx"), getElementData(v, "posy"), getElementData(v, "posz"), getElementData(v, "rotx"), getElementData(v, "roty"), getElementData(v, "rotz"))
			setElementData(atm, "world.atm", 1)
			setElementData(atm, "world.atm_id", getElementData(v, "id"))
		end
		
		outputServerLog("[BANK] [AUTO/SPAWN]: All ATMs spawned as the resource started.")
	end
)