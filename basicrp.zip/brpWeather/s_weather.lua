--[[
	Basic Roleplay Gamemode
	~ Server-side functions for weather
	
	Created by Socialz
]]--

-- Miniatures
local cRoot = getRootElement()
local cThis = getThisResource()
local cThisRoot = getResourceRootElement(cThis)

-- Functions
-- ~ [SETWEATHER] ~ --
addCommandHandler("setweather",
	function(player, cmd, id)
		if exports.brpExports:isPlayerAdmin(player) then
			if id then
				if tonumber(id) then
					setWeather(tonumber(id))
					outputChatBox("Weather changed to " .. tonumber(id) .. ".", player, 220, 220, 0, false)
					outputServerLog("[WEATHER] [CMD/SETWEATHER]: " .. getPlayerName(player) .. " set the weather to " .. tonumber(id) .. ".")
				else
					outputChatBox("ID value must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <id>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETRAIN] ~ --
addCommandHandler("setrain",
	function(player, cmd, level)
		if exports.brpExports:isPlayerAdmin(player) then
			if level then
				if tonumber(level) then
					setRainLevel(tonumber(level))
					outputChatBox("Rain level changed to " .. tonumber(level) .. ".", player, 220, 220, 0, false)
					outputServerLog("[WEATHER] [CMD/SETRAIN]: " .. getPlayerName(player) .. " set the rain level to " .. tonumber(level) .. ".")
				else
					outputChatBox("Rain level must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <level>", player, 220, 220, 0, false)
			end
		end
	end
)

-- ~ [SETWAVE] ~ --
addCommandHandler("setwave",
	function(player, cmd, level)
		if exports.brpExports:isPlayerAdmin(player) then
			if level then
				if tonumber(level) then
					setWaveHeight(tonumber(level))
					outputChatBox("Wave level changed to " .. tonumber(level) .. ".", player, 220, 220, 0, false)
					outputServerLog("[WEATHER] [CMD/SETWAVE]: " .. getPlayerName(player) .. " set the wave level to " .. tonumber(level) .. ".")
				else
					outputChatBox("Wave level must be numbers.", player, 255, 0, 0, false)
				end
			else
				outputChatBox("Syntax: /" .. cmd .. " <level>", player, 220, 220, 0, false)
			end
		end
	end
)

function realisticWeather()
	local current = getWeather()
	if current == 0 then
		setWeather(1)
		setWaterLevel(0.1)
		setWaveHeight(1)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 1, water level changed to 0.1, wave height changed to 1.")
	elseif current == 1 then
		setWeather(2)
		setWaterLevel(0.2)
		setWaveHeight(1)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 2, water level changed to 0.2, wave height changed to 1.")
	elseif current == 2 then
		setWeather(3)
		setWaterLevel(0.2)
		setWaveHeight(1)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 3, water level changed to 0.2, wave height changed to 1.")
	elseif current == 3 then
		setWeather(4)
		setWaterLevel(0.2)
		setWaveHeight(1)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 4, water level changed to 0.2, wave height changed to 1.")
	elseif current == 4 then
		setWeather(5)
		setWaterLevel(0.3)
		setWaveHeight(1)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 5, water level changed to 0.3, wave height changed to 1.")
	elseif current == 5 then
		setWeather(6)
		setWaterLevel(0.2)
		setWaveHeight(1)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 6, water level changed to 0.2, wave height changed to 1.")
	elseif current == 7 then
		setWeather(10)
		setWaterLevel(0)
		setWaveHeight(0.7)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 10, water level changed to 0, wave height changed to 0.7.")
	elseif current == 10 then
		setWeather(12)
		setWaterLevel(0)
		setWaveHeight(0.6)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 12, water level changed to 0, wave height changed to 0.6.")
	elseif current == 12 then
		setWeather(8)
		setWaterLevel(3)
		setWaveHeight(1.8)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 8, water level changed to 3, wave height changed to 1.8.")
	elseif current == 8 then
		setWeather(0)
		setWaterLevel(0.7)
		setWaveHeight(1.4)
		outputServerLog("[WEATHER] [AUTO/WEATHER]: Weather changed to ID 0, water level changed to 0.7, wave height changed to 1.4.")
	end
end

addEventHandler("onResourceStart", cThisRoot,
	function()
		setTimer(realisticWeather, 3600000, 0)
	end
)