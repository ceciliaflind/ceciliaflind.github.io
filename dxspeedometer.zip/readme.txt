
Installation
------------
As usual, put the resource in your resources folder. You dont have to do anything else, except if you want to change the default settings. To do this, you need to edit the defaultSettings.lua file. 

Features
--------
Analog Speedometer

- Fully drawn by MTA's dx-functions
- Every vehicle can have it's own scale
- Show maxspeed reached since you entered the current vehicle
- Inlcudes a altimeter (shows the height in planes or helicopters)

Analog Odometer

- Trip Odometer that can be reset, as well as Total Distance Odometer
- Digits actually turn like they would in a real car
- Distance driven is saved in a local file, so it will stay even when the player leaves the server

Includes an extensive settings GUI that allows each player to customize the speedometer to their liking and save those changes.
