local vZones = {
	{x = -1993, y = 830, z = 15, width = 100, depth = 100, height = 3000},
}

-- initialize all zones on resource start
local z = {}
function initvZones()
	if vZones and #vZones ~= 0 then
		for _,v in ipairs (vZones) do
			if v then
				if v.x and v.y and v.z and v.width and v.depth and v.height then
					local c = createColCuboid (v.x, v.y, v.z, v.width, v.depth, v.height)
					if c then
						z[c] = true
						for _,v in ipairs (getElementsByType("vehicle")) do
							if isElementWithinColShape (v, c) then
								destroyElement(v)
							end
						end
						addEventHandler ("onElementDestroy", c,
							function()
								if z[source] then
									z[source] = nil
								end
							end
						)
						addEventHandler ("onColShapeHit", c,
							function (h, d)
								if h and d and isElement(h) and getElementType (h) == "vehicle" then
									destroyElement (h)
								end
							end
						)
					end
				end
			end
		end
	end
end
addEventHandler ("onResourceStart", resourceRoot, initvZones)

-- The script works fine by itself, but if later any issues occur with removing vehicles, enabling this part may resolve them:
--[[
function destroyVehiclesInvZone()
	if isElement(source) and getElementType (source) == "vehicle" then
		setTimer(function(source)
			if z then
				for zone,v in pairs(z) do
					if zone and isElement(zone) then
						if isElement(source) and isElementWithinColShape(source, zone) then
							destroyElement (source)
						end
					end
				end
			end
		end, 350, 1, source)
	end
end
addEventHandler ("onElementStartSync", root, destroyVehiclesInvZone)--]]