function godmodeHandler ()
  cancelEvent ()
end

addEvent ("enableGodMode",true)
addEventHandler ("enableGodMode",getRootElement(),
function()
  if (source == getLocalPlayer()) then
    addEventHandler ("onClientPlayerDamage",getRootElement(),godmodeHandler)
  end
end)

addEvent ("disableGodMode",true)
addEventHandler ("disableGodMode",getRootElement(),
function()
  if (source == getLocalPlayer()) then
    removeEventHandler ("onClientPlayerDamage",getRootElement(),godmodeHandler)
  end
end)