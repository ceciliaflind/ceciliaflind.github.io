------------------------------------------------------------------------------------------------------
-- * @Author		  Pun1sh3r
-- * @Copyright		  2011-2014 by Pun1sh3r
------------------------------------------------------------------------------------------------------

WinnerName1 = nil
WinnerCar1 = nil
----------------------
WinnerName2 = nil
WinnerCar2 = nil
----------------------
WinnerName3 = nil
WinnerCar3 = nil

-------------------------------------

function P_PlayerName1(name)
	WinnerName1 = name
end
addEvent("SaveName1",true)
addEventHandler("SaveName1",getRootElement(),P_PlayerName1)

function P_PlayerName2(name)
	WinnerName2 = name
end
addEvent("SaveName2",true)
addEventHandler("SaveName2",getRootElement(),P_PlayerName2)

function P_PlayerName3(name)
	WinnerName3 = name
end
addEvent("SaveName3",true)
addEventHandler("SaveName3",getRootElement(),P_PlayerName3)

-------------------------------------

function P_startPeds(Ped)
	setTimer(function() 
		local randomHyd = math.random (1,4)
		if randomHyd == 1 then
			setPedControlState(Ped,"special_control_left",true) 
			setPedControlState(Ped,"special_control_right",false)
			setPedControlState(Ped,"special_control_up",false)
			setPedControlState(Ped,"special_control_down",false)
		elseif randomHyd == 2 then
			setPedControlState(Ped,"special_control_right",true)
			setPedControlState(Ped,"special_control_left",false)
			setPedControlState(Ped,"special_control_up",false)
			setPedControlState(Ped,"special_control_down",false)
		elseif randomHyd == 3 then
			setPedControlState(Ped,"special_control_down",true)
			setPedControlState(Ped,"special_control_left",false) 
			setPedControlState(Ped,"special_control_right",false)
			setPedControlState(Ped,"special_control_up",false)
		elseif randomHyd == 4 then
			setPedControlState(Ped,"special_control_up",true)
			setPedControlState(Ped,"special_control_left",false) 
			setPedControlState(Ped,"special_control_right",false)
			setPedControlState(Ped,"special_control_down",false)
		end
	end,300,22)
	
	WinnerCar1 = getPedOccupiedVehicle(Ped)
	P_startfollow(Ped)
end
addEvent( "podiumDrivePed1", true )
addEventHandler( "podiumDrivePed1", getRootElement(), P_startPeds)

function P_startPed2(Ped)
	setPedControlState(Ped,"accelerate",true)
	setPedControlState(Ped,"brake_reverse",true)
	setTimer(function () 
		setPedControlState(Ped,"accelerate",false) 
		setPedControlState(Ped,"brake_reverse",false) 
		setPedControlState(Ped,"vehicle_left",false)
		setPedControlState(Ped,"vehicle_right",false) 
	end,7900,1)
	
	local randomHyd = 1
	setTimer(function() 
		if randomHyd == 2 then
			setPedControlState(Ped,"vehicle_left",true)
			setPedControlState(Ped,"vehicle_right",false)
			randomHyd = 1
		elseif randomHyd == 1 then
			setPedControlState(Ped,"vehicle_left",false)
			setPedControlState(Ped,"vehicle_right",true)
			randomHyd = 2
		end
	end,980,8)
	WinnerCar2 = getPedOccupiedVehicle(Ped)
end
addEvent( "podiumDrivePed2", true )
addEventHandler( "podiumDrivePed2", getRootElement(), P_startPed2)

function P_startPed3(Ped)
	setPedControlState(Ped,"special_control_down",true)
	WinnerCar3 = getPedOccupiedVehicle(Ped)
end
addEvent( "podiumDrivePed3", true )
addEventHandler( "podiumDrivePed3", getRootElement(), P_startPed3)

-------------------------------------

function P_startfollow()
	setTimer(function()	P_stopfollow() end, 7900, 1)
	local x, y, z = getElementPosition(WinnerCar1)
	setCameraMatrix(x+15, y, z+7, x, y, z)
	addEventHandler("onClientRender",getRootElement(),P_drawWinnerNames)
end

function P_stopfollow()
	removeEventHandler("onClientRender",getRootElement(),P_drawWinnerNames)
	----------------------
	WinnerName1 = nil
	WinnerCar1 = nil
	----------------------
	WinnerName2 = nil
	WinnerCar2 = nil
	----------------------
	WinnerName3 = nil
	WinnerCar3 = nil
end


-- NAMETAG WINNER
local x, y = guiGetScreenSize()
function P_drawWinnerNames()
	if WinnerCar1 ~= nil then
		local x,y,z = getElementPosition(WinnerCar1)
		local px,py,pz = x+5, y+10, z+2
		local distance = getDistanceBetweenPoints3D ( x,y,z,px,py,pz )
		if distance <= 150 then
			local sx,sy = getScreenFromWorldPosition ( x, y, z+0.55, 0.06 )
			if not sx then return end
			local scale = 1/(0.3 * (distance / 150))
			if WinnerName1 ~= nil then
				dxDrawText ("#CDD0D11st", sx-40, sy - 50, sx, sy - 50, tocolor(0, 0, 0, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
				dxDrawText ("#CDD0D11st", sx-40, sy - 50, sx, sy - 50, tocolor(255, 255, 255, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
				dxDrawText (WinnerName1, sx-20, sy - 50, sx, sy - 30, tocolor(0, 0, 0, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
				dxDrawText (WinnerName1, sx-20, sy - 50, sx, sy - 30, tocolor(255, 255, 255, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
			end
		end
	end
	if WinnerCar2 ~= nil then
		local x,y,z = getElementPosition(WinnerCar2)
		local px,py,pz = x+5, y+10, z+2
		local distance = getDistanceBetweenPoints3D ( x,y,z,px,py,pz )
		if distance <= 150 then
			local sx,sy = getScreenFromWorldPosition ( x, y, z+0.55, 0.06 )
			if not sx then return end
			local scale = 1/(0.3 * (distance / 150))
			if WinnerName2 ~= nil then
				dxDrawText ("#CDD0D12nd", sx-40, sy - 50, sx, sy - 50, tocolor(0, 0, 0, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
				dxDrawText ("#CDD0D12nd", sx-40, sy - 50, sx, sy - 50, tocolor(255, 255, 255, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)

				dxDrawText (WinnerName2, sx-20, sy - 50, sx, sy - 30, tocolor(0, 0, 0, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
				dxDrawText (WinnerName2, sx-20, sy - 50, sx, sy - 30, tocolor(255, 255, 255, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
			end
		end
	end
	if WinnerCar3 ~= nil then
		local x,y,z = getElementPosition(WinnerCar3)
		local px,py,pz = x+5, y+10, z+2
		local distance = getDistanceBetweenPoints3D ( x,y,z,px,py,pz )
		if distance <= 150 then
			local sx,sy = getScreenFromWorldPosition ( x, y, z+0.55, 0.06 )
			if not sx then return end
			local scale = 1/(0.3 * (distance / 150))
			if WinnerName3 ~= nil then
				dxDrawText ("#CDD0D13rd", sx-40, sy - 50, sx, sy - 50, tocolor(0, 0, 0, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
				dxDrawText ("#CDD0D13rd", sx-40, sy - 50, sx, sy - 50, tocolor(255, 255, 255, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
				dxDrawText (WinnerName3, sx-20, sy - 50, sx, sy - 30, tocolor(0, 0, 0, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
				dxDrawText (WinnerName3, sx-20, sy - 50, sx, sy - 30, tocolor(255, 255, 255, 255), math.min ( 0.4*(20/distance)*1.4,4), "default-bold", "center", "bottom", false, false, false, true)
			end
		end
	end
end