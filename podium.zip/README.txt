How to make this Podium Script working?

Step1:
Upload this Resource to your Server in [gameplay] folder

Step2:
Type "refresh" in Console (Works only as Admin)

Step3:
Open the destructionderby.lua file in [race]/race/modes/
 
Step4:
Find the "DestructionDerby:handleFinishActivePlayer(player)" function and put this Code at the last line of this function:

if #activePlayers == 2 then
	triggerClientEvent ( "SaveName3",getRootElement(),_getPlayerName(player))
end
if #activePlayers == 1 then
	triggerClientEvent ( "SaveName2",getRootElement(),_getPlayerName(player))
end
if #activePlayers == 0 then
	triggerClientEvent ( "SaveName",getRootElement(),_getPlayerName(player))
	triggerEvent("createPeds",getRootElement())
end


Whole function:

function DestructionDerby:handleFinishActivePlayer(player)
	-- Update ranking board for player being removed
	if not self.rankingBoard then
		self.rankingBoard = RankingBoard:create()
		self.rankingBoard:setDirection( 'up', getActivePlayerCount() )
	end
	local timePassed = self:getTimePassed()
	self.rankingBoard:add(player, timePassed)
	-- Do remove
	finishActivePlayer(player)
	-- Update ranking board if one player left

	if #activePlayers == 1 then
		self.rankingBoard:add(activePlayers[1], timePassed)
		triggerClientEvent ( "onPlayerWin", getRootElement(), activePlayers[1] )
	end
	--PODIUM SCRIPT
	if #activePlayers == 2 then
		triggerClientEvent ( "SaveName3",getRootElement(),_getPlayerName(player))
	end
	if #activePlayers == 1 then
		triggerClientEvent ( "SaveName2",getRootElement(),_getPlayerName(player))
	end
	if #activePlayers == 0 then
		triggerClientEvent ( "SaveName",getRootElement(),_getPlayerName(player))
		triggerEvent("createPeds",getRootElement())
	end
end

Note: This function is from MTA:SA Race Version (Not any edited Version of Race)

Step5:
Restart Race and it should work, if not then you did something wrong?
Sure you did nothing wrong? Try to get help from a friend or someone else...

HAVE FUN -- NO SUPPORT