------------------------------------------------------------------------------------------------------
-- * @Author		  Pun1sh3r
-- * @Copyright		  2011-2014 by Pun1sh3r
------------------------------------------------------------------------------------------------------

function startPodium() 
	outputDebugString("Podium resource successfully started.")
end
addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), startPodium)

-------------------------------------
--DM1 Podium 
local P_Ped1 = nil
local P_Vehicle1 = nil
-----
local P_Ped2 = nil
local P_Vehicle2 = nil
-----
local P_Ped3 = nil
local P_Vehicle3 = nil
-----
local P_BitchPed1 = nil
local P_BitchPed2 = nil
local P_BitchPed3 = nil
local P_BitchPed4 = nil
-----
local P_WankPed1 = nil

------------------------

function createPodium2()
	P_Ped1 = createPed (29, 2174.9, 1678.5, 25.2)
	P_Vehicle1 = createVehicle (536,2174.9, 1680.5, 20.2, 0, 0, 284)
	addVehicleUpgrade ( P_Vehicle1, 1087 )
	warpPedIntoVehicle ( P_Ped1, P_Vehicle1 )  
	------------------------------------------------------------------------------------------------
	P_Ped2 = createPed (22,2170.6, 1685.2, 25.2)
	P_Vehicle2 = createVehicle (536,2170.6, 1685.2, 20.2, 0, 0, 284)
	addVehicleUpgrade ( P_Vehicle2, 1087 )
	warpPedIntoVehicle ( P_Ped2, P_Vehicle2 )  
	------------------------------------------------------------------------------------------------
	P_Ped3 = createPed (10, 2170.2, 1675.4, 25.2)
	P_Vehicle3 = createVehicle (536, 2170.2, 1675.2, 20.2, 0, 0, 284)
	addVehicleUpgrade ( P_Vehicle3, 1087 )
	warpPedIntoVehicle ( P_Ped3, P_Vehicle3 ) 

	triggerClientEvent ("podiumDrivePed1", getRootElement(),P_Ped1)
	triggerClientEvent ("podiumDrivePed2", getRootElement(),P_Ped2)
	triggerClientEvent ("podiumDrivePed3", getRootElement(),P_Ped3)
	
	P_BitchPed1 = createPed(63, 2174.3, 1676.1, 20.4, 250.006)
	setPedAnimation(P_BitchPed1, "STRIP", "STR_Loop_B")
    P_BitchPed2 = createPed(87, 2173.5, 1681.8, 20.4, 244.006)
	setPedAnimation(P_BitchPed2, "STRIP", "STR_Loop_A")
    P_BitchPed3 = createPed(92, 2168.8, 1679.9, 20.4, 254.006)
	setPedAnimation(P_BitchPed3, "STRIP", "STR_Loop_C")
    P_BitchPed4 = createPed(138,2173.5, 1671.9, 20.4, 292.003)
	setPedAnimation(P_BitchPed4, "MISC", "bitchslap")
    P_WankPed1 = createPed(135, 2176.9, 1684.0, 20.4, 226.004)
	setPedAnimation(P_WankPed1, "PAULNMAC", "wank_loop")
	setTimer(function()	DM1_destroyPodium2() end, 8000, 1)
end
addEvent( "createPeds", true )
addEventHandler( "createPeds", getRootElement(), createPodium2 )

function DM1_destroyPodium2()
	destroyElement(P_Vehicle1)
	destroyElement(P_Ped1)
	P_Ped1 = nil
	P_Vehicle1 = nil
	---------------------------
	destroyElement(P_Vehicle2)
	destroyElement(P_Ped2)
	P_Ped2 = nil
	P_Vehicle2 = nil
	---------------------------
	destroyElement(P_Vehicle3)
	destroyElement(P_Ped3)
	P_Ped3 = nil
	P_Vehicle3 = nil
	---------------------------
	destroyElement(P_BitchPed1)
	destroyElement(P_BitchPed2)
	destroyElement(P_BitchPed3)
	destroyElement(P_BitchPed4)
	destroyElement(P_WankPed1)
	P_BitchPed1 = nil
	P_BitchPed2 = nil
	P_BitchPed3 = nil
	P_BitchPed4 = nil
	P_WankPed1 = nil
end
-------------------------------------