function setMoneyOnWasted ( )    
givePlayerMoney ( source, -50 )
        outputChatBox("You Lost [ 50 ]", source, 255,255,0, true)

end
addEventHandler ( "onPlayerWasted", getRootElement(), setMoneyOnWasted )


