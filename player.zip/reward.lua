function rewardOnWasted ( ammo, killer, killerweapon, bodypart )

	if ( killer ) and ( killer ~= source ) then
		givePlayerMoney ( killer, 500 )
		
		        outputChatBox("You won [ 500 ]", source, 255,255,0, true)

		
    end
end
addEventHandler ( "onPlayerWasted", getRootElement(), rewardOnWasted )