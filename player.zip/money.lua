function consoleMoneyOnSpawn ( )    
givePlayerMoney ( source, 0 )
end
addEventHandler ( "onPlayerSpawn", getRootElement(), consoleMoneyOnSpawn )


  