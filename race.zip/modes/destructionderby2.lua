﻿addEvent("onWins", true)
function drawNexMapString(player)
local x, y = guiGetScreenSize()
winner = dxText:create("#00FF00Winner: #ECECEC" ..getPlayerNametagText(player).."", x / 2, y / 2 - 10 + 75 - 41, false, "bankgothic", 1.5, "center")
nextmap = dxText:create( "#ECECECNextMap start after:", x / 2, y / 2 - 10 + 75 + 11, false, "bankgothic", 1, "center")
winner:type('stroke', 1, 0, 0, 0, 255)
nextmap:type('stroke', 1, 0, 0, 0, 255)
local timerTime = 5
timer = dxText:create( tostring(timerTime), x / 2, y / 2 - 10 + 75 + 41, false, "bankgothic", 1, "center")
timer:type('stroke', 1, 0, 0, 0, 255)
setTimer(function()timerTime = timerTime - 1 timer:text(tostring(timerTime)) end, 1000, 4)
setTimer(function()winner:visible(false) nextmap:visible(false) timer:visible(false)end, 5500, 1)
end
addEventHandler("onWins", getRootElement(), drawNexMapString)