g_Root = getRootElement()
g_ResRoot = getResourceRootElement(getThisResource())
g_Me = getLocalPlayer()
g_ArmedVehicleIDs = table.create({ 425, 447, 520, 430, 464, 432 }, true)
g_WaterCraftIDs = table.create({ 539, 460, 417, 447, 472, 473, 493, 595, 484, 430, 453, 452, 446, 454 }, true)
g_ModelForPickupType = { nitro = 2221, repair = 2222, vehiclechange = 2223 }
g_HunterID = 425
local localPlayer = getLocalPlayer()
local root = getRootElement()
local resRoot = getResourceRootElement(getThisResource())
local screenWidth, screenHeight = guiGetScreenSize()

g_Checkpoints = {}
g_Pickups = {}
g_VisiblePickups = {}
g_Objects = {}
fontX = nil
sW, sH = guiGetScreenSize()

local imageX,imageY = 325,150
local scaleX,scaleY = screenWidth/1920,screenHeight/1200
local scaleX,scaleY = (scaleX*scaleY),(scaleX*scaleY)
local timeX,timeY = imageX*scaleX, imageY*scaleY
local timeFix = timeX/100

spectatorsPosition = {
    arrowL = screenHeight,
    arrowR = screenHeight
}

addEventHandler('onClientResourceStart', g_ResRoot,
    function()
        g_Players = getElementsByType('player')
        tosfont = guiCreateFont("edf/font.ttf",30*scaleX)
        fadeCamera(false,0.0)
        -- create GUI
        g_PickupStartTick = getTickCount()
        local fonts = relativeScale(screenHeight)
        fontX = dxGetFontHeight(fonts, 'bankgothic')
        g_dxGUI = {
            checkpoint = dxText:create('0/0', screenWidth - 15, screenHeight - 54, false, 'bankgothic', 0.7, 'right'),
            --timepassed = dxText:create('0:00:00', screenWidth/2+38, 23, false, 'bankgothic', 0.5, 'right'),
            mapdisplay = dxText:create('#ff5400Map: #ffffffNone', 2, screenHeight - fontX/2, false, 'default-bold', fonts*2, 'left'),
            nextmapdisplay = dxText:create('#ff5400Next Map: #ffffffNot set now...', 2, screenHeight - fontX*1.5, false, 'default-bold', fonts*2, 'left')
        }
       -- fps = dxText:create('#ffffff*#ff8c00FPS #ffffff45', 2, screenHeight - fontX*2.5, false, 'default-bold', fonts*2, 'left')
       -- spectators = dxText:create('#ffffff*#ff8c00Spectators: #ffffff0', 2, screenHeight - fontX*1.5, false, 'default-bold', fonts*2, 'left')
       -- fps:type('shadow', 1, 0, 0, 0, 175)
       -- spectators:type('shadow', 1, 0, 0, 0, 175)
       -- spectators:type('shadow', 1, 0, 0, 0, 175)
        g_dxGUI.checkpoint:type('stroke', 1, 0, 0, 0, 255)
        g_dxGUI.mapdisplay:type('shadow', 1, 0, 0, 0, 175)
        g_dxGUI.nextmapdisplay:type('shadow', 1, 0, 0, 0, 175)
        g_dxGUI.nextmapdisplay:visible(false)
        g_GUI = {
            timeleftbg = guiCreateStaticImage(screenWidth/2-165/2, 0, 165, 50, 'img/timeleft.png', false, nil),
            --timepassed = guiCreateStaticImage(screenWidth/2-150, 60, 150, 60, 'img/timepassed.png', false, nil),
            timeleft = guiCreateLabel(screenWidth/2-57, 24, 100, 30, 'default-bold-small', false),
            timepassed = guiCreateLabel(screenWidth/2+20, 24, 100, 30, 'default-bold-small', false),
            --healthbar = FancyProgress.create(320, 1000, 'img/progress_health_bg.png', -45, 90, 163, 30, 'img/progress_health.png', 51, 8, 108, 15),
            --clientTime = guiCreateLabel(screenWidth-(timeX*0.35), timeY*0.56, screenWidth/3.7, screenHeight/30, '', false, timeleftbg),
        }
        guiSetFont(g_GUI.timeleft, 'default-bold-small')
        guiSetFont(g_GUI.timepassed, 'default-bold-small')
        --guiSetFont(g_GUI.clientTime, tosfont)
        guiLabelSetHorizontalAlign(g_GUI.timeleft, 'left')
        guiLabelSetHorizontalAlign(g_GUI.timeleft, 'left')
        guiLabelSetHorizontalAlign(g_GUI.timepassed, 'left')
        guiSetAlpha(g_GUI.timeleftbg, 0)
        guiSetAlpha(g_GUI.timepassed, 0)
        --guiSetAlpha(g_GUI.clientTime, 0)
        guiSetAlpha(g_GUI.timeleft, 0)
        --hideGUIComponents('healthbar')
        RankingBoard.precreateLabels(10)
        -- set update handlers
        addEventHandler('onClientRender', g_Root, updateBars)
        g_WaterCheckTimer = setTimer(checkWater, 1000, 0)
        -- load pickup models and textures
        for name,id in pairs(g_ModelForPickupType) do
            engineImportTXD(engineLoadTXD('model/' .. name .. '.txd'), id)
            engineReplaceModel(engineLoadDFF('model/' .. name .. '.dff', id), id)
            -- Double draw distance for pickups
            engineSetModelLODDistance( id, 60 )
        end
        if isVersion101Compatible() then
            -- Dont clip vehicles (1.0.1 function)
            setCameraClip ( true, false )
        end
        -- Init presentation screens
        TravelScreen.init()
        TitleScreen.init()
        -- Show title screen now
        TitleScreen.show()
        setPedCanBeKnockedOffBike(g_Me, false)
    end
)


-------------------------------------------------------
-- Title screen - Shown when player first joins the game
-------------------------------------------------------
TitleScreen = {}
TitleScreen.startTime = 0

function TitleScreen.init()
    local screenWidth, screenHeight = guiGetScreenSize()
    local adjustY = math.clamp( -30, -15 + (-30- -15) * (screenHeight - 480)/(900 - 480), -15 );
    --g_GUI['titleImage'] = guiCreateStaticImage(screenWidth/2-256, screenHeight/2-256+adjustY, 512, 512, 'img/title.png', false)
end

function TitleScreen.show()
    showGUIComponents('titleImage'--[['titleText1','titleText2']])
    guiMoveToBack(g_GUI['titleImage'])
    TitleScreen.startTime = getTickCount()
    TitleScreen.bringForward = 0
    addEventHandler('onClientRender', g_Root, TitleScreen.update)
end

function TitleScreen.update()
    local secondsLeft = TitleScreen.getTicksRemaining() / 1000
    local alpha = math.min(1,math.max( secondsLeft ,0))
    guiSetAlpha(g_GUI['titleImage'], alpha)
    if alpha == 0 then
        hideGUIComponents('titleImage')
        removeEventHandler('onClientRender', g_Root, TitleScreen.update)
    end
end

function TitleScreen.getTicksRemaining()
    return math.max( 0, TitleScreen.startTime - TitleScreen.bringForward + 10000 - getTickCount() )
end

-- Start the fadeout as soon as possible
function TitleScreen.bringForwardFadeout(maxSkip)
    local ticksLeft = TitleScreen.getTicksRemaining()
    local bringForward = ticksLeft - 1000
    outputDebug( 'MISC', 'bringForward ' .. bringForward )
    if bringForward > 0 then
        TitleScreen.bringForward = math.min(TitleScreen.bringForward + bringForward,maxSkip)
        outputDebug( 'MISC', 'TitleScreen.bringForward ' .. TitleScreen.bringForward )
    end
end
-------------------------------------------------------


-- Travel screen - Message for client feedback when loading maps
-------------------------------------------------------
local smoothers = {}
TravelScreen = {}
TravelScreen.startTime = 0

function TravelScreen.init()
    local screenWidth, screenHeight = guiGetScreenSize()
   -- g_GUI['travelImage']   = guiCreateStaticImage(screenWidth/2-256, screenHeight/2-20, 512, 256, 'img/travelling.png', false, nil)
    g_dxGUI['travelText1'] = dxText:create('Travelling to', screenWidth/2, screenHeight/2-130, false, 'default-bold', 1.3, 'center' )
    g_dxGUI['travelText2'] = dxText:create('', screenWidth/2, screenHeight/2-100, false, 'default-bold', 1.1, 'center' )
    g_dxGUI['travelText3'] = dxText:create('Author:', screenWidth/2, screenHeight/2-70, false, 'default-bold', 1.3, 'center' )
    g_dxGUI['travelText4'] = dxText:create('', screenWidth/2, screenHeight/2-40, false, 'default-bold', 1.1, 'center' )
	g_dxGUI['travelText1']:color(255,84,0)
    g_dxGUI['travelText2']:color(220,220,220)
	g_dxGUI['travelText3']:color(255,84,0)
	g_dxGUI['travelText4']:color(220,220,220)
	--DxMiscGui.travelling.on = true
	RenderMiscGUI()
  hideGUIComponents("travelText1", "travelText2", "travelText3", "travelText4")
end
function changeDXSmoother(vartext, target, speed, ldo)
  if not smoothers[vartext] then
    smoothers[vartext] = ""
  end
  if not ldo then
    smoothers[vartext] = ""
  end
  if smoothers[vartext] == target then
    return false
  end
  smoothers[vartext] = string.sub(target, 1, tonumber(string.len(smoothers[vartext])) + 1)
  g_dxGUI[vartext]:text(tostring(smoothers[vartext]))
  return setTimer(changeDXSmoother, speed, 1, vartext, target, speed, true)
end

function TravelScreen.show(mapName, authorName)
  TravelScreen.startTime = getTickCount()
  changeDXSmoother("travelText2", mapName, 50)
  changeDXSmoother("travelText4", authorName or "", 90)
  showGUIComponents("travelText1", "travelText2", "travelText3", "travelText4")
  DxMiscGui.travelling.on = true
  --guiMoveToBack(g_GUI['travelImage'])
 -- RenderMiscGUI()
end

function TravelScreen.hide()
  hideGUIComponents( "travelText1", "travelText2", "travelText3", "travelText4")
  DxMiscGui.travelling.on = false
  --RenderMiscGUI()
end

function TravelScreen.getTicksRemaining()
  return math.max(0, TravelScreen.startTime + 3000 - getTickCount())
end

DxMiscGui = {}
DxMiscGui.travelling = {
  on = false,
  step = 0,
  maxstep = 15
}
function RenderMiscGUI()
  local screenWidth, screenHeight = guiGetScreenSize()
  if DxMiscGui.travelling.on == true or DxMiscGui.travelling.step > 0 then
    --  Animation.createAndPlay( DxMiscGui.travelling.step, Animation.presets.guiFadeIn(800))
   -- Animation.createAndPlay( DxMiscGui.travelling.step, Animation.presets.guiPulse(1000))
    if DxMiscGui.travelling.on then
      if DxMiscGui.travelling.step < DxMiscGui.travelling.maxstep then
        DxMiscGui.travelling.step = DxMiscGui.travelling.step + 0.5
      end
    else
      DxMiscGui.travelling.step = DxMiscGui.travelling.step - 0.5
    end
    local ix, iy, width, height = screenWidth / 2 - 256, screenHeight / 2 - 20, 512, 256
    local tempelstep = math.ceil(DxMiscGui.travelling.step)
    for ia = 1, tempelstep do
      local ib = tempelstep + 1 - ia
      dxDrawImage(ix - ib * 5 + math.random(-10, 10), iy - ib * 5 + math.random(-10, 10), width + ib * 10, height + ib * 10, "img/travelling.png", 0, 0, 0, tocolor(205, 205, 205, 5 * (DxMiscGui.travelling.maxstep - ia)), false)
    end
    dxDrawImage(ix, iy, width, height, "img/travelling.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
  end
end
-------------------------------------------------------

-- Called from server
function notifyLoadingMap( mapName, authorName )
    fadeCamera( false, 0.0, 0,0,0 ) -- fadeout, instant, black
    TravelScreen.show( mapName, authorName )
	DxMiscGui.travelling.on = true
end


-- Called from server
function initRace(vehicle, checkpoints, objects, pickups, mapoptions, ranked, duration, gameoptions, mapinfo, playerInfo)
    outputDebug( 'MISC', 'initRace start' )
    unloadAll()
    
    g_Players = getElementsByType('player')
    g_MapOptions = mapoptions
    g_GameOptions = gameoptions
    g_MapInfo = mapinfo
    g_PlayerInfo = playerInfo
    triggerEvent('onClientMapStarting', g_Me, mapinfo )
    
    g_dxGUI.mapdisplay:text("#ff5400Map: #FFFFFF"..g_MapInfo.name)
    
    fadeCamera(true)
    showHUD(false)
    
    g_Vehicle = vehicle
    setVehicleDamageProof(g_Vehicle, true)
    OverrideClient.updateVars(g_Vehicle)
    
    --local x, y, z = getElementPosition(g_Vehicle)
    setCameraBehindVehicle(vehicle)
    --alignVehicleToGround(vehicle)
    updateVehicleWeapons()
    setCloudsEnabled(g_GameOptions.cloudsenable)
    setBlurLevel(g_GameOptions.blurlevel)
    g_dxGUI.mapdisplay:visible(g_GameOptions.showmapname)
    if engineSetAsynchronousLoading then
        engineSetAsynchronousLoading( g_GameOptions.asyncloading )
    end

    -- checkpoints
    g_Checkpoints = checkpoints
    
    -- pickups
    local object
    local pos
    local colshape
    for i,pickup in pairs(pickups) do
        pos = pickup.position
        object = createObject(g_ModelForPickupType[pickup.type], pos[1], pos[2], pos[3])
        setElementCollisionsEnabled(object, false)
        colshape = createColSphere(pos[1], pos[2], pos[3], 3.5)
        g_Pickups[colshape] = { object = object }
        for k,v in pairs(pickup) do
            g_Pickups[colshape][k] = v
        end
        g_Pickups[colshape].load = true
        if g_Pickups[colshape].type == 'vehiclechange' then
            g_Pickups[colshape].label = dxText:create(getVehicleNameFromModel(g_Pickups[colshape].vehicle), 0.5, 0.5)
            g_Pickups[colshape].label:color(255, 255, 255, 0)
            g_Pickups[colshape].label:type("shadow",2)
            g_Pickups[colshape].label:font("default-bold")
        end
    end
    
    -- objects
    g_Objects = {}
    local pos, rot
    for i,object in ipairs(objects) do
        pos = object.position
        rot = object.rotation
        g_Objects[i] = createObject(object.model, pos[1], pos[2], pos[3], rot[1], rot[2], rot[3])
    end

    if #g_Checkpoints > 0 then
        g_CurrentCheckpoint = 0
        showNextCheckpoint()
    end
    
    -- GUI
    guiSetText(g_GUI.timepassed, '0:00:00')
    guiSetText(g_GUI.timeleft, '0:00:00')
    --showGUIComponents('healthbar')
    guiLabelSetColor(g_GUI.timeleft, 255, 255, 255)
    Animation.createAndPlay(g_GUI.timepassed, Animation.presets.guiFadeIn(1000))
    Animation.createAndPlay(g_GUI.timeleftbg, Animation.presets.guiFadeIn(1000))
    Animation.createAndPlay(g_GUI.timeleft, Animation.presets.guiFadeIn(1000))
    --Animation.createAndPlay(g_GUI.clientTime, Animation.presets.guiFadeIn(1000))
    if #g_Checkpoints > 0 then
        showGUIComponents('checkpoint')
    else
        hideGUIComponents('checkpoint')
    end
    
    g_HurryDuration = g_GameOptions.hurrytime
    if duration then
        launchRace(duration)
    end

    fadeCamera( false, 0.0 )

    -- Editor start
    if isEditor() then
        editorInitRace()
        return
    end

    -- Min 3 seconds on travel message
    local delay = TravelScreen.getTicksRemaining()
    delay = math.max(50,delay)
    setTimer(TravelScreen.hide,delay,1)

    -- Delay readyness until after title
    TitleScreen.bringForwardFadeout(3000)
    delay = delay + math.max( 0, TitleScreen.getTicksRemaining() - 1500 )

    -- Do fadeup and then tell server client is ready
    setTimer(fadeCamera, delay + 750, 1, true, 10.0)
    setTimer(fadeCamera, delay + 1500, 1, true, 2.0)

    setTimer( function() triggerServerEvent('onNotifyPlayerReady', g_Me) end, delay + 3500, 1 )
    outputDebug( 'MISC', 'initRace end' )
    setTimer( function() setCameraBehindVehicle( g_Vehicle ) end, delay + 300, 1 )
    showPlayerInMessege = false
    showWinStreak = false
end

-- Called from the server when settings are changed
function updateOptions ( gameoptions, mapoptions )
    -- Update
    g_GameOptions = gameoptions
    g_MapOptions = mapoptions

    -- Apply
    updateVehicleWeapons()
    setCloudsEnabled(g_GameOptions.cloudsenable)
    setBlurLevel(g_GameOptions.blurlevel)
    g_dxGUI.mapdisplay:visible(g_GameOptions.showmapname)
    if engineSetAsynchronousLoading then
        engineSetAsynchronousLoading( g_GameOptions.asyncloading )
    end
end

function launchRace(duration)
    g_Players = getElementsByType('player')
    
    if type(duration) == 'number' then
        --showGUIComponents('timeleftbg', 'timeleft', 'timepassed')
        --guiSetSlowVisible( g_GUI.clienttime, true)
        --Animation.createAndPlay(g_GUI.clienttime, Animation.presets.guiFadeIn(1000))
        --Animation.createAndPlay(g_GUI.timepassed, Animation.presets.guiFadeIn(1000))
        --Animation.createAndPlay(g_GUI.timeleftbg, Animation.presets.guiFadeIn(1000))
        --Animation.createAndPlay(g_GUI.timeleft, Animation.presets.guiFadeIn(1000))
        guiLabelSetColor(g_GUI.timeleft, 255, 255, 255)
        g_Duration = duration
        addEventHandler('onClientRender', g_Root, updateTime)
    end
    
    setVehicleDamageProof(g_Vehicle, false)
    
    g_StartTick = getTickCount()
end


addEventHandler('onClientElementStreamIn', g_Root,
    function()
        local colshape = table.find(g_Pickups, 'object', source)
        if colshape then
            local pickup = g_Pickups[colshape]
            if pickup.label then
                pickup.label:color(255, 255, 255, 0)
                pickup.label:visible(false)
                pickup.labelInRange = false
            end
            g_VisiblePickups[colshape] = source
        end
    end
)

addEventHandler('onClientElementStreamOut', g_Root,
    function()
        local colshape = table.find(g_VisiblePickups, source)
        if colshape then
            local pickup = g_Pickups[colshape]
            if pickup.label then
                pickup.label:color(255, 255, 255, 0)
                pickup.label:visible(false)
                pickup.labelInRange = nil
            end
            g_VisiblePickups[colshape] = nil
        end
    end
)

function updatePickups()
    local angle = math.fmod((getTickCount() - g_PickupStartTick) * 360 / 2000, 360)
    local g_Pickups = g_Pickups
    local pickup, x, y, cX, cY, cZ, pickX, pickY, pickZ
    for colshape,elem in pairs(g_VisiblePickups) do
        pickup = g_Pickups[colshape]
        if pickup.load then
            setElementRotation(elem, 0, 0, angle)
            if pickup.label then
                cX, cY, cZ = getCameraMatrix()
                pickX, pickY, pickZ = unpack(pickup.position)
                x, y = getScreenFromWorldPosition(pickX, pickY, pickZ + 2.85, 0.08 )
                local distanceToPickup = getDistanceBetweenPoints3D(cX, cY, cZ, pickX, pickY, pickZ)
                if distanceToPickup > 80 then
                    pickup.labelInRange = false
                    pickup.label:visible(false)
                elseif x then
                    if distanceToPickup < 60 then
                        if isLineOfSightClear(cX, cY, cZ, pickX, pickY, pickZ, true, false, false, true, false) then
                            if not pickup.labelInRange then
                                if pickup.anim then
                                    pickup.anim:remove()
                                end
                                pickup.anim = Animation.createAndPlay(
                                    pickup.label,
                                    Animation.presets.dxTextFadeIn(500)
                                )
                                pickup.labelInRange = true
                                pickup.labelVisible = true
                            end
                            if not pickup.labelVisible then
                                pickup.label:color(255, 255, 255, 255)
                            end
                            pickup.label:visible(true)
                        else
                            pickup.label:color(255, 255, 255, 0)
                            pickup.labelVisible = false
                            pickup.label:visible(false)
                        end
                    else
                        if pickup.labelInRange then
                            if pickup.anim then
                                pickup.anim:remove()
                            end
                            pickup.anim = Animation.createAndPlay(
                                pickup.label,
                                Animation.presets.dxTextFadeOut(1000)
                            )
                            pickup.labelInRange = false
                            pickup.labelVisible = false
                            pickup.label:visible(true)
                        end
                    end
                    local scale = (60/distanceToPickup)*0.7
                    pickup.label:scale(scale)
                    pickup.label:position(x, y, false)
                else
                    pickup.label:color(255, 255, 255, 0)
                    pickup.labelVisible = false
                    pickup.label:visible(false)
                end
                if Spectate.fadedout then
                    pickup.label:visible(false) -- Hide pickup labels when screen is black
                end
            end
        else
            if pickup.label then
                pickup.label:visible(false)
                if pickup.labelInRange then
                    pickup.label:color(255, 255, 255, 0)
                    pickup.labelInRange = false
                end
            end
        end
    end
end
addEventHandler('onClientRender', g_Root, updatePickups)

addEventHandler('onClientColShapeHit', g_Root,
    function(elem)
        local pickup = g_Pickups[source]
        outputDebug( 'CHECKPOINT', 'onClientColShapeHit'
                        .. ' elem:' .. tostring(elem)
                        .. ' g_Vehicle:' .. tostring(g_Vehicle)
                        .. ' isVehicleBlown(g_Vehicle):' .. tostring(isVehicleBlown(g_Vehicle))
                        .. ' g_Me:' .. tostring(g_Me)
                        .. ' getElementHealth(g_Me):' .. tostring(getElementHealth(g_Me))
                        .. ' source:' .. tostring(source)
                        .. ' pickup:' .. tostring(pickup)
                        )
        if elem ~= g_Vehicle or not pickup or isVehicleBlown(g_Vehicle) or getElementHealth(g_Me) == 0 then
            return
        end
        if pickup.load then
            handleHitPickup(pickup)
        end
    end
)

function handleHitPickup(pickup)
    if pickup.type == 'vehiclechange' then
        if pickup.vehicle == getElementModel(g_Vehicle) then
            return
        end
        g_PrevVehicleHeight = getElementDistanceFromCentreOfMassToBaseOfModel(g_Vehicle)
    end
    triggerServerEvent('onPlayerPickUpRacePickupInternal', g_Me, pickup.id, pickup.respawn)
    playSoundFrontEnd(46)
end

function unloadPickup(pickupID)
    for colshape,pickup in pairs(g_Pickups) do
        if pickup.id == pickupID then
            pickup.load = false
            setElementAlpha(pickup.object, 0)
            return
        end
    end
end

function loadPickup(pickupID)
    for colshape,pickup in pairs(g_Pickups) do
        if pickup.id == pickupID then
            setElementAlpha(pickup.object, 255)
            pickup.load = true
            if isElementWithinColShape(g_Vehicle, colshape) then
                handleHitPickup(pickup)
            end
            return
        end
    end
end

function vehicleChanging( changez, newModel )
    if getElementModel(g_Vehicle) ~= newModel then
        outputConsole( "Vehicle change model mismatch (" .. tostring(getElementModel(g_Vehicle)) .. "/" .. tostring(newModel) .. ")" )
    end
    local newVehicleHeight = getElementDistanceFromCentreOfMassToBaseOfModel(g_Vehicle)
    local x, y, z = getElementPosition(g_Vehicle)
    if g_PrevVehicleHeight and newVehicleHeight > g_PrevVehicleHeight then
        z = z - g_PrevVehicleHeight + newVehicleHeight
    end
    if changez then
        z = z + 1
    end
    setElementPosition(g_Vehicle, x, y, z)
    g_PrevVehicleHeight = nil
    updateVehicleWeapons()
    checkVehicleIsHelicopter()
end

function updateVehicleWeapons()
if new ~= nil then
    if new == true then
        g_MapOptions.vehicleweapons = true
    else
        g_MapOptions.vehicleweapons = false
    end
end
    
    if g_Vehicle then
        local weapons = not g_ArmedVehicleIDs[getElementModel(g_Vehicle)] or g_MapOptions.vehicleweapons
        toggleControl('vehicle_fire', weapons)
        if getElementModel(g_Vehicle) == g_HunterID and not g_MapOptions.hunterminigun then
            weapons = false
        end
        toggleControl('vehicle_secondary_fire', weapons)
    end
end

function vehicleUnloading()
    g_Vehicle = nil
end

function updateBars()
    if g_Vehicle then
        --g_GUI.healthbar:setProgress(getElementHealth(g_Vehicle))
        local vx, vy, vz = getElementVelocity(g_Vehicle)
        --g_GUI.speedbar:setProgress(math.sqrt(vx*vx + vy*vy + vz*vz))
    end
end

function updateTime()
    local tick = getTickCount()
    local msPassed = tick - g_StartTick
    if not isPlayerFinished(g_Me) then
        --g_dxGUI.timepassed:text(msToTimeStr(msPassed))
        guiSetText(g_GUI.timepassed, msToTimeStr(msPassed))
    end
    local timeLeft = g_Duration - msPassed
    guiSetText(g_GUI.timeleft, msToTimeStr(timeLeft > 0 and timeLeft or 0))
    if g_HurryDuration and g_GUI.hurry == nil and timeLeft <= g_HurryDuration then
        startHurry()
    end
end

addEventHandler('onClientElementDataChange', g_Me,
    function(dataName)
        if dataName == 'race rank' and not Spectate.active then
            setRankDisplay( getElementData(g_Me, 'race rank') )
        end
    end,
    false
)

function setRankDisplay( rank )
    if not tonumber(rank) then
        --g_dxGUI.ranknum:text('')
        --g_dxGUI.ranksuffix:text('')
        return
    end
    --g_dxGUI.ranknum:text(tostring(rank))
    --g_dxGUI.ranksuffix:text( (rank < 10 or rank > 20) and ({ [1] = 'st', [2] = 'nd', [3] = 'rd' })[rank % 10] or 'th' )
end


addEventHandler('onClientElementDataChange', g_Root,
    function(dataName)
        if dataName == 'race.finished' then
            if isPlayerFinished(source) then
                Spectate.dropCamera( source, 2000 )
            end
        end
        if dataName == 'race.spectating' then
            if isPlayerSpectating(source) then
                Spectate.validateTarget( source )   -- No spectate at this player
            end
        end
    end
)


function checkWater()
    if g_Vehicle then
        if not g_WaterCraftIDs[getElementModel(g_Vehicle)] then
            local x, y, z = getElementPosition(g_Me)
            local waterZ = getWaterLevel(x, y, z)
            if waterZ and z < waterZ - 0.5 and not isPlayerRaceDead(g_Me) and not isPlayerFinished(g_Me) and g_MapOptions then
                if g_MapOptions.firewater then
                    blowVehicle ( g_Vehicle, true )
                else
                    setElementHealth(g_Me,0)
                    triggerServerEvent('onRequestKillPlayer',g_Me)
                end
            end
        end
        -- Check stalled vehicle
        if not getVehicleEngineState( g_Vehicle ) then
            setVehicleEngineState( g_Vehicle, true )
        end
        -- Check dead vehicle
        if getElementHealth( g_Vehicle ) == 0 and not isPlayerRaceDead(g_Me) and not isPlayerFinished(g_Me)then
            setElementHealth(g_Me,0)
            triggerServerEvent('onRequestKillPlayer',g_Me)
        end
    end
end

function showNextCheckpoint(bOtherPlayer)
    g_CurrentCheckpoint = g_CurrentCheckpoint + 1
    local i = g_CurrentCheckpoint
    g_dxGUI.checkpoint:text("#0fc0fc"..(i - 1) .. ' / ' .. #g_Checkpoints)
    if i > 1 then
        destroyCheckpoint(i-1)
    else
        createCheckpoint(1)
    end
    makeCheckpointCurrent(i,bOtherPlayer)
    if i < #g_Checkpoints then
        local curCheckpoint = g_Checkpoints[i]
        local nextCheckpoint = g_Checkpoints[i+1]
        local nextMarker = createCheckpoint(i+1)
        setMarkerTarget(curCheckpoint.marker, unpack(nextCheckpoint.position))
    end
    if not Spectate.active then
        setElementData(g_Me, 'race.checkpoint', i)
    end
end

-------------------------------------------------------------------------------
-- Show checkpoints and rank info that is relevant to the player being spectated
local prevWhich = nil
local cpValuePrev = nil
local rankValuePrev = nil

function updateSpectatingCheckpointsAndRank()
    local which = getWhichDataSourceToUse()

    -- Do nothing if we are keeping the last thing displayed
    if which == "keeplast" then
        return
    end

    local dataSourceChangedToLocal = which ~= prevWhich and which=="local"
    local dataSourceChangedFromLocal = which ~= prevWhich and prevWhich=="local"
    prevWhich = which

    if dataSourceChangedFromLocal or dataSourceChangedToLocal then
        cpValuePrev = nil
        rankValuePrev = nil
    end

    if Spectate.active or dataSourceChangedToLocal then
        local watchedPlayer = getWatchedPlayer()

        if g_CurrentCheckpoint and g_Checkpoints and #g_Checkpoints > 0 then
            local cpValue = getElementData(watchedPlayer, 'race.checkpoint') or 0
            if cpValue > 0 and cpValue <= #g_Checkpoints then
                if cpValue ~= cpValuePrev then
                    cpValuePrev = cpValue
                    setCurrentCheckpoint( cpValue, Spectate.active and watchedPlayer ~= g_Me )
                end
            end
        end

        local rankValue = getElementData(watchedPlayer, 'race rank') or 0
        if rankValue ~= rankValuePrev then
            rankValuePrev = rankValue
            setRankDisplay( rankValue ) 
        end
    end
end

-- "local"          If not spectating
-- "spectarget"     If spectating valid target
-- "keeplast"       If spectating nil target and dropcam
-- "local"          If spectating nil target and no dropcam
function getWhichDataSourceToUse()
    if not Spectate.active          then    return "local"          end
    if Spectate.target              then    return "spectarget"     end
    if Spectate.hasDroppedCamera()  then    return "keeplast"       end
    return "local"
end

function getWatchedPlayer()
    if not Spectate.active          then    return g_Me             end
    if Spectate.target              then    return Spectate.target  end
    if Spectate.hasDroppedCamera()  then    return nil              end
    return g_Me
end
-------------------------------------------------------------------------------

function checkpointReached(elem)
    outputDebug( 'CP', 'checkpointReached'
                    .. ' ' .. tostring(g_CurrentCheckpoint)
                    .. ' elem:' .. tostring(elem)
                    .. ' g_Vehicle:' .. tostring(g_Vehicle)
                    .. ' isVehicleBlown(g_Vehicle):' .. tostring(isVehicleBlown(g_Vehicle))
                    .. ' g_Me:' .. tostring(g_Me)
                    .. ' getElementHealth(g_Me):' .. tostring(getElementHealth(g_Me))
                    )
    if elem ~= g_Vehicle or isVehicleBlown(g_Vehicle) or getElementHealth(g_Me) == 0 or Spectate.active then
        return
    end
    
    if g_Checkpoints[g_CurrentCheckpoint].vehicle then
        g_PrevVehicleHeight = getElementDistanceFromCentreOfMassToBaseOfModel(g_Vehicle)
    end
    triggerServerEvent('onPlayerReachCheckpointInternal', g_Me, g_CurrentCheckpoint)
    playSoundFrontEnd(43)
    if g_CurrentCheckpoint < #g_Checkpoints then
        showNextCheckpoint()
    else
        g_dxGUI.checkpoint:text("#ff8c00"..#g_Checkpoints .. ' / ' .. #g_Checkpoints)
        local rc = getRadioChannel()
        setRadioChannel(0)
        addEventHandler("onClientPlayerRadioSwitch", g_Root, onChange)
        playSound("audio/mission_accomplished.mp3")
        setTimer(changeRadioStation, 8000, 1, rc)
        if g_GUI.hurry then
            Animation.createAndPlay(g_GUI.hurry, Animation.presets.guiFadeOut(500), destroyElement)
            g_GUI.hurry = false
        end
        destroyCheckpoint(#g_Checkpoints)
        triggerEvent('onClientPlayerFinish', g_Me)
        toggleAllControls(false, true, false)
    end
end

function onChange()
    cancelEvent()
end

function changeRadioStation(rc)
    removeEventHandler("onClientPlayerRadioSwitch", g_Root, onChange)
    setRadioChannel(tonumber(rc))
end

function startHurry()
    if not isPlayerFinished(g_Me) then
        local screenWidth, screenHeight = guiGetScreenSize()
        local w, h = resAdjust(370), resAdjust(112)
        g_GUI.hurry = guiCreateStaticImage(screenWidth/2 - w/2, screenHeight - h - 40, w, h, 'img/hurry.png', false, nil)
        guiSetAlpha(g_GUI.hurry, 0)
        Animation.createAndPlay(g_GUI.hurry, Animation.presets.guiFadeIn(800))
        Animation.createAndPlay(g_GUI.hurry, Animation.presets.guiPulse(1000))
    end
    guiLabelSetColor(g_GUI.timeleft, 255, 0, 0)
end

function setTimeLeft(timeLeft)
    g_Duration = (getTickCount() - g_StartTick) + timeLeft
end

-----------------------------------------------------------------------
-- Spectate
-----------------------------------------------------------------------
Spectate = {}
Spectate.active = false
Spectate.target = nil
Spectate.blockUntilTimes = {}
Spectate.savePos = false
Spectate.manual = false
Spectate.droppedCameraTimer = Timer:create()
Spectate.tickTimer = Timer:create()
Spectate.fadedout = true
Spectate.blockManual = false
Spectate.blockManualTimer = nil


-- Request to switch on
function Spectate.start(type)
    outputDebug( 'SPECTATE', 'Spectate.start '..type )
    assert(type=='manual' or type=='auto', "Spectate.start : type == auto or manual")
    Spectate.blockManual = false
    if type == 'manual' then
        if Spectate.active then
            return                  -- Ignore if manual request and already on
        end
        Spectate.savePos = true -- Savepos and start if manual request and was off
    elseif type == 'auto' then
        Spectate.savePos = false    -- Clear restore pos if an auto spectate is requested
    end
    if not Spectate.active then
        Spectate._start()           -- Switch on here, if was off
    end
end


-- Request to switch off
function Spectate.stop(type)
    outputDebug( 'SPECTATE', 'Spectate.stop '..type )
    assert(type=='manual' or type=='auto', "Spectate.stop : type == auto or manual")
    if type == 'auto' then
        Spectate.savePos = false    -- Clear restore pos if an auto spectate is requested
    end
    if Spectate.active then
        Spectate._stop()            -- Switch off here, if was on
    end
end


function Spectate._start()
    outputDebug( 'SPECTATE', 'Spectate._start ' )
    triggerServerEvent('onClientNotifySpectate', g_Me, true )
    assert(not Spectate.active, "Spectate._start - not Spectate.active")
    local screenWidth, screenHeight = guiGetScreenSize()
    --g_GUI.specprev = guiCreateStaticImage(screenWidth/2 - 100 - 58, screenHeight - 123, 58, 82, 'img/specprev.png', false, nil)
    --g_GUI.specprevhi = guiCreateStaticImage(screenWidth/2 - 100 - 58, screenHeight - 123, 58, 82, 'img/specprev_hi.png', false, nil)
    --g_GUI.specnext = guiCreateStaticImage(screenWidth/2 + 100, screenHeight - 123, 58, 82, 'img/specnext.png', false, nil)
    --g_GUI.specnexthi = guiCreateStaticImage(screenWidth/2 + 100, screenHeight - 123, 58, 82, 'img/specnext_hi.png', false, nil)
    --g_GUI.speclabel = guiCreateLabel(screenWidth/2 - 100, screenHeight - 100, 200, 70, '', false)
    Spectate.updateGuiFadedOut()
    --guiLabelSetHorizontalAlign(g_GUI.speclabel, 'center')
    --addEventHandler("onClientRender",getRootElement(),dxSpectator)
    --hideGUIComponents('specprevhi', 'specnexthi')
    if Spectate.savePos then
        savePosition()
    end
    Spectate.setTarget( Spectate.findNewTarget(g_Me,1) )
    bindKey('arrow_l', 'down', Spectate.previous)
    bindKey('arrow_r', 'down', Spectate.next)
    MovePlayerAway.start()
    Spectate.setTarget( Spectate.target )
    Spectate.validateTarget(Spectate.target)
    Spectate.tickTimer:setTimer( Spectate.tick, 500, 0 )
end

-- Stop spectating. Will restore position if Spectate.savePos is set
function Spectate._stop()
    Spectate.cancelDropCamera()
    Spectate.tickTimer:killTimer()
    triggerServerEvent('onClientNotifySpectate', g_Me, false )
    outputDebug( 'SPECTATE', 'Spectate._stop ' )
    assert(Spectate.active, "Spectate._stop - Spectate.active")
    for i,name in ipairs({--[['specprev', 'specprevhi', 'specnext', 'specnexthi','speclabel']]}) do
        if g_GUI[name] then
            destroyElement(g_GUI[name])
            g_GUI[name] = nil
        end
    end
    unbindKey('arrow_l', 'down', Spectate.previous)
    unbindKey('arrow_r', 'down', Spectate.next)
    MovePlayerAway.stop()
    setCameraTarget(g_Me)
    Spectate.target = nil
    Spectate.active = false
    setElementData(getLocalPlayer(), 'spectates', nil)
    removeEventHandler("onClientRender",getRootElement(),dxSpectator)
    if Spectate.savePos then
        Spectate.savePos = false
        restorePosition()
    end
end

function Spectate.previous(bGUIFeedback)
    Spectate.setTarget( Spectate.findNewTarget(Spectate.target,-1) )
    if bGUIFeedback then
        --setGUIComponentsVisible({ specprev = false, specprevhi = true })
        --setTimer(setGUIComponentsVisible, 100, 1, { specprevhi = false, specprev = true })
    end
end

function Spectate.next(bGUIFeedback)
    Spectate.setTarget( Spectate.findNewTarget(Spectate.target,1) )
    if bGUIFeedback then
        setGUIComponentsVisible({ specnext = false, specnexthi = true })
        setTimer(setGUIComponentsVisible, 100, 1, { specnexthi = false, specnext = true })
    end
end


function animateSpect(index)
    local types = index
    if types == "Close" then
        setTimer(
            function()
                addEventHandler("onClientRender",getRootElement(),animateDownSpects)
            end,
            100,1)
    else
        
    end
end


local dxSpec = "Nobody"

function dxSpectator()
    local posX = (sW/2)-(dxGetTextWidth(string.gsub(dxSpec,"#%x%x%x%x%x%x",""),1.5,"default-bold")/2)
    dxDrawColoredLabel(dxSpec,posX,screenHeight-150,sW,sH, tocolor(255,255,255,255),{255,255,255,255}, 1.5, "default-bold")
end

---------------------------------------------
-- Step along to the next player to spectate
local playersRankSorted = {}
local playersRankSortedTime = 0

function Spectate.findNewTarget(current,dir)

    -- Time to update sorted list?
    local bUpdateSortedList = ( getTickCount() - playersRankSortedTime > 1000 )

    -- Need to update sorted list because g_Players has changed size?
    bUpdateSortedList = bUpdateSortedList or ( #playersRankSorted ~= #g_Players )

    if not bUpdateSortedList then
        -- Check playersRankSorted contains the same elements as g_Players
        for _,item in ipairs(playersRankSorted) do
            if not table.find(g_Players, item.player) then
                bUpdateSortedList = true
                break
            end
        end
    end

    -- Update sorted list if required
    if bUpdateSortedList then
        -- Remake list
        playersRankSorted = {}
        for _,player in ipairs(g_Players) do
            local rank = tonumber(getElementData(player, 'race rank')) or 0
            table.insert( playersRankSorted, {player=player, rank=rank} )
        end
        -- Sort it by rank
        table.sort(playersRankSorted, function(a,b) return(a.rank > b.rank) end)

        playersRankSortedTime = getTickCount()
    end

    -- Find next player in list
    local pos = table.find(playersRankSorted, 'player', current) or 1
    for i=1,#playersRankSorted do
        pos = ((pos + dir - 1) % #playersRankSorted ) + 1
        if Spectate.isValidTarget(playersRankSorted[pos].player) then
            return playersRankSorted[pos].player
        end
    end
    return nil
end
---------------------------------------------

function Spectate.isValidTarget(player)
    if player == nil then
        return true
    end
    if player == g_Me or isPlayerFinished(player) or isPlayerRaceDead(player) or isPlayerSpectating(player) then
        return false
    end
    if ( Spectate.blockUntilTimes[player] or 0 ) > getTickCount() then
        return false
    end
    if not table.find(g_Players, player) or not isElement(player) then
        return false
    end
    local x,y,z = getElementPosition(player)
    if z > 20000 then
        return false
    end
    if x > -1 and x < 1 and y > -1 and y < 1 then
        return false
    end
    return true
end

-- If player is the current target, check to make sure is valid
function Spectate.validateTarget(player)
    if Spectate.active and player == Spectate.target then
        if not Spectate.isValidTarget(player) then
            Spectate.previous(false)
        end
    end
end

function Spectate.dropCamera( player, time )
    if Spectate.active and player == Spectate.target then
        if not Spectate.hasDroppedCamera() then
            setCameraMatrix( getCameraMatrix() )
            Spectate.target = nil
            Spectate.droppedCameraTimer:setTimer(Spectate.cancelDropCamera, time, 1, player )
        end
    end
end

function Spectate.hasDroppedCamera()
    return Spectate.droppedCameraTimer:isActive()
end

function Spectate.cancelDropCamera()
    if Spectate.hasDroppedCamera() then
        Spectate.droppedCameraTimer:killTimer()
        Spectate.tick()
    end
end


function Spectate.setTarget( player )
    if Spectate.hasDroppedCamera() then
        return
    end

    Spectate.active = true
    Spectate.target = player
    if Spectate.target then
        if Spectate.getCameraTargetPlayer() ~= Spectate.target then
            setCameraTarget(Spectate.target)
        end
        setElementData(getLocalPlayer(), 'spectates',Spectate.target)
        --guiSetText(g_GUI.speclabel, 'Currently spectating:\n' .. getPlayerName(Spectate.target))
        dxSpec = getPlayerNametagText(Spectate.target)
    else
        local x,y,z = getElementPosition(g_Me)
        x = x - ( x % 32 )
        y = y - ( y % 32 )
        z = getGroundPosition ( x, y, 5000 ) or 40
        setCameraTarget( g_Me )
        setCameraMatrix( x,y,z+10,x,y+50,z+60)
        setElementData(getLocalPlayer(), 'spectates',nil)
        --guiSetText(g_GUI.speclabel, 'Currently spectating:\n No one to spectate')
        dxSpec = "Nobody"
    end
    if Spectate.active and Spectate.savePos then
    end
end

function Spectate.blockAsTarget( player, ticks )
    Spectate.blockUntilTimes[player] = getTickCount() + ticks
    Spectate.validateTarget(player)
end

function Spectate.tick()
    if Spectate.target and Spectate.getCameraTargetPlayer() and Spectate.getCameraTargetPlayer() ~= Spectate.target then
        if Spectate.isValidTarget(Spectate.target) then
            setCameraTarget(Spectate.target)
            return
        end
    end
    if not Spectate.target or ( Spectate.getCameraTargetPlayer() and Spectate.getCameraTargetPlayer() ~= Spectate.target ) or not Spectate.isValidTarget(Spectate.target) then
        Spectate.previous(false)
    end
end

function Spectate.getCameraTargetPlayer()
    local element = getCameraTarget()
    if element and getElementType(element) == "vehicle" then
        element = getVehicleController(element)
    end
    return element
end


g_SavedPos = {}
function savePosition()
    g_SavedPos.x, g_SavedPos.y, g_SavedPos.z = getElementPosition(g_Me)
    g_SavedPos.rz = getPedRotation(g_Me)
    g_SavedPos.vx, g_SavedPos.vy, g_SavedPos.vz = getElementPosition(g_Vehicle)
    g_SavedPos.vrx, g_SavedPos.vry, g_SavedPos.vrz = getElementRotation(g_Vehicle)
end

function restorePosition()
    setElementPosition( g_Me, g_SavedPos.x, g_SavedPos.y, g_SavedPos.z )
    setPedRotation( g_Me, g_SavedPos.rz )
    setElementPosition( g_Vehicle, g_SavedPos.vx, g_SavedPos.vy, g_SavedPos.vz )
    setElementRotation( g_Vehicle, g_SavedPos.vrx, g_SavedPos.vry, g_SavedPos.vrz )
end


addEvent ( "onClientScreenFadedOut", true )
addEventHandler ( "onClientScreenFadedOut", g_Root,
    function()
        Spectate.fadedout = true
        Spectate.updateGuiFadedOut()
    end
)

addEvent ( "onClientScreenFadedIn", true )
addEventHandler ( "onClientScreenFadedIn", g_Root,
    function()
        Spectate.fadedout = false
        Spectate.updateGuiFadedOut()
    end
)

addEvent ( "onClientPreRender", true )
addEventHandler ( "onClientPreRender", g_Root,
    function()
        if isPlayerRaceDead( g_Me ) then
            setCameraMatrix( getCameraMatrix() )
        end
        updateSpectatingCheckpointsAndRank()
    end
)

function Spectate.updateGuiFadedOut()
    if g_GUI and g_GUI.specprev then
        if Spectate.fadedout then
            setGUIComponentsVisible({ --[[specprev = false, specnext = false, speclabel = false ]]})
        else
            setGUIComponentsVisible({ --[[specprev = true, specnext = true, speclabel = true]] })
        end
    end
end

-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- MovePlayerAway - Super hack - Fixes the spec cam problem
-----------------------------------------------------------------------
MovePlayerAway = {}
MovePlayerAway.timer = Timer:create()
MovePlayerAway.posX = 0
MovePlayerAway.posY = 0
MovePlayerAway.posZ = 0
MovePlayerAway.rotZ = 0
MovePlayerAway.health = 0

function MovePlayerAway.start()
    local element = g_Vehicle or getPedOccupiedVehicle(g_Me) or g_Me
    MovePlayerAway.posX, MovePlayerAway.posY, MovePlayerAway.posZ = getElementPosition(element)
    MovePlayerAway.posZ = 34567 + math.random(0,4000)
    MovePlayerAway.rotZ = 0
    MovePlayerAway.health = math.max(1,getElementHealth(element))
    setElementHealth( element, 2000 )
    setElementHealth( g_Me, 90 )
    MovePlayerAway.update(true)
    MovePlayerAway.timer:setTimer(MovePlayerAway.update,500,0)
    triggerServerEvent("onRequestMoveAwayBegin", g_Me)
end


function MovePlayerAway.update(nozcheck)
    -- Move our player far away
    local camTarget = getCameraTarget()
    if not getPedOccupiedVehicle(g_Me) then
        setElementPosition( g_Me, MovePlayerAway.posX-10, MovePlayerAway.posY-10, MovePlayerAway.posZ )
    end
    if getPedOccupiedVehicle(g_Me) then
        if not nozcheck then
            if camTarget then
                MovePlayerAway.posX, MovePlayerAway.posY = getElementPosition(camTarget)
                if getElementType(camTarget) ~= "vehicle" then
                    outputDebug( 'SPECTATE', 'camera target type:' .. getElementType(camTarget) )
                end
                if getElementType(camTarget) == 'ped' then
                    MovePlayerAway.rotZ = getPedRotation(camTarget)
                else
                    _,_, MovePlayerAway.rotZ = getElementRotation(camTarget)
                end
            end  
        end
        local vehicle = g_Vehicle
        if vehicle then
            fixVehicle( vehicle )
            setElementFrozen ( vehicle, true )
            setElementPosition( vehicle, MovePlayerAway.posX, MovePlayerAway.posY, MovePlayerAway.posZ )
            setElementVelocity( vehicle, 0,0,0 )
            setVehicleTurnVelocity( vehicle, 0,0,0 )
            setElementRotation ( vehicle, 0,0,MovePlayerAway.rotZ )
        end
    end
    setElementHealth( g_Me, 90 )

    if camTarget and camTarget ~= getCameraTarget() then
        setCameraTarget(camTarget)
    end
end

function MovePlayerAway.stop()
    triggerServerEvent("onRequestMoveAwayEnd", g_Me)
    if MovePlayerAway.timer:isActive() then
        MovePlayerAway.timer:killTimer()
        local vehicle = g_Vehicle
        if vehicle then
            setElementVelocity( vehicle, 0,0,0 )
            setVehicleTurnVelocity( vehicle, 0,0,0 )
            setElementFrozen ( vehicle, false )
            setVehicleDamageProof ( vehicle, false )
            setElementHealth ( vehicle, MovePlayerAway.health )
        end
        setElementVelocity( g_Me, 0,0,0 )
    end
end

-----------------------------------------------------------------------
-- Camera transition for our player's respawn
-----------------------------------------------------------------------
function remoteStopSpectateAndBlack()
    Spectate.stop('auto')
    fadeCamera(false,0.0, 0,0,0)            -- Instant black
end

function remoteSoonFadeIn( bNoCameraMove )
    setTimer(fadeCamera,250+500,1,true,1.0)     -- And up
    if not bNoCameraMove then
        setTimer( function() setCameraBehindVehicle( g_Vehicle ) end ,250+500-150,1 )
    end
    setTimer(checkVehicleIsHelicopter,250+500,1)
end
-----------------------------------------------------------------------

function raceTimeout()
    removeEventHandler('onClientRender', g_Root, updateTime)
    if g_CurrentCheckpoint then
        destroyCheckpoint(g_CurrentCheckpoint)
        destroyCheckpoint(g_CurrentCheckpoint + 1)
    end
    guiSetText(g_GUI.timeleft, msToTimeStr(0))
    if g_GUI.hurry then
        Animation.createAndPlay(g_GUI.hurry, Animation.presets.guiFadeOut(500), destroyElement)
        g_GUI.hurry = nil
    end
    triggerEvent("onClientPlayerOutOfTime", g_Me)
    toggleAllControls(false, true, false)
end

function unloadAll()
    triggerEvent('onClientMapStopping', g_Me)
    for i=1,#g_Checkpoints do
        destroyCheckpoint(i)
    end
    g_Checkpoints = {}
    g_CurrentCheckpoint = nil
    
    for colshape,pickup in pairs(g_Pickups) do
        destroyElement(colshape)
        if pickup.object then
            destroyElement(pickup.object)
        end
        if pickup.label then
            pickup.label:destroy()
        end
    end
    g_Pickups = {}
    g_VisiblePickups = {}
    
    table.each(g_Objects, destroyElement)
    g_Objects = {}
    
    setElementData(g_Me, 'race.checkpoint', nil)
    
    g_Vehicle = nil
    removeEventHandler('onClientRender', g_Root, updateTime)
    
    toggleAllControls(true)
    
    if g_GUI then
        --hideGUIComponents('healthbar')
        --guiSetSlowVisible( g_GUI.clienttime, false)
        Animation.createAndPlay(g_GUI.timepassed, Animation.presets.guiFadeOut(1000))
        Animation.createAndPlay(g_GUI.timeleftbg, Animation.presets.guiFadeOut(1000))
        Animation.createAndPlay(g_GUI.timeleft, Animation.presets.guiFadeOut(1000))
        --Animation.createAndPlay(g_GUI.clientTime, Animation.presets.guiFadeOut(1000))
        if g_GUI.hurry then
            Animation.createAndPlay(g_GUI.hurry, Animation.presets.guiFadeOut(500), destroyElement)
            g_GUI.hurry = nil
        end
    end
    TimerManager.destroyTimersFor("map")
    g_StartTick = nil
    g_HurryDuration = nil
    if Spectate.active then
        Spectate.stop('auto')
    end
end

function createCheckpoint(i)
    local checkpoint = g_Checkpoints[i]
    if checkpoint.marker then
        return
    end
    local pos = checkpoint.position
    local color = checkpoint.color or { 0, 0, 255 }
    checkpoint.marker = createMarker(pos[1], pos[2], pos[3], checkpoint.type or 'checkpoint', checkpoint.size, color[1], color[2], color[3])
    if (not checkpoint.type or checkpoint.type == 'checkpoint') and i == #g_Checkpoints then
        setMarkerIcon(checkpoint.marker, 'finish')
    end
    if checkpoint.type == 'ring' and i < #g_Checkpoints then
        setMarkerTarget(checkpoint.marker, unpack(g_Checkpoints[i+1].position))
    end
    checkpoint.blip = createBlip(pos[1], pos[2], pos[3], 0, isCurrent and 2 or 1, color[1], color[2], color[3])
    setBlipOrdering(checkpoint.blip, 1)
    return checkpoint.marker
end

function makeCheckpointCurrent(i,bOtherPlayer)
    local checkpoint = g_Checkpoints[i]
    local pos = checkpoint.position
    local color = checkpoint.color or { 255, 0, 0 }
    if not checkpoint.blip then
        checkpoint.blip = createBlip(pos[1], pos[2], pos[3], 0, 2, color[1], color[2], color[3])
        setBlipOrdering(checkpoint.blip, 1)
    else
        setBlipSize(checkpoint.blip, 2)
    end
    
    if not checkpoint.type or checkpoint.type == 'checkpoint' then
        checkpoint.colshape = createColCircle(pos[1], pos[2], checkpoint.size + 4)
    else
        checkpoint.colshape = createColSphere(pos[1], pos[2], pos[3], checkpoint.size + 4)
    end
    if not bOtherPlayer then
        addEventHandler('onClientColShapeHit', checkpoint.colshape, checkpointReached)
    end
end

function destroyCheckpoint(i)
    local checkpoint = g_Checkpoints[i]
    if checkpoint and checkpoint.marker then
        destroyElement(checkpoint.marker)
        checkpoint.marker = nil
        destroyElement(checkpoint.blip)
        checkpoint.blip = nil
        if checkpoint.colshape then
            destroyElement(checkpoint.colshape)
            checkpoint.colshape = nil
        end
    end
end

function setCurrentCheckpoint(i, bOtherPlayer)
    destroyCheckpoint(g_CurrentCheckpoint)
    destroyCheckpoint(g_CurrentCheckpoint + 1)
    createCheckpoint(i)
    g_CurrentCheckpoint = i - 1
    showNextCheckpoint(bOtherPlayer)
end

function isPlayerRaceDead(player)
    return not getElementHealth(player) or getElementHealth(player) < 1e-45 or isPlayerDead(player)
end

function isPlayerFinished(player)
    return getElementData(player, 'race.finished')
end

function isPlayerSpectating(player)
    return getElementData(player, 'race.spectating')
end

addEventHandler('onClientPlayerJoin', g_Root,
    function()
        table.insertUnique(g_Players, source)
    end
)

addEventHandler('onClientPlayerSpawn', g_Root,
    function()
        Spectate.blockAsTarget( source, 2000 )  -- No spectate at this player for 2 seconds
    end
)

addEventHandler('onClientPlayerWasted', g_Root,
    function()
        if not g_StartTick then
            return
        end
        local player = source
        local vehicle = getPedOccupiedVehicle(player)
        if player == g_Me then
            if #g_Players > 1 and (g_MapOptions.respawn == 'none' or g_MapOptions.respawntime >= 10000) then
                if Spectate.blockManualTimer and isTimer(Spectate.blockManualTimer) then
                    killTimer(Spectate.blockManualTimer)
                end
                TimerManager.createTimerFor("map"):setTimer(Spectate.start, 2000, 1, 'auto')
            end
        else
            Spectate.dropCamera( player, 1000 )
        end
    end
)

addEventHandler('onClientPlayerQuit', g_Root,
    function()
        table.removevalue(g_Players, source)
        Spectate.blockUntilTimes[source] = nil
        Spectate.validateTarget(source)     -- No spectate at this player
    end
)

addEventHandler('onClientResourceStop', g_ResRoot,
    function()
        unloadAll()
        removeEventHandler('onClientRender', g_Root, updateBars)
        killTimer(g_WaterCheckTimer)
        showHUD(true)
        setPedCanBeKnockedOffBike(g_Me, true)
    end
)

------------------------
-- Make vehicle upright

function directionToRotation2D( x, y )
    return rem( math.atan2( y, x ) * (360/6.28) - 90, 360 )
end

function alignVehicleWithUp()
    local vehicle = g_Vehicle
    if not vehicle then return end

    local matrix = getElementMatrix( vehicle )
    local Right = Vector3D:new( matrix[1][1], matrix[1][2], matrix[1][3] )
    local Fwd   = Vector3D:new( matrix[2][1], matrix[2][2], matrix[2][3] )
    local Up    = Vector3D:new( matrix[3][1], matrix[3][2], matrix[3][3] )

    local Velocity = Vector3D:new( getElementVelocity( vehicle ) )
    local rz

    if Velocity:Length() > 0.05 and Up.z < 0.001 then
        -- If velocity is valid, and we are upside down, use it to determine rotation
        rz = directionToRotation2D( Velocity.x, Velocity.y )
    else
        -- Otherwise use facing direction to determine rotation
        rz = directionToRotation2D( Fwd.x, Fwd.y )
    end

    setElementRotation( vehicle, 0, 0, rz )
end


------------------------
-- Script integrity test

setTimer(
    function ()
        if g_Vehicle and not isElement(g_Vehicle) then
            outputChatBox( "Race integrity test fail (client): Your vehicle has been destroyed. Please panic." )
        end
    end,
    1000,0
)

---------------------------------------------------------------------------
--
-- Commands and binds
--
--
--
---------------------------------------------------------------------------


function kill()
    if Spectate.active then
        if Spectate.savePos then
            triggerServerEvent('onClientRequestSpectate', g_Me, false )
        end
    else
        Spectate.blockManual = true
        triggerServerEvent('onRequestKillPlayer', g_Me)
        Spectate.blockManualTimer = setTimer(function() Spectate.blockManual = false end, 3000, 1)
    end
end
addCommandHandler('kill',kill)
addCommandHandler('Commit suicide',kill)
bindKey ( next(getBoundKeys"enter_exit"), "down", "Commit suicide" )


function spectate()
    if Spectate.active then
        if Spectate.savePos then
            triggerServerEvent('onClientRequestSpectate', g_Me, false )
        end
    else
        if not Spectate.blockManual then
            triggerServerEvent('onClientRequestSpectate', g_Me, true )
        end
    end
end
addCommandHandler('spectate',spectate)
addCommandHandler('Toggle spectator',spectate)
bindKey("b","down","Toggle spectator")

function setPipeDebug(bOn)
    g_bPipeDebug = bOn
    outputConsole( 'bPipeDebug set to ' .. tostring(g_bPipeDebug) )
end


function relativeScale(sH)
    local rs = (sH*0.55)/1080
    if rs <= 0.5 then
        rs = 0.5
    elseif rs > 0.5 and rs < 0.7 then
        rs = 1.25/2
    else
        rs = 1.25/2
    end
    return rs
end

local fpsEnabled = true
function fps()
    if not fpsEnabled then
       -- fps:visible(true)
       -- fpsEnabled = true
    else
      --  fpsEnabled = false
      --  fps:visible(false)
    end
end
addCommandHandler("fps", fps, false, false)

local specs = true
function spec()
    if not specs then
       -- spectators:visible(true)
      --  specs = true
    else
      --  specs = false
      -- spectators:visible(false)
    end
end
addCommandHandler("spec", spec, false, false)


setTimer(
function()
    --fps
    local fpstext --= tostring("#ffffff*#ff8c00FPS: #ffffff"..( getElementData(getLocalPlayer(), 'fps') or 0 ))
   -- fps:text(fpstext)   
    --Specs
    local snr = 0
    for k, v in ipairs(getElementsByType("player")) do
        local label = addTeamColor(v)
        if getElementData(v, 'spectates') == getLocalPlayer() then
            snr = snr + 1
            if posLabel[label] ~= nil then
                setElementData(posLabel[label], "spectated", true)
                setElementData(playerLabel[label], "spectated", true)
            end
        else
            if posLabel[label] ~= nil then
                setElementData(posLabel[label], "spectated", false)
                setElementData(playerLabel[label], "spectated", false)
            end
        end
    end
   -- stext = tostring("#ffffff*#ff8c00Spectators: #ffffff"..snr)
    --spectators:text(stext)
end
,1000,0)


function nextMapSet(confirm, mapname)
    if confirm == true then
        g_dxGUI.mapdisplay:position(2, sH - fontX/2, false)
        --fps:position(2, sH-fontX*3.5, false)
        --spectators:position(2, sH-fontX*2.5, false)
        g_dxGUI.nextmapdisplay:visible(true)
        g_dxGUI.nextmapdisplay:text("#ff5400Next Map: #ffffff" ..mapname)
    else
        g_dxGUI.nextmapdisplay:visible(false)
        g_dxGUI.mapdisplay:position(2, sH - fontX/2, false)
        --fps:position(2, sH-fontX*2.5, false)
        --spectators:position(2, sH-fontX*1.5, false)
    end
end
addEvent("onNextMap", true)
addEventHandler("onNextMap", getRootElement(), nextMapSet)

--FPS
local root = getRootElement()
local player = getLocalPlayer()
local counter = 0
local starttick
local currenttick
addEventHandler("onClientRender",root,
    function()
        if not starttick then
            starttick = getTickCount()
        end
        counter = counter + 1
        currenttick = getTickCount()
        if currenttick - starttick >= 1000 then
            setElementData(player,'fps',counter)
            counter = 0
            starttick = false
        end
        local a,b = getServerTime()
        --guiSetText(g_GUI.clientTime,b)
    end
)

--EXTRA FUNCTION FOR SMOOTH GUI WINDOWS
local visibleElement
local visibleBool
function guiSetSlowVisible(element, bool)
    if (element) then
        local bool = bool or false
        if (isElement(element)) then
            if (bool == false) then
                local visible = guiGetVisible(element)
                    if (visible) then
                        visibleBool = bool
                        visibleElement = element
                        addEventHandler("onClientRender", root, guiSmoothVisible)
                        return true
                    else
                        outputDebugString ( "guiSetSlowVisible - Element already invisible", 0, 112, 112, 112 )
                        return false
                    end
            elseif (bool == true) then
                local visible = guiGetVisible(element)
                    if not (visible) then
                        guiSetVisible(element, true)
                        guiSetAlpha(element, 0)
                        visibleBool = bool
                        visibleElement = element
                        addEventHandler("onClientRender", root, guiSmoothVisible)
                        return true
                    else
                        outputDebugString ( "guiSetSlowVisible - Element already invisible", 0, 112, 112, 112 )
                        return false
                    end             
            else
                outputDebugString ( "guiSetSlowVisible - Bad element pointer", 0, 112, 112, 112 )
                return false
            end
        else
            outputDebugString ( "guiSetSlowVisible - Given element pointer is not an element", 0, 112, 112, 112 )
            return false        
        end
    else
        outputDebugString ( "guiSetSlowVisible - Missing argument", 0, 112, 112, 112 )
        return false
    end
end

local smoothInvisible = 1
local smoothVisible = 0
function guiSmoothVisible()
    local bool = visibleBool
    local element = visibleElement
    if (bool == true) then
        if not (smoothVisible >= 1) then
            local test1 = guiSetAlpha(element, smoothVisible)
            smoothVisible = smoothVisible + 0.01
        else
            smoothVisible = 0
            removeEventHandler("onClientRender", root, guiSmoothVisible)
        end
    else
        if not (smoothInvisible <= 0) then
            local test2 = guiSetAlpha(element, smoothInvisible)
            smoothInvisible = smoothInvisible -0.01
        else
            guiSetVisible(element, false)
            smoothVisible = 1
            removeEventHandler("onClientRender", root, guiSmoothVisible)
        end     
    end
end



local sw,sh = guiGetScreenSize()
local winstreak = nil
local PlayerName = "N/A"
local showPlayerInMessege = false
local WinStreak = false

function setWinStreakOnMessege(WinStreak)
    if WinStreak then
        showWinStreak = true
        dxWinS = tonumber(WinStreak)
    end
end

function setPlayerNameOnWinMessege(player)
    PlayerName = addTeamColor(player)
    showPlayerInMessege = true
end
addEvent( "sentMessegeDataToClient", true )
addEventHandler( "sentMessegeDataToClient", getRootElement(), setPlayerNameOnWinMessege )


function addTeamColor(player)
    local playerTeam = getPlayerTeam ( player ) 
    if ( playerTeam ) then
        local r,g,b = getTeamColor ( playerTeam )
        local n1 = toHex(r)
        local n2 = toHex(g)
        local n3 = toHex(b)
        if r <= 16 then n1 = "0"..n1 end
        if g <= 16 then n2 = "0"..n2 end
        if b <= 16 then n3 = "0"..n3 end
        return "#"..n1..""..n2..""..n3..""..getPlayerNametagText(player)
    else
        return getPlayerNametagText(player)
    end
end

function showWinMessageF()
    if showPlayerInMessege then
        addEventHandler ( "onClientRender", getRootElement(), WinTextRendering )
        setTimer(function() removeEventHandler("onClientRender",getRootElement(), WinTextRendering) end, 5500,1)
    end
end
addEvent( "showWinMessage", true )
addEventHandler( "showWinMessage", getRootElement(), showWinMessageF )

function WinTextRendering() 
    local scaleFont = sh*0.005
    local fontH = dxGetFontHeight(scaleFont,"default-bold")
    --dxDrawColorTextLine("Winner:", 0, 0, sw+3, sh-(fontH*1.3)-3, tocolor(0,0,0,255), scaleFont/2.3, "default-bold", "center", "center")
    --dxDrawColorTextPuma("Winner:", 0, 0, sw, sh-(fontH*1.3), tocolor(255,255,255,Alpha), scaleFont/2.3, "default-bold", "center", "center")
    --dxDrawColorTextLine(""..string.gsub(PlayerName,"#%x%x%x%x%x%x","").."", 0, 0, sw+3, sh-3, tocolor(0,0,0,255), scaleFont, "default-bold", "center", "center")
    --dxDrawColorTextPuma(""..PlayerName.."", 0, 0, sw, sh, tocolor(255,255,255,Alpha), scaleFont, "default-bold", "center", "center")
    if showWinStreak then
    --dxDrawColorTextLine("Winstreak: "..dxWinS.."", 0, 0, sw+3, sh+(fontH*1.3)+3, tocolor(0,0,0,255), scaleFont/2.1, "default-bold", "center", "center")
    --dxDrawColorTextPuma("Winstreak: "..dxWinS.."", 0, 0, sw, sh+fontH*1.3, tocolor(255,255,255,Alpha), scaleFont/2.1, "default-bold", "center", "center")
    end
end


function toHex ( n )
    local hexnums = {"0","1","2","3","4","5","6","7",
                     "8","9","A","B","C","D","E","F"}
    local str,r = "",n%16
    if n-r == 0 then str = hexnums[r+1]
    else str = toHex((n-r)/16)..hexnums[r+1] end
    return str
end
------------------------------------------------------------------------------------------------------------

function getPointFromDistanceRotation(x, y, dist, angle)
 
    local a = math.rad(90 - angle);
 
    local dx = math.cos(a) * dist;
    local dy = math.sin(a) * dist;
 
    return x+dx, y+dy;
 
end

function dxDrawColorTextLine(str, ax, ay, bx, by, color, scale, font, alignX, alignY)
    Texts = {}
    Texts = string.explode(str,"/newline/")
    for i=1,#Texts do
        dxDrawText(Texts[i], ax, ay+(dxGetFontHeight ( scale, font ))*(i-1), bx, by, color, scale, font, alignX, alignY)
    end
end

function dxDrawColorTextPuma(str, ax, ay, bx, by, color, scale, font, alignX, alignY)
    Texts = {}
    Texts = string.explode(str,"/newline/")
    for i=1,#Texts do
        dxDrawColorTextNext(Texts[i], ax, ay+(dxGetFontHeight ( scale, font ))*(i-1), bx, by, color, scale, font, alignX, alignY)
    end
end
function dxDrawColorTextNext(str, ax, ay, bx, by, color, scale, font, alignX, alignY)
  if alignX then
    if alignX == "center" then
      local w = dxGetTextWidth(str:gsub("#%x%x%x%x%x%x",""), scale, font)
      ax = ax + (bx-ax)/2 - w/2
    elseif alignX == "right" then
      local w = dxGetTextWidth(str:gsub("#%x%x%x%x%x%x",""), scale, font)
      ax = bx - w
    end
  end

  if alignY then
    if alignY == "center" then
      local h = dxGetFontHeight(scale, font)
      ay = ay + (by-ay)/2 - h/2
    elseif alignY == "bottom" then
      local h = dxGetFontHeight(scale, font)
      ay = by - h
    end
  end
 
  local pat = "(.-)#(%x%x%x%x%x%x)"
  local s, e, cap, col = str:find(pat, 1)
  local last = 1
  while s do
    if cap == "" and col then color = tocolor(tonumber("0x"..col:sub(1, 2)), tonumber("0x"..col:sub(3, 4)), tonumber("0x"..col:sub(5, 6)), Alpha) end
    if s ~= 1 or cap ~= "" then
      local w = dxGetTextWidth(cap, scale, font)
      dxDrawText(cap, ax, ay, ax + w, by, color, scale, font)
      ax = ax + w
      color = tocolor(tonumber("0x"..col:sub(1, 2)), tonumber("0x"..col:sub(3, 4)), tonumber("0x"..col:sub(5, 6)), Alpha)
    end
    last = e + 1
    s, e, cap, col = str:find(pat, last)
  end
  if last <= #str then
    cap = str:sub(last)
    local w = dxGetTextWidth(cap, scale, font)
    dxDrawText(cap, ax, ay, ax + w, by, color, scale, font)
  end
end
function string.explode(self, separator)
    Check("string.explode", "string", self, "ensemble", "string", separator, "separator")
 
    if (#self == 0) then return {} end
    if (#separator == 0) then return { self } end
 
    return loadstring("return {\""..self:gsub(separator, "\",\"").."\"}")()
end
function Check(funcname, ...)
    local arg = {...}
 
    if (type(funcname) ~= "string") then
        error("Argument type mismatch at 'Check' ('funcname'). Expected 'string', got '"..type(funcname).."'.", 2)
    end
    if (#arg % 3 > 0) then
        error("Argument number mismatch at 'Check'. Expected #arg % 3 to be 0, but it is "..(#arg % 3)..".", 2)
    end
 
    for i=1, #arg-2, 3 do
        if (type(arg[i]) ~= "string" and type(arg[i]) ~= "table") then
            error("Argument type mismatch at 'Check' (arg #"..i.."). Expected 'string' or 'table', got '"..type(arg[i]).."'.", 2)
        elseif (type(arg[i+2]) ~= "string") then
            error("Argument type mismatch at 'Check' (arg #"..(i+2).."). Expected 'string', got '"..type(arg[i+2]).."'.", 2)
        end
 
        if (type(arg[i]) == "table") then
            local aType = type(arg[i+1])
            for _, pType in next, arg[i] do
                if (aType == pType) then
                    aType = nil
                    break
                end
            end
            if (aType) then
                error("Argument type mismatch at '"..funcname.."' ('"..arg[i+2].."'). Expected '"..table.concat(arg[i], "' or '").."', got '"..aType.."'.", 3)
            end
        elseif (type(arg[i+1]) ~= arg[i]) then
            error("Argument type mismatch at '"..funcname.."' ('"..arg[i+2].."'). Expected '"..arg[i].."', got '"..type(arg[i+1]).."'.", 3)
        end
    end
end



function fade(current,target,step)
    local new = current

    local FPS = tonumber(getElementData(getLocalPlayer(),"fps"))
    if FPS < 30 then
        step = step * 1.7
    elseif FPS < 35 then
        step = step * 1.5
    elseif FPS < 40 then
        step = step * 1.3
    elseif FPS < 45 then
        step = step * 1.1
    end

    if (current < target) then
            new = current + step
        if (new > target) then
            new = target
        end
    elseif (current > target) then
            new = current - step
        if (new < target) then
            new = target
        end
    end
    return new
end


function getServerTime ()
    local time = getRealTime()
    local hours = time.hour
    if hours < 10 then
        hours = "0"..hours
    end
    local minutes = time.minute
    if minutes < 10 then
        minutes = "0"..minutes
    end
    local seconds = time.second
    if seconds < 10 then
        seconds = "0"..seconds
    end
    local year = time.year+1900
    local month = time.month+1
    local day = time.monthday
    local monthTable = {
    "january ",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september", 
    "october",
    "november",
    "december"}

    -- Return:  DATE, TIME
    return day.." "..monthTable[month].." "..year, hours..":"..minutes..":"..seconds
end



----------------
-- Draw Hunter
----------------

sx,sy = guiGetScreenSize()
font = "default-bold"

function hunterHundleInfo()
    removeEventHandler("onClientRender",getRootElement(),drawHunterInfoMessage)
    addEventHandler("onClientRender",getRootElement(),drawHunterInfoMessage)
    setTimer(stopHuntersInfo,5000,1)
    getTickInfoStart = getTickCount ()
    setWaterColor ( 0, 150, 255, 112 ) --water
    setTime( 0, 0 )
    setWeather(0)
    resetSkyGradient()
end
addEvent("onServerSendHunterMessage",true)
addEventHandler("onServerSendHunterMessage",getRootElement(),hunterHundleInfo)


function stopHuntersInfo()
    removeEventHandler("onClientRender",getRootElement(),drawHunterInfoMessage)
end

function drawHunterInfoMessage()
    local getTickNow = getTickCount () - getTickInfoStart
    if getTickNow <= 1000 then
        alfa = getTickNow/1000
    elseif getTickNow >= 4000 then
        alfa = (5000-getTickNow)/1000
    else
        alfa = 1
    end
    alfa = alfa * alfa * alfa
    --dxDrawText("Hunter reached!",-1,-1,sx-1,sy-1,tocolor(0,0,0,alfa*200),(2.5*sx/1920)*alfa*1.6,font,"center","center",true)
    --dxDrawText("Hunter reached!",0,0,sx,sy,tocolor(15, 192, 252,alfa*255),(2.5*sx/1920)*alfa*1.6,font,"center","center",true)
end


function getVehicleSpeed()
    local sx, sy, sz = getElementVelocity(getPedOccupiedVehicle(localPlayer))
    local speed = math.sqrt((sx^2 + sy^2 + sz^2))
    return math.floor(speed * 161)
end


local loading = {
    size = {(scaleX*0.75)*1024,(scaleX*0.75)*64},
    progress = 0,
    anim = 0,
    mapName = ""
}

function resetLoadingStats(map_Name)
loading = {
    size = {(scaleX*0.75)*1024,(scaleX*0.75)*64},
    progress = 0,
    anim = 0,
    mapName = map_Name
}
end

function showTravelingDx()
    loading.anim = loading.anim+0.01
    loading.progress = loading.progress+0.013
    if loading.progress >= 1 then
        loading.progress = 1
    end
    if loading.anim >= 1 then
        loading.anim = 0
    end
    local scaleX = scaleX*0.75
    local loadInt = math.floor(loading.progress*100)
    dxDrawText("Loading next map...",(sW/2-(loading.size[1]/2))+((scaleX*0.5)*235)-2,sH/2.5-2,(sW/2-(loading.size[1]/2))+((scaleX*0.5)*235)+(scaleX*1024),sH/2.5+((scaleX*0.5)*235),tocolor(255,165,0,255),scaleX*5,"default-bold","center","center")
    --dxDrawText("Loading next map...",(sW/2-(loading.size[1]/2))+((scaleX*0.5)*235),sH/2.5,(sW/2-(loading.size[1]/2))+((scaleX*0.5)*235)+(scaleX*1024),sH/2.5+((scaleX*0.5)*235),tocolor(255,165,0,255),scaleX*5,"default-bold","center","center")
    dxDrawText(loading.mapName,(sW/2-(loading.size[1]/2))-2,sH/2-2,(sW/2-(loading.size[1]/2))+(scaleX*1024),sH/2,tocolor(0,0,0,255),scaleX*3,"default-bold","center","center")
    --dxDrawText(loading.mapName,(sW/2-(loading.size[1]/2)),sH/2,(sW/2-(loading.size[1]/2))+(scaleX*1024),sH/2,tocolor(255,255,255,255),scaleX*3,"default-bold","center","center")
    dxDrawImage(sW/2-(loading.size[1]/2),sH/2.5,(scaleX*0.5)*256,(scaleX*0.5)*256,"img/loading/circle.png",loading.anim*360,0,0,tocolor(255,255,255,255))
    --dxDrawImage(sW/2-(loading.size[1]/2),sH*0.55,scaleX*1024,scaleX*64,"img/loading/bg.png",0,0,0,tocolor(255,255,255,255))
    --dxDrawImage(sW/2-(loading.size[1]/2),sH*0.55,scaleX*1024,scaleX*64,"img/loading/bg.png",0,0,0,tocolor(255,255,255,255))
    --dxDrawImageSection(sW/2-(loading.size[1]/2),sH*0.55,loading.progress*(scaleX*1024),scaleX*64,1024,64,loading.progress*1024,64,"img/loading/bar.png")
    --if loadInt > 15 then
    -- dxDrawText(loadInt.."%",(sW/2-(loading.size[1]/2))+(loading.progress*(scaleX*1024))+2-(scaleX*160),sH*0.55+2,(sW/2-(loading.size[1]/2))+(loading.progress*(scaleX*1024)),sH*0.55+(64*scaleX),tocolor(0,0,0,255),scaleX*3,"default-bold","center","center")
    --dxDrawText(loadInt.."%",(sW/2-(loading.size[1]/2))+(loading.progress*(scaleX*1024))-(scaleX*160),sH*0.55,(sW/2-(loading.size[1]/2))+(loading.progress*(scaleX*1024)),sH*0.55+(64*scaleX),tocolor(255,255,255,255),scaleX*3,"default-bold","center","center")
    --end
    --dxDrawImage(sW/2-(loading.size[1]/2),sH*0.55,scaleX*1024,scaleX*64,"img/loading/border.png",0,0,0,tocolor(255,255,255,255))
    dxDrawText("Nerd Gamers",(sW/2-(loading.size[1]/2))-2,sH*0.6-2,(sW/2-(loading.size[1]/2))+(scaleX*1024),sH*0.6,tocolor(0,0,0,255),scaleX*3,"default-bold","center","center")
    --dxDrawText("Nerd Gamers",(sW/2-(loading.size[1]/2)),sH*0.6,(sW/2-(loading.size[1]/2))+(scaleX*1024),sH*0.6,tocolor(255,165,0,255),scaleX*3,"default-bold","center","center")
end


--loadingBar = {
    --sizeX = 1024*scaleX,
    --sizeY = 64*scaleX,
    --progress = 0
--}

--function drawLoadingBar()
    --loadingBar.progress = loadingBar.progress + 0.01
    --if loadingBar.progress >= 1 then
        --loadingBar.progress = 0
    --end
    --local fontScale = 3*scaleX
    --dxDrawRectangle((sx/2)-(loadingBar.sizeX/2)-2,(sy*0.75)-loadingBar.sizeY-2,loadingBar.sizeX+4,loadingBar.sizeY+4,tocolor(50,50,50,255),true)
    --dxDrawImageSection((sx/2)-(loadingBar.sizeX/2),(sy*0.75)-loadingBar.sizeY,loadingBar.sizeX,loadingBar.sizeY,loadingBar.sizeX*loadingBar.progress,64,loadingBar.sizeX,64,"img/bar.png",0,0,0,tocolor(255,255,255,255),true)
    --dxDrawText(math.floor(loadingBar.progress*100).."%",(sx/2)+(loadingBar.sizeX/2)-(loadingBar.sizeX/20)-dxGetTextWidth(math.floor(loadingBar.progress*100).."%",fontScale,"default-bold"),(sy*0.75)-loadingBar.sizeY,sx,(sy*0.75),tocolor(255,255,255,255),fontScale,"deafult-bold","left","center",false,false,true)
--end

--function showLoadingBar()
    --loadingBar.progress = 0
    --addEventHandler("onClientRender",getRootElement(),drawLoadingBar)
--end

--function removeLoadingBar()
    --removeEventHandler("onClientRender",getRootElement(),drawLoadingBar)
--end


fileDelete("race_client.lua")