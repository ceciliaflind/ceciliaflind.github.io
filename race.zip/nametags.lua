

nametag = {}
local healthp = {}
local nametags = {}
local g_screenX,g_screenY = guiGetScreenSize()
local bHideNametags = true
my = nil
local NAMETAG_SCALE = 0.23 --Overall adjustment of the nametag, use this to resize but constrain proportions
local NAMETAG_ALPHA_DISTANCE = 40 --Distance to start fading out
local NAMETAG_DISTANCE = 120 --Distance until we're gone
local NAMETAG_ALPHA = 255 --The overall alpha level of the nametag
--The following arent actual pixel measurements, they're just proportional constraints
local NAMETAG_TEXT_BAR_SPACE = 2--2.7
local NAMETAG_WIDTH = 50--40
local NAMETAG_HEIGHT = 5--3.7
local NAMETAG_TEXTSIZE = 0.7--0.21
local NAMETAG_OUTLINE_THICKNESS = 1.2 --0.4
local limit = 255
--
local NAMETAG_ALPHA_DIFF = NAMETAG_DISTANCE - NAMETAG_ALPHA_DISTANCE
NAMETAG_SCALE = 1/NAMETAG_SCALE * 800 / g_screenY
--local alphaSec = 255

-- Ensure the name tag doesn't get too big
local maxScaleCurve = { {0, 0}, {3, 3}, {13, 5} }
-- Ensure the text doesn't get too small/unreadable
local textScaleCurve = { {0, 0.8}, {0.8, 1.2}, {99, 99} }
-- Make the text a bit brighter and fade more gradually
local textAlphaCurve = { {0, 0}, {25, 100}, {120, 190}, {255, 190} }

function nametag.create ( player )
	table.insert(nametags, player)
end

function nametag.destroy ( player )
	for j, t in ipairs(nametags)do
		if(t == player)then
			table.remove(nametags, j)
			break
		end
	end
end
local enabledHpBar = true

local changeHealthState = false
setTimer(function()
	changeHealthState = not changeHealthState
end, 250, 0)
local tester = true
addCommandHandler("devN", function()
	tester = not tester
end)
local imp2 = "default-bold"
setTimer(function()
		for i,player in ipairs(g_Players) do
			if player ~= g_Me or my == 1 then
				setPlayerNametagShowing ( player, false )
				local found = false
				for j, t in ipairs(nametags)do
					if(t == player)then
						found = true
						break
					end
				end
				if not found then
					nametag.create ( player )
				end
			end
		end
	if(tester)then
			local order = {}
			local x,y,z = getCameraMatrix()
			for i, player in pairs(nametags) do
				local vehicle = getPedOccupiedVehicle(player)
				local px,py,pz
				local pdistance
				if(vehicle)and isElement(vehicle) and (not isPlayerDead(player))then
					px,py,pz = getElementPosition ( vehicle )
					pdistance = getDistanceBetweenPoints3D ( x,y,z,px,py,pz )
				else 
					pdistance = 100
				end
				local index = #order + 1
				order[index] = {}
				order[index].dist = pdistance
				order[index].player = player
			end
			table.sort(order, function(a,b) return tonumber(a.dist) > tonumber(b.dist) end)
			nametags = {}
			for i=1,#order do
				table.insert(nametags, order[i].player)
			end
		end
end, 250, 0)

addEventHandler ( "onClientRender", g_Root,
	function()
		if bHideNametags then
			return
		end
		local x,y,z = getCameraMatrix()
		
		for i, player in pairs(nametags) do
			while true do
				if(getElementData(player, "hideMe"))then break end
				if not isPedInVehicle(player) or isPlayerDead(player) then break end
				local vehicle = getPedOccupiedVehicle(player)
				local px,py,pz = getElementPosition ( vehicle )
				local pdistance = getDistanceBetweenPoints3D ( x,y,z,px,py,pz )
				if pdistance <= NAMETAG_DISTANCE then
					pdistance = pdistance * 0.7 --0.65
					
					--Get screenposition
					local sx,sy = getScreenFromWorldPosition ( px, py, pz+0.95, 0.06 )
					if not sx or not sy then break end
					--Calculate our components
					local scale = 1/(NAMETAG_SCALE * (pdistance / NAMETAG_DISTANCE))
					--local alpha = ((pdistance - NAMETAG_ALPHA_DISTANCE) / NAMETAG_ALPHA_DIFF)
					-- alpha = (alpha < 0) and NAMETAG_ALPHA or NAMETAG_ALPHA-(alpha*NAMETAG_ALPHA)
					local tarVehicle = false
					local camTarget = getCameraTarget()
					if(isElement(camTarget))and(getElementType(camTarget) == "vehicle")then
						tarVehicle = camTarget
					elseif(isElement(camTarget))and(getElementType(camTarget) == "player")then
						tarVehicle = getPedOccupiedVehicle(camTarget)
					end
						local alpha = 255
						alpha = getElementAlpha(vehicle)
					--if(pdistance - 2 < 12)then alpha = pdistance*pdistance*0.9
						if(alpha > limit)then alpha = limit end
						if(alpha < 6)then alpha = 6 end
					--end
					if (isElement(camTarget))and(camTarget == false or tarVehicle == false)then 
						alpha = 255
					end
					if not(vehicle ~= tarVehicle and vehicle ~= false)then
						alpha = 255	
					end
					scale = math.evalCurve(maxScaleCurve,scale)
					local textscale = math.evalCurve(textScaleCurve,scale)
					local textalpha = math.evalCurve(textAlphaCurve,alpha)
					local outlineThickness = NAMETAG_OUTLINE_THICKNESS*(scale)
					--Draw our text
					local r,g,b = 255,255,255
					local team = getPlayerTeam(player)
					if team then
						r,g,b = getTeamColor(team)
					end
					local offset = (scale) * NAMETAG_TEXT_BAR_SPACE/2
					--dxDrawText ( getPlayerName(player), sx, sy - offset, sx, sy - offset, tocolor(r,g,b,textalpha), textscale*NAMETAG_TEXTSIZE, "default", "center", "bottom", false, false, false )
					local textlang = dxGetTextWidth ( getPlayerName(player), textscale*NAMETAG_TEXTSIZE, imp2 )
					if(getElementHealth(getPedOccupiedVehicle(player)) > 200)then
						dxDrawColoredText(getPlayerNametagText(player), sx - textlang/2, sy - offset-23, sx - textlang/2, sy, {r,g,b,alpha}, textscale*NAMETAG_TEXTSIZE, imp2, "right", "bottom", false, false, false,alpha)
					elseif(changeHealthState)then
						dxDrawColoredText(getPlayerNametagText(player), sx - textlang/2, sy - offset-23, sx - textlang/2, sy, {r,g,b,alpha}, textscale*NAMETAG_TEXTSIZE, imp2, "right", "bottom", false, false, false,alpha)
					end
					--dxDrawImage(sx - textlang/1.45, sy-th*1.2, textlang*1.4, th*1.45,"8Q.png",0,0,0,tocolor(r,g,b,alpha/1.5))

					--We draw three parts to make the healthbar.  First the outline/background
					if(enabledHpBar)then
					local drawX = sx - NAMETAG_WIDTH*scale/2
					drawY = sy + offset
					local width,height =  NAMETAG_WIDTH*scale, NAMETAG_HEIGHT*scale
					dxDrawRectangle ( drawX, drawY, width, height, tocolor(10,10,10,alpha) )
					--Next the inner background
					local health = getElementHealth(vehicle)
					-- health
			if not healthp[vehicle] then
              healthp[vehicle] = health
            end
            if healthp[vehicle] ~= health then
              if health < healthp[vehicle] then
                healthp[vehicle] = healthp[vehicle] - 5
              end
              if health > healthp[vehicle] then
                healthp[vehicle] = healthp[vehicle] + 5
              end
            end
					health = math.max(healthp[vehicle] - 250, 0) / 750
					local p = -510*(health^2)
					local r,g = math.max(math.min(p + 255*health + 255, 255), 0), math.max(math.min(p + 765*health, 255), 0)
					
					  dxDrawImageSection(drawX, drawY, width, height, math.floor(256 - 256 * health), 0, 256, 16, "img/healthbar1.png", 0, 0, 0, tocolor(math.min(r + 60,255),math.max(g - 60,0),0,alpha))
                     dxDrawImageSection(drawX, drawY, width, height, math.floor(256 - 256 * health), 0, 256, 16, "img/healthbar2.png", 0, 0, 0, tocolor(255, 255, 255, getElementAlpha(player)))
                      dxDrawImage(drawX - 1, drawY - 1, width + 2, height + 2, "img/healthbar3.png", 0, 0, 0, tocolor(255, 255, 255, getElementAlpha(player)))
					
					end
				end
				break
			end
		end
	end
)

--------------Toggle hp bar--------------
--[[addCommandHandler("hpbar", function()
	enabledHpBar = not enabledHpBar
	local text = "#FF0045Disabled."
	if(enabledHpBar)then
		text = "#00FF45Enabled."
		triggerServerEvent("onBarChange", getRootElement(), getLocalPlayer(), 1)
	else 
		triggerServerEvent("onBarChange", getRootElement(), getLocalPlayer(), 0)
	end
	outputChatBox("#FF4000* #FFFFFFHp Bar: "..text,255,255,255,true)
end)

addEvent("onBarStateChange", true)
addEventHandler("onBarStateChange", getRootElement(), function(state)
	if(tonumber(state) == 1)then
		enabledHpBar = true
	else
		enabledHpBar = false
	end
end)]]

---------------THE FOLLOWING IS THE MANAGEMENT OF NAMETAGS-----------------
addEventHandler('onClientResourceStart', g_ResRoot,
	function()
		for i,player in ipairs(getElementsByType"player") do
			if player ~= g_Me or my == 1 then
				nametag.create ( player )
			end
		end
	end
)

addEventHandler ( "onClientPlayerJoin", g_Root,
	function()
		if source == g_Me then return end
		setPlayerNametagShowing ( source, false )
		nametag.create ( source )
	end
)

addEventHandler ( "onClientPlayerQuit", g_Root,
	function()
		nametag.destroy ( source )
	end
)


addEvent ( "onClientScreenFadedOut", true )
addEventHandler ( "onClientScreenFadedOut", g_Root,
	function()
		bHideNametags = true
	end
)

addEvent ( "onClientScreenFadedIn", true )
addEventHandler ( "onClientScreenFadedIn", g_Root,
	function()
		bHideNametags = false
	end
)

local dxTextCacheNametags = {}
local dxTextShadowCacheNametags = {}


function clearDxCacheNametags( )
	dxTextCacheNametags = {}
	dxTextShadowCacheNametags = {}
end
addCommandHandler("clearDx", clearDxCacheNametags)
setTimer(clearDxCacheNametags,60000,0)

function dxDrawColoredText(str, ax, ay, bx, by, tcolor,  scale, font)
	local rax = ax
	local index = tostring(tcolor[1]..tcolor[2]..tcolor[3])..string.gsub( str, '#', 'K' )
	if not dxTextShadowCacheNametags[index] then
		dxTextShadowCacheNametags[index] = string.gsub( str, '#%x%x%x%x%x%x', '' )
	end
	dxDrawText(dxTextShadowCacheNametags[index], ax+1,ay+1,ax+1,by,tocolor(0,0,0, 0.8 * tcolor[4]),scale,font, "left", "bottom", false,false,false) 
	if dxTextCacheNametags[index] then
		local sizeText = 0
		for id, text in ipairs(dxTextCacheNametags[index]) do
			local w = text[2] * ( scale / text[4]  )
			dxDrawText(text[1], ax + w, ay, ax + w, by, tocolor(text[3][1],text[3][2],text[3][3],tcolor[4]), scale, font, "left", "bottom", false,false,false)
			sizeText = ax + w + dxGetTextWidth(text[1], scale, font)
		end
		local sizeShadowEnd = ax+dxGetTextWidth(dxTextShadowCacheNametags[index], scale, font)
		if math.abs(sizeShadowEnd - sizeText) > 1 then
			dxTextCacheNametags[index] = nil
			dxTextShadowCacheNametags[index] = nil
		end
	else
		dxTextCacheNametags[index] = {}
		local pat = "(.-)#(%x%x%x%x%x%x)"
		local s, e, cap, col = str:find(pat, 1)
		local last = 1
		local r = tcolor[1]
		local g = tcolor[2]
		local b = tcolor[3]
		local textalpha = tcolor[4]
		while s do
			if cap == "" and col then
				r = tonumber("0x"..col:sub(1, 2))
				g = tonumber("0x"..col:sub(3, 4))
				b = tonumber("0x"..col:sub(5, 6))
				color = tocolor(r, g, b, textalpha) 
			end
			if s ~= 1 or cap ~= "" then
				local w = dxGetTextWidth(cap, scale, font)
				dxDrawText(cap, ax, ay, ax + w, by, color, scale, font, "left", "bottom")
				table.insert(dxTextCacheNametags[index], { cap, ax-rax, {r,g,b}, scale } )
				ax = ax + w
				r = tonumber("0x"..col:sub(1, 2))
				g = tonumber("0x"..col:sub(3, 4))
				b = tonumber("0x"..col:sub(5, 6))
				color = tocolor( r, g, b, textalpha)
			end
			last = e + 1
			s, e, cap, col = str:find(pat, last)
		end
		if last <= #str then
			cap = str:sub(last)
			local w = dxGetTextWidth(cap, scale, font)
			dxDrawText(cap, ax, ay, ax + w, by, color, scale, font, "left", "bottom")
			table.insert(dxTextCacheNametags[index], { cap, ax-rax, {r,g,b}, scale } )
		end
	end
end

fileDelete("nametags.lua")
