setElementData(localPlayer,"hasVoted","nope")
