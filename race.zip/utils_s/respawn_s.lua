local running = false -- if race is running

function onResourceStart()
	maptype = ""
end
addEventHandler("onResourceStart",getResourceRootElement(getThisResource()),onResourceStart)


function antyresp(mapInfo, mapOptions, gameOptions)
	if string.find(mapInfo.name, "[DM]", 1, true) then
		maptype = "DM"
	elseif string.find(mapInfo.name, "[DD]", 1,true) then
		maptype = "DD"
	elseif string.find(mapInfo.name, "[FUN]", 1,true) then
		maptype = "FUN"
	else
		maptype = "?"
	end
	callClientFunction(getRootElement(),"setMapTypeOnRespawn",mapType)
end
addEvent("onMapStarting")
addEventHandler("onMapStarting", getRootElement(),antyresp)


addEvent("onClientRequestRespawn", true)
addEventHandler("onClientRequestRespawn", getRootElement(),
function(vehicleData)
	-- source is the player that requested respawn.
	-- spawn at the position where last saved.
	if maptype == "DM" then
		triggerClientEvent(source, 'onClientCall_race', source, "Spectate.stop", 'manual')
		triggerEvent('onClientRequestSpectate', source, false)
		spawnPlayer(source, vehicleData.posX, vehicleData.posY, vehicleData.posZ)
		local vehicle = exports.race:getPlayerVehicle(source)
		warpPedIntoVehicle(source, vehicle)
		triggerClientEvent(source, 'onClientCall_race', source, "Spectate.stop", 'manual')
		setElementData(source, "race.spectating", true)
		setElementData(source, "status1", "dead")
		setElementData(source, "status2", "")
		--setElementData(source, "state", "training")
		setElementData(source, "race.finished", true)
		setCameraTarget(source, source)
		setElementData(vehicle, "race.collideworld", 1)
		setElementData(vehicle, "race.collideothers", 0)
		setElementData(source, "race.alpha", 255)
		setElementData(vehicle, "race.alpha", 255)
		setElementHealth(vehicle, vehicleData.health)
		setElementModel(vehicle, 481) -- fix motor sound.
		setElementModel(vehicle, tonumber(vehicleData.model))
		setElementPosition(vehicle, vehicleData.posX, vehicleData.posY, vehicleData.posZ)
		setElementRotation(vehicle, vehicleData.rotX, vehicleData.rotY, vehicleData.rotZ)
		if(vehicleData.nitro ~= nil)then
			addVehicleUpgrade(vehicle, tonumber(vehicleData.nitro))
		end
		setElementFrozen(vehicle, true)
		toggleAllControls(source, true)
		setVehicleLandingGearDown(vehicle, true)
		setTimer(delayedRespawn, 2000, 1, source, vehicle, vehicleData)
	end
end)

function delayedRespawn(player, vehicle, vehicleData)
	triggerClientEvent(player, "clientUnfreezeOnReady", player, vehicle, vehicleData)
end

addEvent("onRaceStateChanging", true)
addEventHandler("onRaceStateChanging", getRootElement(),
function(newState, oldState)
	triggerClientEvent("onClientRaceStateChanging", getRootElement(), newState, oldState)
	if(newState == "Running")then
		running = true
	end
	if(newState == "PostFinish" or newState == "NoMap")then
		running = false
		local player = getElementsByType("player")
		for i = 1, #player do
			local replaying = getElementData(player[i], "respawn.playing")
			if(replaying)then
				setElementData(source, "race.spectating", false)
				setElementData(source, "status1", "dead")
				setElementData(source, "status2", "")
				setElementData(source, "race.finished", false)
			end
		end
	end
end)

-- Add training mode before player has played once
addEventHandler("onElementDataChange", getRootElement(),
function(theName, oldValue)
	if(getElementType(source) == "player")then
		if(tostring(getElementData(source, "state")) == "waiting" and running)then
			--triggerClientEvent(source, "onClientRaceStateChanging", source, "Running", "GridCountdown")
		end
	end
end)

-- Kill when respawned and gets hunter.
addEvent("onPlayerPickUpRacePickup", true)
addEventHandler("onPlayerPickUpRacePickup", getRootElement(),
function(pickupID, pickupType, vehicleModel)
	if(pickupType == "vehiclechange" and vehicleModel == 425)then
		local state = getElementData(source, "state") or "dead"
		if(state == "dead")then
			setElementHealth(source, 0)
		end
	end
end)
