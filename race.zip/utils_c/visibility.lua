addEventHandler("onClientRender", getRootElement(),
function()
	local player = getElementsByType("player")
	for i = 1, #player do
		if(getElementData(player[i], "respawn.playing"))then
			local alpha = 0
			if(player[i] == getLocalPlayer())then
				alpha = getElementData(player[i], "race.alpha") or 255
			end
			setElementAlpha(player[i], alpha)
			local vehicle = getPedOccupiedVehicle(player[i])
			if(vehicle ~= false)then
				setElementAlpha(vehicle, alpha)
			end
		end
	end
end)