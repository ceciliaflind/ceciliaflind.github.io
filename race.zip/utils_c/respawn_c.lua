local screen_width, screen_height = guiGetScreenSize()
local RESPAWN_KEY = "SPACE"
local showRespawn = false
local color = tocolor(255, 128, 0, 255)
setElementData(getLocalPlayer(), "respawn.playing", false, true)
local running = false
local vehicleData = {}
local SAVE_INTER = 22500
local saveTimer = nil
local reset = true -- reset timer
local lastSaved = 0
local isDM = false
local mapType = ""



function isDM()
	for i, pu in pairs (getElementsByType("racepickup")) do
		local puType = getElementData(pu, "type")
		if (puType == "vehiclechange") then
			local puVehicle = tonumber(getElementData(pu, "vehicle"))
			if puVehicle == 425 then
				return true
			end
		end
	end
	return false
end


function setMapTypeOnRespawn(cache)
	mapType = cache
end

-- When element data for the player changes, bind or unbind key.
addEventHandler("onClientElementDataChange", getLocalPlayer(),
function(dataName, oldValue)
	if(getElementType(source) ~= "player" or dataName ~= "state")then return end
	local newValue = getElementData(source, dataName)
	if(newValue == "dead")then
		if isDM() and mapType == "DM" then
			reset = true
			setTimer(function()
			if(#vehicleData > 0 and running)then
				showRespawn = true
				setElementData(getLocalPlayer(), "respawn.playing", false, true)
				bindKey(RESPAWN_KEY, "up", respawn)
			end
			end,	3000, 1)
		else
			unbindKey(RESPAWN_KEY, "up", respawn)
			showRespawn = false
			setElementData(getLocalPlayer(), "respawn.playing", false, true)
		end
	else
		unbindKey(RESPAWN_KEY, "up", respawn)
		showRespawn = false
		setElementData(getLocalPlayer(), "respawn.playing", false, true)
	end
	if(newValue == "alive" and oldValue ~= "alive")then
		reset = false
	end
end)

-- respawn player, later add "checkpoints"
function respawn()
	reset = false
	unbindKey(RESPAWN_KEY, "up", respawn)
	showRespawn = false
	setElementData(getLocalPlayer(), "respawn.playing", true, true)
	local index = #vehicleData
	local index2 = #vehicleData
	-- Save memory and go back to later saved positions if dying too fast.
	local timeWasted = math.floor((getTickCount() - lastSaved)/1000)
	if(timeWasted <= 7 and index > 1)then
		table.remove(vehicleData, index)
		index = #vehicleData
		outputDebugString("Vehicle data num: "..index.." removed respawn.")
	end
	outputDebugString("Respawning with vehicle data index: "..index)
	triggerServerEvent("onClientRequestRespawn", getLocalPlayer(), vehicleData[index])
	if(index2 > 1 and index == index2)then
		table.remove(vehicleData, index)
		outputDebugString("Vehicle data num: "..index.." removed.")
	end
end


addEventHandler("onClientRender", getRootElement(),
function()
	if(reset)then
		resetTimer(saveTimer)
	end
	local text = "#DD1111Press #707070"..RESPAWN_KEY.." #DD1111to respawn and try again!"
	local scale = screen_height*0.0025
	local font = "default-bold"
	local textWidth = dxGetTextWidth(text:gsub("#%x%x%x%x%x%x", ""), scale, font)
	local fontHeight = dxGetFontHeight(scale, font)
	-- Dont show text if player is not allowed to respawn.
	if not showRespawn then return end
	local x, y = screen_width/2 - textWidth/2, screen_height * 0.75 - fontHeight/2
	dxDrawColoredText("#000000"..text:gsub("#%x%x%x%x%x%x", ""), x+1, y+1, screen_width, screen_height, color, scale, font)
	dxDrawColoredText(text, x, y, screen_width, screen_height, color, scale, font)
end)


-- Save vehicle data, to later spawn with that data.
function saveVehicleData()
	local vehicle = getPedOccupiedVehicle(getLocalPlayer())
	if(not running or showRespawn or (not vehicle) or reset)then return end
	local mode = getElementModel(vehicle)
	if(mode == 425)then return end
	local lastSaved = getTickCount()
	local index = #vehicleData + 1
	vehicleData[index] = {}
	local posX, posY, posZ = getElementPosition(vehicle)
	local rotX, rotY, rotZ = getElementRotation(vehicle)
	local velX, velY, velZ = getElementVelocity(vehicle)
	local turnVelX, turnVelY, turnVelZ = getVehicleTurnVelocity(vehicle)
	local health = getElementHealth(vehicle)
	local model = getElementModel(vehicle)
	-- Later add worldSpecialProperty too.
	vehicleData[index].posX = posX
	vehicleData[index].posY = posY
	vehicleData[index].posZ = posZ
		
	vehicleData[index].rotX = rotX
	vehicleData[index].rotY = rotY
	vehicleData[index].rotZ = rotZ
		
	vehicleData[index].velX = velX
	vehicleData[index].velY = velY
	vehicleData[index].velZ = velZ
		
	vehicleData[index].turnVelX = turnVelX
	vehicleData[index].turnVelY = turnVelY
	vehicleData[index].turnVelZ = turnVelZ
		
	vehicleData[index].health = health
	vehicleData[index].model = model
	vehicleData[index].dimension = getElementDimension(vehicle)
	
	vehicleData[index].nitro = nil
	local upgrades = getVehicleUpgrades(vehicle)
	for upgradeKey, upgradeValue in ipairs(upgrades) do
		if(tonumber(upgradeValue) >= 1008 and tonumber(upgradeValue) <= 1010)then
			vehicleData[index].nitro = tonumber(upgradeValue)
		end
	end
	outputDebugString("Vehicle data num: "..index.." saved.")
end

saveTimer = setTimer(saveVehicleData, SAVE_INTER, 0)

function saveRespawnToSpawnpoint(player)
	local vehicle = getPedOccupiedVehicle(player)
	local index = #vehicleData + 1
	vehicleData[index] = {}
	local spawn = getElementsByType("spawnpoint")
	local posX, posY, posZ = getElementData(spawn[1], "posX"), getElementData(spawn[1], "posY"), getElementData(spawn[1], "posZ")
	local rotX, rotY, rotZ = getElementData(spawn[1], "rotX"), getElementData(spawn[1], "rotY"), getElementData(spawn[1], "rotZ")
	local velX, velY, velZ = 0, 0, 0
	local turnVelX, turnVelY, turnVelZ = 0, 0, 0
	local health = getElementHealth(vehicle)
	local model = getElementData(spawn[1], "vehicle")
	-- Later add worldSpecialProperty too.
	vehicleData[index].posX = posX
	vehicleData[index].posY = posY
	vehicleData[index].posZ = posZ
		
	vehicleData[index].rotX = rotX
	vehicleData[index].rotY = rotY
	vehicleData[index].rotZ = rotZ
		
	vehicleData[index].velX = velX
	vehicleData[index].velY = velY
	vehicleData[index].velZ = velZ
		
	vehicleData[index].turnVelX = turnVelX
	vehicleData[index].turnVelY = turnVelY
	vehicleData[index].turnVelZ = turnVelZ
		
	vehicleData[index].health = health
	vehicleData[index].model = model
	vehicleData[index].dimension = getElementDimension(vehicle)
end

addEvent("onClientRaceStateChanging", true)
addEventHandler("onClientRaceStateChanging", getRootElement(),
function(newState, oldState)
	if(newState == "Running")then
		local state = tostring(getElementData(getLocalPlayer(), "state"))
		if(state == "waiting")then
			--[[
			reset = false
			running = true
			vehicleData = {}
			saveRespawnToSpawnpoint(getLocalPlayer())
			showRespawn = true
			setElementData(getLocalPlayer(), "respawn.playing", false, true)
			bindKey(RESPAWN_KEY, "up", respawn)
			--]]
		elseif(state == "alive" or state == "not ready")then
			reset = false
			running = true
			for i = 1, #vehicleData do
				table.remove(vehicleData, i)
			end
			vehicleData = {}
			saveVehicleData()
		end
	end
	if(newState == "PostFinish" or newState == "NoMap")then
		reset = true
		running = false
		unbindKey(RESPAWN_KEY, "up", respawn)
		showRespawn = false
		setElementData(getLocalPlayer(), "respawn.playing", false, true)
	end
end)

addEventHandler("onClientPlayerWasted", getLocalPlayer(),
function()
	if(source ~= getLocalPlayer())then return end
	reset = true
	setElementData(getLocalPlayer(), "respawn.playing", false, true)
	setTimer(function()
		--local state = getElementData(getLocalPlayer(), "respawn.playing") or true
			if(#vehicleData > 0 and running)then
				showRespawn = true
				setElementData(getLocalPlayer(), "respawn.playing", false, true)
				bindKey(RESPAWN_KEY, "up", respawn)
			end
		end,
	3000, 1)
end)

local unfreeze = {}

addEvent("clientUnfreezeOnReady", true)
addEventHandler("clientUnfreezeOnReady", getRootElement(),
function(vehicle, vehData)
	-- source is the vehicle to unfreeze
	unfreeze.vehicle = vehicle
	unfreeze.health = vehData.health
	unfreeze.dim = vehData.dimension
	unfreeze.x, unfreeze.y, unfreeze.z = vehData.posX, vehData.posY, vehData.posZ
	unfreeze.vx, unfreeze.vy, unfreeze.vz = vehData.velX, vehData.velY, vehData.velZ
	unfreeze.tx, unfreeze.ty, unfreeze.tz = vehData.turnVelX, vehData.turnVelY, vehData.turnVelZ
	setElementFrozen(vehicle, false)
	addEventHandler("onClientRender", getRootElement(), unfreezeOnReady)
end)

function unfreezeOnReady()
	setElementHealth(unfreeze.vehicle, unfreeze.health)
	setElementPosition(unfreeze.vehicle, unfreeze.x, unfreeze.y, unfreeze.z)
	if(not isElementFrozen(unfreeze.vehicle))then
		setElementDimension(unfreeze.vehicle, unfreeze.dim)
		setElementVelocity(unfreeze.vehicle, unfreeze.vx, unfreeze.vy, unfreeze.vz)
		setVehicleTurnVelocity(unfreeze.vehicle, unfreeze.tx, unfreeze.ty, unfreeze.tz)
		removeEventHandler("onClientRender", getRootElement(), unfreezeOnReady)
	end
end

function dxDrawColoredText(text, left, top, right, bottom, color, scale, font, alignX, alignY, clip, wordBreak, postGUI)
	-- Making them optional.
	right = right or screen_width
	bottom = bottom or screen_height
	while(left < 0) do
		left = screen_width - math.abs(left)
	end
	while(top < 0) do
		top = screen_height - math.abs(top)
	end
	while(right < 0) do
		right = screen_width - math.abs(right)
	end
	while(bottom < 0) do
		bottom = screen_height - math.abs(bottom)
	end
	if(right > screen_width)then right = screen_width end
	if(bottom > screen_height)then bottom = screen_height end
	color = color or tocolor(255, 255, 255, 200)
	scale = scale or 1
	font = font or "default"
	alignX = alignX or "left"
	alignY = alignY or "top"
	clip = clip or false
	wordBreak = wordBreak or false
	postGUI = postGUI or true
	local alpha = intToAlpha(color)
	local text_width = 0
	local offset = 0
	local text_height = dxGetFontHeight(scale, font)
	local TEXT_WIDTH = dxGetTextWidth(text:gsub("#%x%x%x%x%x%x", ""), scale, font)
	local off = -TEXT_WIDTH
	local width = 0
	local height = 0
	if(alignX == "center")then
		left = left + width/2 - TEXT_WIDTH/2
	end
	if(alignX == "right")then
		left = left + width - TEXT_WIDTH
	end
	if(alignY == "center")then
		top = top + height/2 - text_height/2
	end
	if(alignY == "bottom")then
		top = top + height - text_height
	end
	alignX = "left"
	alignY = "top"
	
	-- 0 index ?
	local col1, col2 = string.find(text, "#%x%x%x%x%x%x")
	if col1 ~= nil then col1 = col1-1 end
	
	-- draw text with the color we sent until we find hexadecimal code.
	for i = 1, col1 or string.len(text) do
		text_width = dxGetTextWidth(string.sub(text, i, i), scale, font)
		dxDrawText(string.sub(text, i, i), left + offset, top, right, bottom, color, scale, font, alignX, alignY, clip, wordBreak, postGUI)
		offset = offset + text_width
	end
	while(string.find(text, "#%x%x%x%x%x%x", i))do
		local hex1, hex2 = string.find(text, "#%x%x%x%x%x%x")
		local r, g, b, a = getColorFromString(string.sub(text, hex1, hex2))
		text = string.sub(text, hex2 + 1)
		hex1, hex2 = string.find(text, "#%x%x%x%x%x%x")
		if hex1 ~= nil then hex1 = hex1-1 end
		for i = 1, hex1 or string.len(text) do
			text_width = dxGetTextWidth(string.sub(text, i, i), scale, font)
			dxDrawText(string.sub(text, i, i), left + offset, top, right, bottom, tocolor(r, g, b, alpha), scale, font, alignX, alignY, clip, wordBreak, postGUI)
			offset = offset + text_width
		end
	end
end

function intToAlpha(color)
	local a = 16777216
	local red, green, blue, alpha = 0, 0, 0, 0
	local ap = 1
	
	if(color < 0)then
		color = 2147483648 + (-color)
		alpha = 383
		ap = -ap
	end
	
	while(color >= a)do
		alpha = alpha + ap
		color = color - a
	end
	return alpha
end
